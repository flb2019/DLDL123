package com.soso.app.module.message.mvp.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.billy.cc.core.component.CC;
import com.soso.app.module.message.R;
import com.soso.uiactivity.base.fragment.SoSoCommonFragment;
import com.soso.uiwidget.widgets.title.ITitleWrapper;

import java.util.concurrent.TimeUnit;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;

/**
 * Created by sumerlin on 2019/2/24 2019/2/24.
 * Describe:
 */
public class MessageDetailFragment extends SoSoCommonFragment {
    @Override
    protected int getLayoutResId() {
        return R.layout.message_fragment_detail;
    }

    @Override
    protected ITitleWrapper initTitle(View titleView) {
        return new ITitleWrapper() {
            @Override
            public int getTitleBarType() {
                return ITitleWrapper.FLAG_ALL | ITitleWrapper.FLAG_BTN;
            }

            @Override
            public boolean onPageBack(View view) {
                getActivity().finish();
                return false;
            }

            @Override
            public String getTitle(View view) {
                return "message-detail";
            }

            @Override
            public String getTitleRightBtnText(View view) {
                return "扫一扫";
            }

            @Override
            public boolean onPageNext(View view) {
                CC.obtainBuilder("OtherComponent")
                        .setContext(getActivity())
                        .setActionName("openQRCoderView")
                        .build()
                        .call();
                return false;
            }
        };
    }

    @Override
    protected void initBodyView(View view, @Nullable Bundle savedInstanceState) {
        super.initBodyView(view, savedInstanceState);
        showLoading();
        io.reactivex.Observable.timer(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Long>() {
                    @Override
                    public void accept(Long aLong) throws Exception {
//                        LSPostUtil.postCircularLoading(mLoadService);
                        showCircularLoading();
                    }
                });

        io.reactivex.Observable.timer(4, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Long>() {
                    @Override
                    public void accept(Long aLong) throws Exception {
                        showError();
                    }
                });

    }

    @Override
    protected void onReload(View v) {
        super.onReload(v);

        showCircularLoading();
        io.reactivex.Observable.timer(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Long>() {
                    @Override
                    public void accept(Long aLong) throws Exception {
                        showSuccess();
                    }
                });
    }
}
