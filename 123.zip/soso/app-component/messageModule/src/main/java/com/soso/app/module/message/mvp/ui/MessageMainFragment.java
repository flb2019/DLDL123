package com.soso.app.module.message.mvp.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.soso.app.module.message.R;
import com.soso.common.module.web.mvp.ui.WebNetFragment;
import com.soso.sosolib.art.di.component.AppComponent;
import com.soso.sosolib.art.tools.AppComponentUtils;
import com.soso.sosolib.utils.FileUtils;
import com.soso.uiactivity.base.UIModelHelper;
import com.soso.uiactivity.base.fragment.SoSoCommonFragment;
import com.soso.uiwidget.imageloader.ImageLoader;
import com.soso.uiwidget.imageloader.glide.GlideConfig;
import com.soso.uiwidget.imageloader.glide.ImageScaleType;
import com.soso.uiwidget.imageloader.transformation.BlurTransformation;
import com.soso.uiwidget.imageloader.transformation.RoundTransformation;
import com.soso.uiwidget.pictureselector.PictureSelectorHelper;
import com.soso.uiwidget.widgets.title.ITitleWrapper;

import java.io.File;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;

/**
 * Created by sumerlin on 2019/2/24 2019/2/24.
 * Describe:
 */
public class MessageMainFragment extends SoSoCommonFragment {

    private String mDirSize;

    public static MessageMainFragment getInstance() {
        MessageMainFragment fragment = new MessageMainFragment();
        return fragment;
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.message_fragment_main;
    }

    @Override
    protected ITitleWrapper initTitle(View titleView) {
        titleView.setVisibility(View.GONE);
        return new ITitleWrapper() {
            @Override
            public int getTitleBarType() {
                return ITitleWrapper.FLAG_BACK;
            }

            @Override
            public boolean onPageBack(View view
            ) {
                getActivity().finish();
                return false;
            }
        };
    }

    @Override
    protected void initBodyView(View view, @Nullable Bundle savedInstanceState) {
        super.initBodyView(view, savedInstanceState);
        showSuccess();
        View viewById = view.findViewById(R.id.btn_detail);
        viewById.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UIModelHelper.startNextAct(getActivity(), MessageDetailFragment.class.getName());

            }
        });

        view.findViewById(R.id.btn_web).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WebNetFragment.startFragment(getActivity(), "https://www.baidu.com", "title", false);

            }
        });

        ImageView imageView = view.findViewById(R.id.img);
        ImageView imageView2 = view.findViewById(R.id.img2);
        ImageView imageView3 = view.findViewById(R.id.img3);
        ImageView imageView4 = view.findViewById(R.id.img4);
        String url = "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_" +
                "10000&sec=1551382131772&di=7ee4086362bafc517bb9ddb43abc4336&imgtype=0&src=http%3A%2F%2Fpic26.nipic.com%2F20121227%2F10193203_131357536000_2.jpg";

        view.findViewById(R.id.btn_img).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url2 = "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1551441215201&di=f79639d1df68913a111b09e272166598&imgtype=0&src=http%3A%2F%2Fwww.pptbz.com%2Fpptpic%2FUploadFiles_6909%2F201203%2F2012031220134655.jpg";
                ImageLoader.getInstance().load(getActivity(), GlideConfig
                        .builder()
                        .url(url)
                        .imageView(imageView)
                        .scaleType(ImageScaleType.CENTER_CROP)
                        .placeholder(R.mipmap.ic_launcher)
                        .error(R.mipmap.ic_launcher_round)
                        .cacheStrategy(0)
                        .build());
                ImageLoader.getInstance().load(getActivity(), GlideConfig
                        .builder()
                        .url(url2)
                        .imageView(imageView2)
                        .scaleType(ImageScaleType.CENTER_CROP)
                        .transformation(new RoundTransformation(getActivity(), 80))
                        .placeholder(R.mipmap.ic_launcher)
                        .error(R.mipmap.ic_launcher_round)
                        .cacheStrategy(0)
                        .build());

                ImageLoader.getInstance().load(getActivity(), GlideConfig
                        .builder()
                        .url(url)
                        .imageView(imageView3)
                        .scaleType(ImageScaleType.CENTER_CROP)
                        .transformation(new RoundTransformation(getActivity(), 8))
                        .placeholder(R.mipmap.ic_launcher)
                        .error(R.mipmap.ic_launcher_round)
                        .cacheStrategy(0)
                        .build());

                ImageLoader.getInstance().load(getActivity(), GlideConfig
                        .builder()
                        .url(url)
                        .imageView(imageView4)
                        .scaleType(ImageScaleType.FIT_CENTER)
                        .transformation(new BlurTransformation(4))
                        .placeholder(R.mipmap.ic_launcher)
                        .error(R.mipmap.ic_launcher_round)
                        .cacheStrategy(0)
                        .build());


            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PictureSelectorHelper.ShowSelectedPicture(getActivity(), url);
            }
        });


        AppComponent appComponent = AppComponentUtils.getAppComponent();
        TextView btnClear = view.findViewById(R.id.btn_clear);
        File file = new File(appComponent.cacheFile(), "Glide");
        String path = file.getPath();
        mDirSize = FileUtils.getDirSize(path);
        btnClear.setText("清除：" + mDirSize);
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //底层是异步处理的
                ImageLoader.getInstance().clear(getActivity(), GlideConfig.builder().clearDiskCache(true).clearMemory(true).build());
                Observable.timer(2, TimeUnit.SECONDS)
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Consumer<Long>() {
                            @Override
                            public void accept(Long aLong) throws Exception {

                                mDirSize = FileUtils.getDirSize(path);
                                btnClear.setText("清除：" + mDirSize);
                            }
                        });
            }
        });

    }
}
