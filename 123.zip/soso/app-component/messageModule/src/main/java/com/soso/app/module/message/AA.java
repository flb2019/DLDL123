package com.soso.app.module.message;

/**
 * Created by sumerlin on 2019/2/24 2019/2/24.
 * Describe:
 */
public class AA {
}
