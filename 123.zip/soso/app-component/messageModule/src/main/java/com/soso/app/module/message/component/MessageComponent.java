package com.soso.app.module.message.component;

import com.billy.cc.core.component.CC;
import com.billy.cc.core.component.CCResult;
import com.billy.cc.core.component.IComponent;
import com.soso.app.module.message.mvp.ui.MessageMainFragment;

/**
 * Created by sumerlin on 2019/2/24 2019/2/24.
 * Describe:
 */
public class MessageComponent  implements IComponent {
    @Override
    public String getName() {
        return "MessageComponent";
    }

    @Override
    public boolean onCall(CC cc) {
        String actionName = cc.getActionName();
        switch (actionName) {
            case  "startMainFragment":
                startMessageMainFragment(cc);
                break;

        }
        CC.sendCCResult(cc.getCallId(), CCResult.success());
        return false;
    }

    private void startMessageMainFragment(CC cc) {
        MessageMainFragment fragment = MessageMainFragment.getInstance();
        CC.sendCCResult(cc.getCallId(), CCResult.success().addData("fragment", fragment));

    }



}
