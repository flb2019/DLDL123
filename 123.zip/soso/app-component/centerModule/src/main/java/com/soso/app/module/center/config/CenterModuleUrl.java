package com.soso.app.module.center.config;

/**
 * Created by sumerlin on 2019/2/28 2019/2/28.
 * Describe:
 */
public interface CenterModuleUrl {
    //GET http://gank.io/api/data/Android/10/1
    String Host_Url = "https://api.eelly.com";
    String REQ_HOME_LIST = "/api/data/Android/10/1";
    String REQ_EELLY_TEST = "https://api.eelly.com/live/live/getLivingRoomNum";
    String REQ_EELLY_TEST2 = "https://api.eelly.com/eellyOldCode/live/live/getHomeLiveList";
    String REQ_EELLY_TEST3 = "https://api.eelly.com/eellyOldCode/phenix/startPage/getStartPageData";//参数 {"type":2}
}
