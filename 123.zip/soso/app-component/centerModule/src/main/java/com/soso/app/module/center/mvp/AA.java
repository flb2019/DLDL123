package com.soso.app.module.center.mvp;

/**
 * Created by sumerlin on 2019/2/28 2019/2/28.
 * Describe:
 */
public class AA {
}
