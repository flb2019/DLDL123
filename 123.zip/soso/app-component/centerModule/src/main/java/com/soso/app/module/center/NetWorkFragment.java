package com.soso.app.module.center;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.JsonElement;
import com.soso.app.module.center.config.CenterModuleUrl;
import com.soso.network.NetWorkTestEvent;
import com.soso.network.bean.NetResultData;
import com.soso.network.callback.NetCallback;
import com.soso.network.core.NetWorkManager;
import com.soso.network.core.NetWorkMethods;
import com.soso.network.core.cache.CacheStrategyModel;
import com.soso.network.exception.ErrorMessage;
import com.soso.network.tools.ParseUtils;
import com.soso.sosolib.art.di.component.AppComponent;
import com.soso.sosolib.art.tools.AppComponentUtils;
import com.soso.sosolib.bean.AppToken;
import com.soso.sosolib.todo.AppInfoModule;
import com.soso.sosolib.utils.FileUtils;
import com.soso.sosolib.utils.LogUtils;
import com.soso.sosolib.utils.ToastManager;
import com.soso.uiactivity.base.fragment.SoSoCommonFragment;
import com.soso.uiwidget.widgets.refresh.SoPullToRefreshView;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Cache;
import retrofit2.Response;

/**
 * Created by sumerlin on 2019/2/25 2019/2/25.
 * Describe:
 */
public class NetWorkFragment extends SoSoCommonFragment {


    private SoPullToRefreshView mSoPullToRefreshView;

    private List<String> networkList = new ArrayList<>();
    private NetWorkAdapter mNetWorkAdapter;

    @Override
    protected int getLayoutResId() {
        return R.layout.center_fragment_network;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        showSuccess();
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    protected void initBodyView(View view, @Nullable Bundle savedInstanceState) {
        super.initBodyView(view, savedInstanceState);

        mSoPullToRefreshView = view.findViewById(R.id.soPullToRefreshView);
        mNetWorkAdapter = new NetWorkAdapter();
        mSoPullToRefreshView.setAdapter(mNetWorkAdapter);
        TextView tvDir = view.findViewById(R.id.btn_cache_dir);
        view.findViewById(R.id.btn_cache_clear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cache cache = NetWorkManager.getInstance().getHttpClient().cache();
                File directory = cache.directory();
                String dirName = FileUtils.getDirName(directory);
                String fileSize = FileUtils.getFileSize(directory);
                tvDir.setText(dirName + "==size:" + fileSize);
                try {
                    cache.delete();
//                    FileUtils.deleteFile(directory);
                } catch (IOException e) {


                }

            }
        });

        view.findViewById(R.id.btn_get_token).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //请求token
                AppComponent appComponent = AppComponentUtils.getAppComponent();
                AppInfoModule appInfoModule = appComponent.getAppInfoModule();
                String client_credentials = "client_credentials";
                String client_id = appInfoModule.getClientKey();
                String client_secret = appInfoModule.getClientSecret();
                String refresh_token = "";
                Observable<Response<JsonElement>> tokenObservable = NetWorkMethods.getInstance()
                        .getRetrofitService()
                        .getToken(client_credentials, client_id, client_secret, refresh_token);
                tokenObservable
                        .map(new Function<Response<JsonElement>, AppToken>() {
                            @Override
                            public AppToken apply(retrofit2.Response<JsonElement> response) throws Exception {
                                JsonElement body = response.body();
                                AppToken accessToken = ParseUtils.parseJsonElement(body, AppToken.class, "");
                                return accessToken;
                            }
                        })
                        .subscribeOn(Schedulers.io()) //很关键， 必须在当前线程同步处理。
                        .observeOn(Schedulers.io())
                        .subscribe(new Observer<AppToken>() {
                            @Override
                            public void onSubscribe(Disposable d) {
                                LogUtils.i("onComplete", "onComplete 1=======================================================" + refresh_token);

                            }

                            @Override
                            public void onNext(AppToken o) {
                                appComponent.extras().put("token", o.getAccessToken());

                            }

                            @Override
                            public void onError(Throwable e) {
                                LogUtils.i("onComplete", "onComplete 1=======================================================" + refresh_token);
                            }

                            @Override
                            public void onComplete() {
                                LogUtils.i("onComplete", "onComplete 1=======================================================" + refresh_token);
                                //不管是成功还是失败
                            }
                        });
            }
        });

        view.findViewById(R.id.btn_net_request).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                networkList.clear();
                mNetWorkAdapter.setNewData(networkList);
//                HashMap<String, Object> paramsMap = new HashMap<>();
//                paramsMap.put("type", "Android");
//                paramsMap.put("page", 1);
//                paramsMap.put("pre_page", 20);
//                ApiFactory.getInstance().get(CenterModuleUrl.REQ_HOME_LIST, null, new NetCallback<GanKIoDataBean>() {
//                    @Override
//                    public void onStart(Disposable disposable) {
//
//                    }
//
//                    @Override
//                    public void onSuccess(NetResultData<GanKIoDataBean> netResult) {
//
//                    }
//
//                    @Override
//                    public void onError(ErrorMessage error) {
//
//                    }
//                });
//                NetWorkMethods.getInstance().get(CenterModuleUrl.REQ_HOME_LIST, new NetCallback<GanKIoDataBean>() {
//                    @Override
//                    public void onStart(Disposable disposable) {
//
//                    }
//
//                    @Override
//                    public void onSuccess(NetResultData<GanKIoDataBean> netResult) {
//
//                    }
//
//                    @Override
//                    public void onError(ErrorMessage error) {
//
//                    }
//                });

                for (int i = 0; i < 1; i++) {
                    int finalI = i;
                    CacheStrategyModel cacheStrategyModel = new CacheStrategyModel().builder().cacheTime(30);
                    NetWorkMethods.getInstance().postBody(CenterModuleUrl.REQ_EELLY_TEST, cacheStrategyModel, new NetCallback<Object>() {
                        @Override
                        public void onStart(Disposable disposable) {
                            addDisposable(disposable);
//                            networkList.add("请求链接类型1。。。。+" + finalI);

                        }

                        @Override
                        public void onSuccess(NetResultData<Object> netResult) {
//                            ToastManager.getInstance(getActivity()).showText("成功，数据：" + netResult.getData());
                            showSuccess();

                        }

                        @Override
                        public void onError(ErrorMessage error) {
                            ToastManager.getInstance(getActivity()).showText("失败");
                        }
                    });
                }

//                for (int i = 0; i < 2; i++) {
//                    int finalI = i;
//                    NetWorkMethods.getInstance().postBody(CenterModuleUrl.REQ_EELLY_TEST2, new NetCallback<Object>() {
//                        @Override
//                        public void onStart(Disposable disposable) {
//                            addDisposable(disposable);
////                            networkList.add("请求链接类型2。。。。+" + finalI);
//                        }
//
//                        @Override
//                        public void onSuccess(NetResultData<Object> netResult) {
////                            ToastManager.getInstance(getActivity()).showText("成功，数据：" + netResult.getData());
//                            showSuccess();
//                        }
//
//                        @Override
//                        public void onError(ErrorMessage error) {
//                            ToastManager.getInstance(getActivity()).showText("失败");
//                        }
//                    });
//                }
//                HashMap<String, Object> objectObjectHashMap = new HashMap<>();
//                objectObjectHashMap.put("type", 2);
//                for (int i = 0; i < 2; i++) {
//
//                    int finalI = i;
//                    NetWorkMethods.getInstance().postBody(CenterModuleUrl.REQ_EELLY_TEST3, objectObjectHashMap, new NetCallback<Object>() {
//                        @Override
//                        public void onStart(Disposable disposable) {
//                            addDisposable(disposable);
////                            networkList.add("请求链接类型3。。。。+" + finalI);
//                        }
//
//                        @Override
//                        public void onSuccess(NetResultData<Object> netResult) {
////                            ToastManager.getInstance(getActivity()).showText("成功，数据：" + netResult.getData());
//                            showSuccess();
//                        }
//
//                        @Override
//                        public void onError(ErrorMessage error) {
//                            ToastManager.getInstance(getActivity()).showText("失败");
//                        }
//                    });
//                }
//                mNetWorkAdapter.setNewData(networkList);
            }
        });

        view.findViewById(R.id.btn_token).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppComponentUtils.getAppComponent().extras().remove("token");
                String token = (String) AppComponentUtils.getAppComponent().extras().get("token");
                ToastManager.getInstance(getActivity()).showText("token:" + token);
                networkList.clear();
                mNetWorkAdapter.setNewData(networkList);
            }
        });


    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNetWorkTestEvent(NetWorkTestEvent event) {
//        networkList.add(event.message);

        mNetWorkAdapter.addData(event.message);
        mNetWorkAdapter.notifyDataSetChanged();
//        mNetWorkAdapter.addData(networkList);
    }

    @Override
    public boolean useEventBus() {
        return true;
    }

    public static class NetWorkAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

        public NetWorkAdapter() {
            super(R.layout.center_item_network);
        }

        @Override
        protected void convert(BaseViewHolder helper, String item) {
            helper.setText(R.id.tv_netwok, item);

        }
    }
}
