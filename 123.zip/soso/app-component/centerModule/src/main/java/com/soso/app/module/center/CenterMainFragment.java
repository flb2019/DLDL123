package com.soso.app.module.center;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.billy.cc.core.component.CC;
import com.billy.cc.core.component.CCResult;
import com.soso.common.assist.AssistMainActivity;
import com.soso.common.db.AppDatabase;
import com.soso.common.db.User;
import com.soso.common.module.flutter_test.FlutterMainActivity2;
import com.soso.sosolib.art.di.component.AppComponent;
import com.soso.sosolib.art.tools.AppComponentUtils;
import com.soso.sosolib.utils.JsonUtils;
import com.soso.sosolib.utils.ToastManager;
import com.soso.uiactivity.base.UIModelHelper;
import com.soso.uiactivity.base.fragment.SoSoCommonFragment;

import java.util.List;

/**
 * Created by sumerlin on 2019/2/25 2019/2/25.
 * Describe:
 */
public class CenterMainFragment extends SoSoCommonFragment {

    public static CenterMainFragment getInstance() {
        CenterMainFragment fragment = new CenterMainFragment();
        return fragment;
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.center_fragment_main;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        showSuccess();
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    protected void initBodyView(View view, @Nullable Bundle savedInstanceState) {
        super.initBodyView(view, savedInstanceState);
        view.findViewById(R.id.btn_flutter).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FlutterMainActivity2.start(getActivity());

            }
        });

        view.findViewById(R.id.btn_assist).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AssistMainActivity.start(getActivity());

            }
        });

        view.findViewById(R.id.btn_net).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UIModelHelper.startNextAct(getActivity(),NetWorkFragment.class.getName());

            }
        });




        view.findViewById(R.id.btn_share).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CCResult call = CC.obtainBuilder("ShareComponent")
                        .setActionName("openShareDialog")
                        .setContext(getActivity())
                        .build()
                        .call();
                Object dataItem = call.getDataItem("11");

            }
        });

        view.findViewById(R.id.btn_pay).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CCResult call = CC.obtainBuilder("PayComponent")
                        .setActionName("openPayDialog")
                        .setContext(getActivity())
                        .build()
                        .call();
                Object dataItem = call.getDataItem("11");
            }
        });

        view.findViewById(R.id.btn_db_insert).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user = new User();
                user.setUserId("testid");
                user.setName("test");
                AppComponent appComponent = AppComponentUtils.getAppComponent();
                AppDatabase.getDatabase(appComponent).userDao().insertAll(user);
                ToastManager.getInstance(getActivity()).showText(JsonUtils.formatJson(user));
            }
        });

        view.findViewById(R.id.btn_db_query).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppComponent appComponent = AppComponentUtils.getAppComponent();
                List<User> all = AppDatabase.getDatabase(appComponent).userDao().getAll();
                ToastManager.getInstance(getActivity()).showText(JsonUtils.formatJson(all));
            }
        });
    }
}
