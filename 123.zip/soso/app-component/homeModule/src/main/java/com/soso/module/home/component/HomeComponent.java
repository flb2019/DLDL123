package com.soso.module.home.component;

import com.billy.cc.core.component.CC;
import com.billy.cc.core.component.CCResult;
import com.billy.cc.core.component.IComponent;
import com.soso.module.home.mvp.ui.HomeMainFragment;
import com.soso.uiactivity.base.UIModelHelper;

/**
 * Created by sumerlin on 2019/2/17 2019/2/17.
 * Describe:
 */
public class HomeComponent implements IComponent {
    @Override
    public String getName() {
        return "HomeComponent";
    }

    /**
     * 组件被调用时的入口
     * 要确保每个逻辑分支都会调用到CC.sendCCResult，
     * 包括try-catch,if-else,switch-case-default,startActivity
     *
     * @param cc 组件调用对象，可从此对象中获取相关信息
     * @return true:将异步调用CC.sendCCResult(...),用于异步实现相关功能，例如：文件加载、网络请求等
     * false:会同步调用CC.sendCCResult(...),即在onCall方法return之前调用，否则将被视为不合法的实现
     */
    @Override
    public boolean onCall(CC cc) {
        String actionName = cc.getActionName();
        switch (actionName) {
            case  "startMainFragment":
                startHomeMainFragment(cc);
                break;
            case  "startHomeMainActivity":
                startHomeMainActivity(cc);
                break;

        }
        CC.sendCCResult(cc.getCallId(), CCResult.success());
        return false;
    }

    private void startHomeMainFragment(CC cc) {
        HomeMainFragment instance = HomeMainFragment.getInstance();
        CC.sendCCResult(cc.getCallId(), CCResult.success().addData("fragment", instance));

    }

    private void startHomeMainActivity(CC cc) {
//        Context context = cc.getContext();
//        HomeMainActivity.startActivity(context);
        UIModelHelper.startNextAct(cc.getContext(), HomeMainFragment.class.getName());

    }
}
