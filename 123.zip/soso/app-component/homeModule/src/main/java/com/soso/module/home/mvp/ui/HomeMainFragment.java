package com.soso.module.home.mvp.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.soso.module.home.R;
import com.soso.module.home.mvp.contract.HomeMainContract;
import com.soso.module.home.mvp.presenter.HomeMainPresenter;
import com.soso.module.home.mvp.ui.adapter.HomeMainAdapter;
import com.soso.sosolib.utils.LogUtils;
import com.soso.uiactivity.base.fragment.SoSoCommonFragment;
import com.soso.uiwidget.widgets.refresh.OnSoLoadMoreListener;
import com.soso.uiwidget.widgets.refresh.OnSoRefreshListener;
import com.soso.uiwidget.widgets.refresh.SoPullToRefreshView;
import com.soso.uiwidget.widgets.title.ITitleWrapper;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;

/**
 * Created by sumerlin on 2019/2/21 2019/2/21.
 * Describe:
 */
public class HomeMainFragment extends SoSoCommonFragment<HomeMainPresenter> implements HomeMainContract.HomeView {

    private SoPullToRefreshView mSoPullToRefreshView;
    private HomeMainAdapter mHomeMainAdapter;
    private HomeMainPresenter mHomeMainPresenter;

    public static HomeMainFragment getInstance(){
        HomeMainFragment fragment = new HomeMainFragment();
        return fragment;
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.home_activity_main;
    }



    @Override
    protected ITitleWrapper initTitle(View titleView) {
        titleView.setVisibility(View.GONE);
        return new ITitleWrapper() {
            @Override
            public int getTitleBarType() {
                return ITitleWrapper.FLAG_BACK;
            }

            @Override
            public boolean onPageBack(View view) {
                getActivity().finish();
                return false;
            }
        };
    }

    private int pageNo = 0;
    private int pageSize = 20;

    @Override
    protected void initBodyView(View view, @Nullable Bundle savedInstanceState) {
        super.initBodyView(view, savedInstanceState);
        LogUtils.i("========HomeMainFragment===========initBodyView");
        mSoPullToRefreshView = view.findViewById(R.id.soPullToRefreshView);
        mHomeMainAdapter = new HomeMainAdapter();
        mSoPullToRefreshView.setAdapter(mHomeMainAdapter);
        mSoPullToRefreshView.setOnRefreshAndLoadMoreListener(new OnSoRefreshListener() {
            @Override
            public void onRefresh() {
//                getMoniData(true);
                mPresenter.getHomeListDemo(true, pageNo, pageSize);
            }
        }, new OnSoLoadMoreListener() {
            @Override
            public void onLoadMore() {
//                getMoniData(false);
                mPresenter.getHomeListDemo(false, pageNo, pageSize);
            }
        });
        mPresenter = new HomeMainPresenter(this);
        mSoPullToRefreshView.forceRefresh();

    }

    @Override
    public void endRefresh(List<String> data) {
        mSoPullToRefreshView.finishRefresh();
        mHomeMainAdapter.setNewData(data);
        pageNo++;
    }


    @Override
    public void endLoadMore(List<String> data) {
        if (mHomeMainAdapter.getData().size() <= 11) {
            mSoPullToRefreshView.finishLoadMore();
        } else {
            mSoPullToRefreshView.finishLoadMoreWithNoMoreData();
        }
        mHomeMainAdapter.addData(data);
        pageNo++;
    }

    private void getMoniData(boolean isRefresh) {
        List<String> data = new ArrayList<>();
        io.reactivex.Observable.timer(1, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Long>() {
                    @Override
                    public void accept(Long aLong) throws Exception {
//                        LSPostUtil.postCircularLoading(mLoadService);
                        for (int i = 0; i < 5; i++) {
                            data.add("item数据..." + i);
                        }
                        if (isRefresh) {
                            mSoPullToRefreshView.finishRefresh();
                            mHomeMainAdapter.setNewData(data);
                            showSuccess();
                        } else {
                            if (mHomeMainAdapter.getData().size() <= 11) {
                                mSoPullToRefreshView.finishLoadMore();
                            } else {
                                mSoPullToRefreshView.finishLoadMoreWithNoMoreData();
                            }
                            mHomeMainAdapter.addData(data);
                        }

                    }
                });
    }

    @Override
    protected void onReload(View v) {
        super.onReload(v);
        showCircularLoading();
        io.reactivex.Observable.timer(2, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Long>() {
                    @Override
                    public void accept(Long aLong) throws Exception {
//                        LSPostUtil.postCircularLoading(mLoadService);
                        mPresenter.getHomeListDemo(false, pageNo, pageSize);
                    }
                });

    }
}
