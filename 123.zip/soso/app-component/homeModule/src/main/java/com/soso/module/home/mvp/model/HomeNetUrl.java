package com.soso.module.home.mvp.model;

import com.soso.sosoframe.config.BaseNetUrl;

/**
 * Created by sumerlin on 2019/2/19 2019/2/19.
 * Describe:
 */
public interface HomeNetUrl extends BaseNetUrl {
    //GET http://gank.io/api/data/Android/10/1
    String REQ_HOME_LIST = "/api/data/Android/10/1" ;
}
