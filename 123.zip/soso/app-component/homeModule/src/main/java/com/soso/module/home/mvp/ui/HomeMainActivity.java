package com.soso.module.home.mvp.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.soso.module.home.R;
import com.soso.module.home.mvp.presenter.HomeMainPresenter;
import com.soso.sosoframe.base.activity.BaseMvpActivity;


public class HomeMainActivity extends BaseMvpActivity<HomeMainPresenter>{

    public static void startActivity(Context context){
        Intent intent = new Intent(context, HomeMainActivity.class);
        context.startActivity(intent);
    }


    @Override
    public int getLayoutResId(@Nullable Bundle savedInstanceState) {
        return R.layout.home_activity_main;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
