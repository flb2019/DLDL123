package com.soso.module.home.mvp.ui.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.soso.module.home.R;

/**
 * Created by sumerlin on 2019/2/24 2019/2/24.
 * Describe:
 */
public class HomeMainAdapter extends BaseQuickAdapter<String , BaseViewHolder> {

    public HomeMainAdapter() {
        super(R.layout.home_item_main);
    }

    @Override
    protected void convert(BaseViewHolder helper, String item) {
        helper.setText(R.id.text, item);
    }
}
