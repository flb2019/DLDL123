package com.soso.module.home.mvp.contract;

import com.soso.sosoframe.base.mvp.IModel;
import com.soso.uiactivity.mvp.SoSoView;

import java.util.List;

/**
 * Created by sumerlin on 2019/2/19 2019/2/19.
 * Describe:
 */
public interface HomeMainContract {
    interface   HomeView extends SoSoView {
        void endRefresh(List<String> data);
        void endLoadMore(List<String> data);
    }

    interface  HomeModel extends IModel{
        List<String> getHomeListData(int pageNo, int pageSize);
    }
}
