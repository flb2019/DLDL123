package com.soso.module.home.mvp.presenter;

import com.soso.module.home.mvp.contract.HomeMainContract;
import com.soso.module.home.mvp.model.HomeNetUrl;
import com.soso.module.home.mvp.model.bean.GanKIoDataBean;
import com.soso.network.ApiFactory;
import com.soso.network.bean.NetResultData;
import com.soso.network.callback.NetCallback;
import com.soso.network.exception.ErrorMessage;
import com.soso.uiactivity.mvp.SoSoPresenter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

/**
 * Created by sumerlin on 2019/2/19 2019/2/19.
 * Describe:
 */
public class HomeMainPresenter extends SoSoPresenter<HomeMainContract.HomeView> {

    public HomeMainPresenter(HomeMainContract.HomeView homeView ) {
        super(homeView);
    }

    public void getHomeListDemo(boolean isRefresh, int pageNo, int pageSize){
        List<String> data = new ArrayList<>();
        io.reactivex.Observable.timer(1, TimeUnit.SECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Long>() {
                    @Override
                    public void accept(Long aLong) throws Exception {
//                        LSPostUtil.postCircularLoading(mLoadService);
                        for (int i = 0; i < 5; i++) {
                            data.add("item数据..." + i);
                        }
                        if(isRefresh){
                            mRootView.endRefresh(data);
                        }else{
                            mRootView.endLoadMore(data);
                        }

                        mRootView.showSuccess();
                    }
                });
    }


    public void  getHomeList(){
        HashMap<String, Object> paramsMap = new HashMap<>();
        paramsMap.put("type", "Android");
        paramsMap.put("page", 1);
        paramsMap.put("pre_page", 20);
        ApiFactory.getInstance().get(HomeNetUrl.REQ_HOME_LIST, null, new NetCallback<GanKIoDataBean>() {
            @Override
            public void onStart(Disposable disposable) {

            }

            @Override
            public void onSuccess(NetResultData<GanKIoDataBean> netResult) {

            }

            @Override
            public void onError(ErrorMessage error) {

            }
        });

    }
}
