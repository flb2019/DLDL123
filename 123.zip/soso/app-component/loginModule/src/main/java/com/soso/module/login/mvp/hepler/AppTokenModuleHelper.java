package com.soso.module.login.mvp.hepler;

import android.text.TextUtils;

import com.google.gson.JsonElement;
import com.soso.module.login.mvp.model.bean.AccessToken;
import com.soso.module.login.mvp.model.bean.TokenRequestDto;
import com.soso.network.ApiFactory;
import com.soso.network.config.ApiCodeEnum;
import com.soso.network.exception.ApiRequestException;
import com.soso.network.exception.ErrorExceptionUtil;
import com.soso.network.exception.ErrorMessage;
import com.soso.network.tools.JsonParserUtil;
import com.soso.network.tools.LogUtil;
import com.soso.network.tools.ParseUtils;
import com.soso.sosolib.BaseApplication;
import com.soso.sosolib.art.di.component.AppComponent;
import com.soso.sosolib.art.tools.AppComponentUtils;
import com.soso.sosolib.todo.AppInfoModule;
import com.soso.sosolib.todo.AppLoginModule;
import com.soso.sosolib.utils.SPUtil;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Response;

/**
 * Created by sumerlin on 2019/1/15 2019/1/15.
 * Describe: token  保存 ， 或者，一些判断, 底层还是调用ApiConfig， 为了兼容性处理
 * 主要是 网络 请求 相关的 业务处理
 */
public class AppTokenModuleHelper {
    private static long TIME_LENGTH = 2 * 86400000;//2天,提前续约
    public final static String LOGIN_TYPE_CLIENT = "client_credentials";//客户端模式
    public final static String LOGIN_TYPE_REFRESH = "refresh_token";//登录端模式
    public final static String LOGIN_TYPE_PASSWORD = "password";//使用默认登录, 手机号码
    public final static String LOGIN_TYPE_QQ = "qq";
    public final static String LOGIN_TYPE_WECHAT = "wechat";
    public final static String LOGIN_TYPE_MOBILE = "mobile"; //使用手机快速登录
    public final static String LOGIN_TYPE_MOBILE_REGISTER = "mobile"; //使用手机注册登录
    private  AccessToken mAccessToken;
    private static AppInfoModule appInfoModule;
    private static AppLoginModule appLoginModule;
    static {
        AppComponent appComponent = AppComponentUtils.getAppComponent();
        appInfoModule = appComponent.getAppInfoModule();
        appLoginModule = appComponent.getAppLoginModule();
    }

    /****单例模式********************************************************************************/
    private static volatile AppTokenModuleHelper mInstance;

    public static AppTokenModuleHelper getInstance() {
        if (mInstance == null) {
            synchronized (AppTokenModuleHelper.class) {
                if (mInstance == null) {
                    mInstance = new AppTokenModuleHelper();
                }
            }
        }
        return mInstance;
    }

    /****单例模式end********************************************************************************/



    /**
     * 获取AccessToken
     *
     * @return
     */
    public  AccessToken getAppToken() {

        AccessToken appTokenMemory = getAppTokenMemory();
        if(appTokenMemory == null){
            appTokenMemory = getAppTokenSP();
            if (appTokenMemory == null) {
                //内存 和  本地 都没有
            }
        }
        return appTokenMemory;
    }

    public  AccessToken getAppTokenMemory() {
        return this.mAccessToken;
    }

    public  AccessToken getAppTokenSP() {
        return SPUtil.getValue(BaseApplication.getAppContext(), "access_tokenv2", AccessToken.class);
    }

    /**
     * 保存AccessToken 统一入口， 以为要保存创建时的时间， 来计算过期时间
     */
    public  void saveAppToken(AccessToken accessToken) {
        if (accessToken != null) {
            saveAppTokenMemory(accessToken);
            saveAppTokenSP(accessToken);
        }
    }




    public  void saveAppTokenMemory(AccessToken appToken) {
        this.mAccessToken = appToken;
    }

    public   void saveAppTokenSP(AccessToken appToken) {
        if (appToken != null) {
//            this.isRefreshToken = false;
            appToken.setSaveTimeStamp(System.currentTimeMillis());
//            mAccessToken = mAccessToken;
            SPUtil.apply(BaseApplication.getAppContext(), "refresh_token", appToken.getRefreshToken());
            SPUtil.apply(BaseApplication.getAppContext(), "access_tokenv2", appToken);
        }

    }

    public  void clearAccessToken() {
        saveAppToken(new AccessToken());

    }

    public  void logoutUser() {
        clearAccessToken();
//        AccountManager.getInstance().logout();
    }


    /**
     * 判断是否要重新请求 client token
     * 其实client 是 没有refresh_token 的， 当做有来处理， 逻辑模型就跟登录模式refresh_token 一样了， 只需要传递 refresh_token = ""即可
     *
     * @param accessToken
     * @return
     */
    public static boolean isNeedRefreshClientToken(AccessToken accessToken) {
        if (accessToken == null || accessToken.isTokenAdvanceExpireTime()) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * 只针对登录模式是否有， token_refresh 返回值。判断是否 需要刷新
     *
     * @param accessToken
     * @return
     */
    public static boolean isNeedRefreshLoginToken(AccessToken accessToken) {
        //判断是否 需要刷新
        if (accessToken != null && !TextUtils.isEmpty(accessToken.getRefreshToken()) && accessToken.isTokenAdvanceExpireTime()) {
            //需要
            return true;
        } else {
            //不需要 ， 就保存
            return false;
        }
    }


    /**
     * Unauthorized  401  业务逻辑判断
     *
     * @return null就跳转到 登录页面， 否则返回RequestTokenDto， 根据
     * 刷新token 模式，{@link AppTokenModuleHelper#LOGIN_TYPE_CLIENT}
     */
    public TokenRequestDto getUnauthorizedTokenGrantType() {
//        return "password";
//        return "refresh_token";
//        return "client_credentials";
        TokenRequestDto tokenRequestDto = null;
        boolean isLogin = appLoginModule.isLogin();
        AccessToken accessToken = getAppToken();
        //有登录过。密码、qq、 微信
        if (isLogin) {
            //判断是否需要刷新
            if (accessToken != null && isNeedRefreshLoginToken(accessToken)) {
                tokenRequestDto = TokenRequestDto.createRefreshDto(accessToken.getRefreshToken());
            } else if (isNeedRefreshClientToken(accessToken)) {
                ////没有就以客户端形式 获取token
                tokenRequestDto = TokenRequestDto.createClientDto("");
            } else {
                // 有登录， 又不需要刷新token， 那就直接跳转登录界面
                tokenRequestDto = null;
            }

        } else {
            //没有登录信息， 就判断是否需要刷新
            if (accessToken == null) {
                //没有就以客户端形式 获取token
                tokenRequestDto = TokenRequestDto.createClientDto("");
            } else if (isNeedRefreshLoginToken(accessToken)) {
                //需要刷新
                tokenRequestDto = TokenRequestDto.createRefreshDto(accessToken.getRefreshToken());
            } else {
                // 没有登录， 又不需要刷新token， 那就直接跳转登录
                tokenRequestDto = null;
            }
        }

        return tokenRequestDto;
    }

    public interface OnTokenListen {
        default String onTokenStart(Disposable d) {
            return null;
        }

        void onTokenSuccess(AccessToken accessToken);

        void onTokenError(ErrorMessage error);
    }


    /**
     * 启动app 调用该方法去检查获取token
     * 逻辑：【1】获取本地，有，检查是否需要刷新；【2】没有，直接去获取，  【3】 不需要刷新 也会走 onTokenSuccess（）方法
     *
     * @param onTokenListen
     */
    public  void requestNetTokenWhenAppStart(OnTokenListen onTokenListen) {
        //获取本地token
        LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
        String name = Thread.currentThread().getName();
        AccessToken accessToken = getAppTokenSP();
        TokenRequestDto tokenRequestDto = null;
        if (accessToken == null) {
            //【1】为null， 直接走客户端模式
            tokenRequestDto = TokenRequestDto.createClientDto("");
            requestNetTokenOrRefresh(tokenRequestDto, onTokenListen);
        } else {
            //【2】有token， 判断是否需要续约刷新
            if (AppTokenModuleHelper.isNeedRefreshLoginToken(accessToken)) {
                //【2-1】登录模式过期了，需要刷新， 直接走刷新
                tokenRequestDto = TokenRequestDto.createRefreshDto(accessToken.getRefreshToken());
                requestNetTokenOrRefresh(tokenRequestDto, onTokenListen);
            } else if (AppTokenModuleHelper.isNeedRefreshClientToken(accessToken)) {
                //【2-2】客户端模式过期了， 直接走客户端模式
                tokenRequestDto = TokenRequestDto.createClientDto("");
                requestNetTokenOrRefresh(tokenRequestDto, onTokenListen);
            } else {
                //不需要刷新
                if (onTokenListen != null) {
                    onTokenListen.onTokenSuccess(accessToken);
                }
            }

        }

    }

    /**
     * 走网络，获取登录模式token：手机密码模式、QQ模式、微信模式
     *
     * @param tokenRequestDto
     * @param onTokenListen
     */
    public  void requestNetLoginToken(TokenRequestDto tokenRequestDto,OnTokenListen onTokenListen) {
        if (tokenRequestDto == null) {
            onTokenListen.onTokenError(new ErrorMessage("token请求异常"));
            return;

        }
        // TODO: 2019/1/18 检查网络

        Observable<Response<JsonElement>> tokenObservable = null;
        switch (tokenRequestDto.getGrantType()) {
            case LOGIN_TYPE_PASSWORD:
                tokenObservable = ApiFactory.getInstance()
                        .getSingletonRetrofitFactory()
                        .getRetrofitService()
                        .login(LOGIN_TYPE_PASSWORD,
                                appInfoModule.getClientKey(),
                                appInfoModule.getClientSecret(),
                                tokenRequestDto.getUsername(),
                                tokenRequestDto.getPassword(),
                                "");
                break;

            case LOGIN_TYPE_QQ:
                tokenObservable = ApiFactory.getInstance()
                        .getSingletonRetrofitFactory()
                        .getRetrofitService()
                        .qqLogin(LOGIN_TYPE_QQ,
                                appInfoModule.getClientKey(),
                                appInfoModule.getClientSecret(),
                                tokenRequestDto.getAccessTokenQQ());

                break;

            case LOGIN_TYPE_WECHAT:

                tokenObservable = ApiFactory.getInstance()
                        .getSingletonRetrofitFactory()
                        .getRetrofitService()
                        .wxLogin(LOGIN_TYPE_WECHAT,
                                appInfoModule.getClientKey(),
                                appInfoModule.getClientSecret(),
                                tokenRequestDto.getWechatCode());

                break;

        }

        if (tokenObservable == null) {
            onTokenListen.onTokenError(new ErrorMessage("token请求异常"));
            return;
        }
        tokenObservable.map(new Function<Response<JsonElement>, AccessToken>() {
            @Override
            public AccessToken apply(Response<JsonElement> jsonElementResponse) throws Exception {
                //请求200 才会进来这里
                AccessToken accessToken = null;
                if (jsonElementResponse != null && jsonElementResponse.body() != null) {
                    //请求成200. 但是否有错误信息
                    String error = JsonParserUtil.getStringResult(jsonElementResponse.body(), "error");
                    if (!TextUtils.isEmpty(error)) {
                        //有错误信息
                        ErrorExceptionUtil.throwException(new ApiRequestException(ApiCodeEnum.Success.getId(), error));
                    } else {

                    }
                    accessToken = ParseUtils.parseJsonElement(jsonElementResponse.body(), AccessToken.class, "");
                    //保存session
                    if (!TextUtils.isEmpty(accessToken.getAccessToken())) {
                        saveAppToken(accessToken);
                    } else {
                        ErrorExceptionUtil.throwException(new ApiRequestException(ApiCodeEnum.Success.getId(), error));
                    }
                }
                return accessToken;
            }
        })

                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<AccessToken>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        if (onTokenListen != null) {
                            onTokenListen.onTokenStart(d);
                        }
                    }

                    @Override
                    public void onNext(AccessToken accessToken) {
                        if (onTokenListen != null) {
                            onTokenListen.onTokenSuccess(accessToken);
                        }

                    }

                    @Override
                    public void onError(Throwable e) {
                        if (onTokenListen != null) {
                            ApiRequestException error = ErrorExceptionUtil.parserException(e);
                            onTokenListen.onTokenError(new ErrorMessage(error.getErrorCode(), error.getErrorMsg()));
                        }

                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    /**
     * 请求 token 方法, 包括客户端token、刷新token， 走该方法
     *
     * @param tokenRequestDto
     * @param onTokenListen
     */
    public  void requestNetTokenOrRefresh(TokenRequestDto tokenRequestDto, OnTokenListen onTokenListen) {
        if (tokenRequestDto == null) {
            if (onTokenListen != null) {
                onTokenListen.onTokenError(new ErrorMessage("token请求异常"));
            }
            return;
        }
        ApiFactory.getInstance().getSingletonRetrofitFactory().getRetrofitService()
                .getToken(tokenRequestDto.getGrantType(), tokenRequestDto.getClientId(), tokenRequestDto.getClientSecret(), tokenRequestDto.getRefreshToken())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
//                .retryWhen(new EmptyChainLoader.RetryWithDelay(1, 2000))

                .subscribe(new Observer<Response<JsonElement>>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        if (onTokenListen != null) {
                            onTokenListen.onTokenStart(d);
                        }

                    }

                    @Override
                    public void onNext(Response<JsonElement> response) {
                        //接受到新的token, 内存 和 sp保存一份
                        //解析 和 保存
                        AccessToken accessToken = null;
                        JsonElement body = response.body();
                        // TODO: 2019/1/12 为空发出异常出来
                        if (response != null && response.body() != null) {
                            //请求成200. 但是否有错误信息
                            String error = JsonParserUtil.getStringResult(response.body(), "error");
                            if (!TextUtils.isEmpty(error)) {
                                //有错误信息, 当异常处理
                                if (onTokenListen != null) {
                                    onTokenListen.onTokenError(new ErrorMessage(ApiCodeEnum.Success.getId(), error));
                                }
                            } else {
                                accessToken = ParseUtils.parseJsonElement(body, AccessToken.class, "");
                                if (accessToken != null) {
                                    if (!TextUtils.isEmpty(accessToken.getAccessToken())) {
                                        saveAppToken(accessToken);
                                        if (onTokenListen != null) {
                                            onTokenListen.onTokenSuccess(accessToken);
                                        }
                                    }
                                } else {
                                    if (onTokenListen != null) {
                                        onTokenListen.onTokenError(new ErrorMessage(ApiCodeEnum.No_Authorized.getId(), ApiCodeEnum.No_Authorized.getName()));
                                    }
                                }
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        if (onTokenListen != null) {
                            ApiRequestException error = ErrorExceptionUtil.parserException(e);
                            onTokenListen.onTokenError(new ErrorMessage(error.getErrorCode(), error.getErrorMsg()));
                        }

                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }
}

