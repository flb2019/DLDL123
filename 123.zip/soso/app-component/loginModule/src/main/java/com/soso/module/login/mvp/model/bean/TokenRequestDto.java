package com.soso.module.login.mvp.model.bean;

import com.soso.sosolib.art.tools.AppComponentUtils;
import com.soso.sosolib.todo.AppInfoModule;

/**
 * Created by sumerlin on 2019/1/15 2019/1/15.
 * Describe:
 */
public class TokenRequestDto {
    private static long TIME_LENGTH = 2 * 86400000;//2天,提前续约
    public final static String LOGIN_TYPE_CLIENT = "client_credentials";//客户端模式
    public final static String LOGIN_TYPE_REFRESH = "refresh_token";//登录端模式
    public final static String LOGIN_TYPE_PASSWORD = "password";//使用默认登录, 手机号码
    public final static String LOGIN_TYPE_QQ = "qq";
    public final static String LOGIN_TYPE_WECHAT = "wechat";
    public final static String LOGIN_TYPE_MOBILE = "mobile"; //使用手机快速登录
    public final static String LOGIN_TYPE_MOBILE_REGISTER = "mobile"; //使用手机注册登录

    private String grantType;//@Field("grant_type")
    private static String clientId;// @Field("client_id")
    private static String clientSecret; //@Field("client_secret")
    private String refreshToken = "";//@Field("refresh_token")
    private String accessTokenQQ;// @Field("access_token") qq登录
    private String wechatCode;// @Field("access_token") 微信登录

    static {
        AppInfoModule appInfoConfig = AppComponentUtils.getAppComponent().getAppInfoModule();
        clientId = appInfoConfig.getClientKey();
        clientSecret = appInfoConfig.getClientSecret();

    }


    //
    private String username;
    private String password;

    private TokenRequestDto() {
    }


    /**
     * client客户端模式， 和  刷新模式
     *
     * @param refreshToken
     * @return
     */
    public static TokenRequestDto createClientDto(String refreshToken) {
//        grant_type:client_credentials
//        client_id:myawesomeapp
//        client_secret:password
        TokenRequestDto tokenRequestDto = new TokenRequestDto();
        tokenRequestDto.setGrantType(TokenRequestDto.LOGIN_TYPE_CLIENT);
        return tokenRequestDto;

    }

    public static TokenRequestDto createRefreshDto(String refreshToken) {
//        grant_type:client_credentials
//        client_id:myawesomeapp
//        client_secret:password
        TokenRequestDto tokenRequestDto = new TokenRequestDto();
        tokenRequestDto.setGrantType(TokenRequestDto.LOGIN_TYPE_REFRESH);
        tokenRequestDto.setRefreshToken(refreshToken);
        return tokenRequestDto;

    }

    /**
     * 用户密码模式
     *
     * @param username
     * @param password
     * @return
     */
    public static TokenRequestDto createLoginPwdDto(String username, String password) {
//        client_id:myawesomeapp
//        client_secret:password
//        username:molimoq
//        password:password
        TokenRequestDto tokenRequestDto = new TokenRequestDto();
        tokenRequestDto.setGrantType(TokenRequestDto.LOGIN_TYPE_PASSWORD);
        tokenRequestDto.setUsername(username);
        tokenRequestDto.setPassword(password);
        return tokenRequestDto;

    }

    /**
     * QQ模式
     *
     * @param clientId
     * @param clientSecret
     * @param access_token
     * @return
     */
    public static TokenRequestDto createLoginQQDto(String clientId, String clientSecret, String access_token) {
//        grant_type:qq
//        client_id:myawesomeapp
//        client_secret:abc123
//        access_token:4E338C9700B3CAEE6017C15001BB7ACD
        TokenRequestDto tokenRequestDto = new TokenRequestDto();
        tokenRequestDto.setGrantType(TokenRequestDto.LOGIN_TYPE_QQ);
        tokenRequestDto.setAccessTokenQQ(access_token);
        return tokenRequestDto;
    }

    /**
     * Wechat 微信模式
     *
     * @param clientId
     * @param clientSecret
     * @param code
     * @return
     */
    public static TokenRequestDto createLoginWechatDto(String clientId, String clientSecret, String code) {
//        grant_type:wechat
//        client_id:myawesomeapp
//        client_secret:abc123
//        code:E338C9700B3CAEE6017C15001BB7ACD
        TokenRequestDto tokenRequestDto = new TokenRequestDto();
        tokenRequestDto.setGrantType(TokenRequestDto.LOGIN_TYPE_WECHAT);
        tokenRequestDto.setWechatCode(code);
        return tokenRequestDto;

    }


    public String getGrantType() {
        return grantType;
    }

    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    public String getClientId() {
        return clientId;
    }


    public String getClientSecret() {
        return clientSecret;
    }


    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getAccessTokenQQ() {
        return accessTokenQQ;
    }

    public void setAccessTokenQQ(String accessTokenQQ) {
        this.accessTokenQQ = accessTokenQQ;
    }

    public String getWechatCode() {
        return wechatCode;
    }

    public void setWechatCode(String wechatCode) {
        this.wechatCode = wechatCode;
    }
}
