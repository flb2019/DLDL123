package com.soso.module.login.mvp;

/**
 * Created by sumerlin on 2019/2/20 2019/2/20.
 * Describe:
 */
public class AA {
}
