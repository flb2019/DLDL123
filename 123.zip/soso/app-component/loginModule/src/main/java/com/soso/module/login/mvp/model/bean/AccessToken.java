package com.soso.module.login.mvp.model.bean;

import com.soso.sosolib.bean.AppToken;

/**
 * Created by sumerlin on 2019/2/20 2019/2/20.
 * Describe:
 */
public class AccessToken extends AppToken {
}
