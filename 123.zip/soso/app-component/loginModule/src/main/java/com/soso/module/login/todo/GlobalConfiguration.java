package com.soso.module.login.todo;

import android.app.Application;
import android.content.Context;
import android.support.v4.app.FragmentManager;

import com.soso.sosolib.art.base.delegate.AppLifecycles;
import com.soso.sosolib.art.di.module.GlobalConfigModule;
import com.soso.sosolib.art.integration.ConfigModule;

import java.util.List;

/**
 * Created by sumerlin on 2019/2/20 2019/2/20.
 * Describe: 登录模块 单独配置
 */
public class GlobalConfiguration implements ConfigModule {


    @Override
    public void applyOptions(Context context, GlobalConfigModule.Builder builder) {
        builder.baseurl("https://api.eelly.com")
                .setAppTokenModule(AppTokenModuleImpl.getInstance())
                .setAppLoginModule(AppLoginModuleImpl.getInstance());
    }

    @Override
    public void injectAppLifecycle(Context context, List<AppLifecycles> lifecycles) {

    }

    @Override
    public void injectActivityLifecycle(Context context, List<Application.ActivityLifecycleCallbacks> lifecycles) {

    }

    @Override
    public void injectFragmentLifecycle(Context context, List<FragmentManager.FragmentLifecycleCallbacks> lifecycles) {

    }
}
