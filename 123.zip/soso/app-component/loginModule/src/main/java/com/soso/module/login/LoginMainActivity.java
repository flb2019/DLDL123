package com.soso.module.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class LoginMainActivity extends AppCompatActivity {

    private String mCallId;

    public  static void  startActivity(Context context, String callId){
        Intent intent = new Intent(context, LoginMainActivity.class);
        intent.putExtra("callId", callId);
        context.startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity_main);
        mCallId = getIntent().getStringExtra("callId");
    }
}
