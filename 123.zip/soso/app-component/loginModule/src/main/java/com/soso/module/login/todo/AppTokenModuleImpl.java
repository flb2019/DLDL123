package com.soso.module.login.todo;

import com.soso.module.login.mvp.hepler.AppTokenModuleHelper;
import com.soso.module.login.mvp.model.bean.AccessToken;
import com.soso.sosolib.todo.AppTokenModule;
import com.soso.sosolib.todo.TokenRefreshChainLoader;

/**
 * Created by sumerlin on 2019/2/20 2019/2/20.
 * Describe:
 */
public class AppTokenModuleImpl implements AppTokenModule<AccessToken> {
    /****单例模式********************************************************************************/
    private static volatile AppTokenModuleImpl mInstance;

    public static AppTokenModuleImpl getInstance() {
        if (mInstance == null) {
            synchronized (AppTokenModuleImpl.class) {
                if (mInstance == null) {
                    mInstance = new AppTokenModuleImpl();
                }
            }
        }
        return mInstance;
    }


    private AppTokenModuleImpl() {
    }

    /****单例模式end********************************************************************************/

    @Override
    public AccessToken getAppToken() {
        return AppTokenModuleHelper.getInstance().getAppToken();
    }
    @Override
    public AccessToken getAppTokenMemory() {
        return  AppTokenModuleHelper.getInstance().getAppTokenMemory();
    }

    @Override
    public AccessToken getAppTokenSP() {
        return  AppTokenModuleHelper.getInstance().getAppTokenSP();
    }

    @Override
    public void saveAppToken(AccessToken appToken) {
          AppTokenModuleHelper.getInstance().saveAppToken(appToken);
    }

    @Override
    public void saveAppTokenMemory(AccessToken appToken) {
         AppTokenModuleHelper.getInstance().saveAppTokenMemory(appToken);
    }

    @Override
    public void saveAppTokenSP(AccessToken appToken) {
         AppTokenModuleHelper.getInstance().saveAppTokenSP(appToken);

    }

    @Override
    public void cleanAppToken() {
         AppTokenModuleHelper.getInstance().clearAccessToken();
    }

    @Override
    public TokenRefreshChainLoader getTokenChainLoader() {
        return TokenChainLoaderImpl.getInstance();
    }
}
