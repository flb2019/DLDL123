package com.soso.module.login.component;

import android.text.TextUtils;

import com.billy.cc.core.component.CC;
import com.billy.cc.core.component.CCResult;
import com.billy.cc.core.component.IComponent;
import com.soso.module.login.mvp.hepler.AppTokenModuleHelper;
import com.soso.module.login.mvp.model.bean.AccessToken;
import com.soso.network.exception.ErrorMessage;

/**
 * Created by sumerlin on 2019/2/20 2019/2/20.
 * Describe:
 */
public class LoginComponent implements IComponent {

    @Override
    public String getName() {
        return "LoginComponent";
    }

    @Override
    public boolean onCall(CC cc) {
        String actionName = cc.getActionName();
        switch (actionName) {
            case "requestNetTokenWhenAppStart":
                ////true不立即获取, 等待 cc返回结果，直到超时
//                return requestNetTokenWhenAppStart(cc);
//            LoginMainActivity.startActivity(cc.getContext(), cc.getCallId());
                requestNetTokenWhenAppStart(cc);
                return true;

        }

        return false;
    }

    private void requestNetTokenWhenAppStart(CC cc) {

//        LoginMainActivity.startActivity(cc.getContext());
        AppTokenModuleHelper.getInstance().requestNetTokenWhenAppStart(new AppTokenModuleHelper.OnTokenListen() {
            @Override
            public void onTokenSuccess(AccessToken accessToken) {
                CCResult result = CCResult.success().addData("loginType", 200);
                String callId = cc.getCallId();
                if (!TextUtils.isEmpty(callId)) {
                    CC.sendCCResult(callId, result);
                }
            }

            @Override
            public void onTokenError(ErrorMessage error) {

            }
        });


//        request(cc);

        //获取本地token
//        LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//        String name = Thread.currentThread().getName();
//        AccessToken accessToken = AccessTokenHelper.getAccessTokenSP();
//        TokenRequestDto tokenRequestDto = null;
//
//        AccessTokenModule.OnTokenListen onTokenListen =   new AccessTokenModule.OnTokenListen() {
//            @Override
//            public void onTokenSuccess(AccessToken accessToken) {
//                CCResult result = CCResult.success().addData("loginType", 200);
//                String callId = cc.getCallId();
//                if (!TextUtils.isEmpty(callId)) {
//                    CC.sendCCResult(callId, result);
//                }
//            }
//
//            @Override
//            public void onTokenError(ErrorMessage error) {
//
//            }
//        };
//
//        if (accessToken == null) {
//            //【1】为null， 直接走客户端模式
//            tokenRequestDto = TokenRequestDto.createClientDto("");
//            AccessTokenModule.requestNetTokenOrRefresh(tokenRequestDto, onTokenListen);
//        } else {
//            //【2】有token， 判断是否需要续约刷新
//            if (AccessTokenHelper.isNeedRefreshLoginToken(accessToken)) {
//                //【2-1】登录模式过期了，需要刷新， 直接走刷新
//                tokenRequestDto = TokenRequestDto.createRefreshDto(accessToken.getRefreshToken());
//                AccessTokenModule.requestNetTokenOrRefresh(tokenRequestDto, onTokenListen);
//            } else if (AccessTokenHelper.isNeedRefreshClientToken(accessToken)) {
//                //【2-2】客户端模式过期了， 直接走客户端模式
//                tokenRequestDto = TokenRequestDto.createClientDto("");
//                AccessTokenModule.requestNetTokenOrRefresh(tokenRequestDto, onTokenListen);
//            } else {
//                //不需要刷新
//                if (onTokenListen != null) {
//                    onTokenListen.onTokenSuccess(accessToken);
//                }
//            }
//
//        }
//        CCResult result = CCResult.success().addData("loginType", 200);
//        String callId = cc.getCallId();
//        if (!TextUtils.isEmpty(callId)) {
//            CC.sendCCResult(callId, result);
//        }
//
//        return true;
    }

}
