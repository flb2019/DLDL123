package com.soso.module.login.todo;

import com.soso.sosolib.todo.AppLoginModule;

/**
 * Created by sumerlin on 2019/2/20 2019/2/20.
 * Describe:
 */
public class AppLoginModuleImpl implements AppLoginModule {
    /****单例模式********************************************************************************/
    private static volatile AppLoginModuleImpl mInstance;

    public static AppLoginModuleImpl getInstance() {
        if (mInstance == null) {
            synchronized (AppLoginModuleImpl.class) {
                if (mInstance == null) {
                    mInstance = new AppLoginModuleImpl();
                }
            }
        }
        return mInstance;
    }

    /****单例模式end********************************************************************************/

    @Override
    public boolean isLogin() {
        return false;
    }

    @Override
    public boolean isNeedReLoginCall() {
        return false;
    }

    @Override
    public void callAsyncLoginActivity() {

    }

    @Override
    public void reLoginCall(AppLoginModule.OnReLoginListen onReLoginListen) {

    }
}
