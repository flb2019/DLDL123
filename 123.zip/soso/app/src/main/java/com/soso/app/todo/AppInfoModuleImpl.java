package com.soso.app.todo;

import com.soso.app.BuildConfig;
import com.soso.app.DemoApplication;
import com.soso.sosolib.todo.AppInfoModule;
import com.soso.sosolib.utils.AppUtils;

/**
 * Created by sumerlin on 2019/2/20 2019/2/20.
 * Describe:
 */
public class AppInfoModuleImpl implements AppInfoModule {

    /**
     * 店+环境的帐号
     */
    private static final String CLIENT_KEY_BUYER_TEST = "5b61190269d76914ca61cd81";
    private static final String CLIENT_SECRET_BUYER_TEST = "GvmM58CUCmv3+Jm6Z3aWOx4ddqG+d9Wc";

    private static final String CLIENT_KEY_BUYER_LOCAL = "5b71588a42046b66ac3eef11";
    private static final String CLIENT_SECRET_BUYER_LOCAL = "N0t+/lmjlb1jztQ372eH7INK9DG3iJOo";

    private static final String CLIENT_KEY_BUYER_ONLINE = "5b715aef710455af0a59d991";
    private static final String CLIENT_SECRET_BUYER_ONLINE = "tmjIZUkSYMjlvl2rufXJd2Nvf9eVbpEQ";
    /****单例模式********************************************************************************/
    private static volatile AppInfoModuleImpl mInstance;

    public static AppInfoModuleImpl getInstance() {
        if (mInstance == null) {
            synchronized (AppInfoModuleImpl.class) {
                if (mInstance == null) {
                    mInstance = new AppInfoModuleImpl();
                }
            }
        }
        return mInstance;
    }

    /****单例模式end********************************************************************************/

    @Override
    public String getAppVersion() {
        return BuildConfig.VERSION_CODE + "";
    }

    @Override
    public String getClient() {
        return "buyer";
    }

    @Override
    public String getIMEI() {
        return AppUtils.getIMEI(DemoApplication.getAppContext());
    }

    @Override
    public String getClientKey() {
        String netConfig = "";
        if ("test".equals(netConfig)) {
            return CLIENT_KEY_BUYER_TEST;
        } else if ("cn".equals(netConfig)) {
            return CLIENT_KEY_BUYER_LOCAL;
        } else {
            return CLIENT_KEY_BUYER_ONLINE;
        }
    }

    @Override
    public String getClientSecret() {
        String netConfig = "";
        if ("test".equals(netConfig)) {
            return CLIENT_SECRET_BUYER_TEST;
        } else if ("cn".equals(netConfig)) {
            return CLIENT_SECRET_BUYER_LOCAL;
        } else {
            return CLIENT_SECRET_BUYER_ONLINE;
        }
    }

    @Override
    public String getApiHost() {
//        if (isOnline(environment)) {
//            return "https://api.eelly.com";
//        } else {
//            return isLocal(environment) ? "https://api.eelly.cn" : "https://api.eelly.test";
//        }
        return "https://api.eelly.com";
    }

//
//    @Override
//    public TokenRequestDto getUnauthorizedTokenGrantType() {
//        return null;
//    }







//    public static String getNetEnvironment(Context context) {
//        SharedPreferences sp = context.getSharedPreferences("AppConfig", 0);
//        return sp.getString("NetEnvironment", defaultNetEnvironment);
//    }
//
//    public static void setNetEnvironment(Context context, String environment) {
//        SharedPreferences sp = context.getSharedPreferences("AppConfig", 0);
//        String net = sp.getString("NetEnvironment", "");
//        if (!net.equals(environment)) {
//            ApiConfig.getInstant().saveAccessToken((AccessToken)null);
//        }
//
//        SharedPreferences.Editor editor = sp.edit();
//        editor.putString("NetEnvironment", environment);
//        editor.commit();
//    }
}
