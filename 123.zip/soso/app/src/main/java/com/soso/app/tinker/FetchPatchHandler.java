//package com.soso.app.tinker;
//
//import android.os.Handler;
//import android.os.Message;
//
///**
// * Created by sumerlin on 2019/3/19 2019/3/19.
// * Describe:
// */
//public class FetchPatchHandler extends Handler {
//
//    public static final long HOUR_INTERVAL = 3600 * 1000;
//    private long checkInterval;
//
//
//    /**
//     * 通过handler, 达到按照时间间隔轮训的效果
//     */
//    public void fetchPatchWithInterval(int hour) {
//        //设置TinkerPatch的时间间隔
//        TinkerPatch.with().setFetchPatchIntervalByHours(hour);
//        checkInterval = hour * HOUR_INTERVAL;
//        //立刻尝试去访问,检查是否有更新
//        sendEmptyMessage(0);
//    }
//
//
//    @Override
//    public void handleMessage(Message msg) {
//        super.handleMessage(msg);
//        //这里使用false即可
//        TinkerPatch.with().fetchPatchUpdate(false);
//        //每隔一段时间都去访问后台, 增加10分钟的buffer时间
//        sendEmptyMessageDelayed(0, checkInterval + 10 * 60 * 1000);
//    }
//}