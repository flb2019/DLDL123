package com.soso.app;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.billy.cc.core.component.CC;
import com.soso.common.BaseCommonApplication;
import com.soso.sosolib.utils.AppUtils;
import com.soso.sosolib.utils.LogUtils;
import com.tencent.bugly.Bugly;
import com.tencent.bugly.beta.Beta;
import com.tencent.bugly.beta.interfaces.BetaPatchListener;

import java.util.Locale;

/**
 * Created by sumerlin on 2019/2/19 2019/2/19.
 * Describe:
 */
public class DemoApplication extends BaseCommonApplication {
    private static final String TAG_SOSO_DEBUG = "TAG_SOSO_DEBUG";

    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        // 安装tinker
        // 此接口仅用于反射Application方式接入。
        Beta.installTinker();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        LogUtils.i("DemoApplication.....GlobalConfiguration.....injectAppLifecycle...........onCreate");
        intiLogger(AppUtils.isAppDebug(this));
        CC.init(this);
        CC.enableVerboseLog(true);
        CC.enableDebug(true);
        //跨app调用支持：debug时启用，release时禁用,BuildConfig.DEBUG
        CC.enableRemoteCC(false);
        initTinker();



    }
    private void initTinker() {
        //这里实现SDK初始化，appId为自己申请的appId
        //同时在调试时将第3个参数isDebug修改为true
        //是否提示用户重启，这里默认设置为false
        /**/
        //是否开启热更新能力，默认为true
        Beta.enableHotfix = true;
        //是否开启自动下载补丁，默认为true
        Beta.canAutoDownloadPatch = true;
        //是否自动合成补丁，默认为true
        Beta.canAutoPatch = true;
        //是否提示用户重启，这里默认设置为false
        Beta.canNotifyUserRestart = true;
        //补丁回调接口
        Beta.betaPatchListener = new BetaPatchListener() {
            @Override
            public void onPatchReceived(String s) {
                Log.e(TAG_SOSO_DEBUG, "补丁下载地址：" + s);
            }

            @Override
            public void onDownloadReceived(long l, long l1) {
                Log.e(TAG_SOSO_DEBUG, String.format(Locale.getDefault(), "%s %d%%",
                        Beta.strNotificationDownloading,
                        (int) (l1 == 0 ? 0 : l * 100 / l1)));
            }

            @Override
            public void onDownloadSuccess(String s) {
                Log.e(TAG_SOSO_DEBUG, "补丁下载成功");
                Toast.makeText(getApplicationContext(), "补丁下载成功", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onDownloadFailure(String s) {
                Log.e(TAG_SOSO_DEBUG, "补丁下载失败");
                Toast.makeText(getApplicationContext(), "补丁下载失败", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onApplySuccess(String s) {
                Log.e(TAG_SOSO_DEBUG, "补丁应用成功");
                Toast.makeText(getApplicationContext(), "补丁应用成功", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onApplyFailure(String s) {
                Log.e(TAG_SOSO_DEBUG, "补丁应用失败");
                Toast.makeText(getApplicationContext(), "补丁应用失败", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPatchRollback() {

            }
        };

        //设置开发设备，默认为false，上传补丁如果下发范围指定为“开发设备”，需要调用此接口来标识开发设备
        Bugly.setIsDevelopmentDevice(getApplicationContext(), true);
        // 多渠道需求塞入
        // String channel = WalleChannelReader.getChannel(getApplication());
        // Bugly.setAppChannel(getApplication(), channel);
        // 这里实现SDK初始化，appId替换成你的在平台申请的appId
        Bugly.init(getApplicationContext(), "c1156491db", true);

    }

    private void intiLogger(boolean isDebug) {
        new LogUtils.Builder()
                .setLogSwitch(isDebug)// 设置log总开关， 默认开， dubug 时打开
                .setGlobalTag(TAG_SOSO_DEBUG)// 设置log全局标签，默认为空
                // 当全局标签不为空时，我们输出的log全部为该tag，
                // 为空时，如果传入的tag为空那就显示类名，否则显示tag
                .setLog2FileSwitch(false)// 打印log时是否存到文件的开关，默认关
                .setBorderSwitch(true)   // 输出日志是否带边框开关，默认开
                .setLogFilter(LogUtils.V);// log过滤器，和logcat过滤器同理，默认Verbose
    }

//    /**
//     * 捕获全局异常
//     */
//    private void initCrashHandlerManager(Application application) {
//        AnalysisAgent.initialize(application, BuildConfig.Channel, false, new GtCrashListener() {
//            @Override
//            public void gtCrashInfo(Throwable ex) {
//                if (!BuildConfig.LOG_DEBUG) {
//
//                    Context context = application;
//                    Intent intent = new Intent(context, MainActivity.class);
//                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
//                    context.startActivity(intent);
//                    System.exit(0);
//                }
//
//            }
//        }, BuildConfig.LOG_DEBUG);
//
//    }


}

