package com.soso.app;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;

import com.billy.cc.core.component.CC;
import com.billy.cc.core.component.CCResult;
import com.soso.sosoframe.base.activity.BaseMvpActivity;
import com.soso.uiwidget.widgets.tabLayout.SoTabLayout;
import com.soso.uiwidget.widgets.viewPage.SoViewPager;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sumerlin on 2019/2/24 2019/2/24.
 * Describe:
 */
public class MainActivity extends BaseMvpActivity {
    private SoTabLayout mTabTl;
    private SoViewPager mContentVp;

    private ContentPagerAdapter contentAdapter;

    @Override
    public int getLayoutResId(@Nullable Bundle savedInstanceState) {
        return R.layout.activity_main;
    }

    @Override
    public void initView(@Nullable Bundle savedInstanceState) {
        super.initView(savedInstanceState);
//        findViewById(R.id.btn_share).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                CCResult call = CC.obtainBuilder("ShareComponent")
//                        .setActionName("openShareDialog")
//                        .setContext(MainActivity.this)
//                        .build()
//                        .call();
//                Object dataItem = call.getDataItem("11");
//            }
//        });
        mTabTl = (SoTabLayout) findViewById(R.id.soTabLayout);
        mContentVp = (SoViewPager) findViewById(R.id.soViewPager);
        initContent();
        initTab();

    }


    private void initTab() {
        mTabTl.setTabMode(TabLayout.MODE_SCROLLABLE);
        mTabTl.setTabTextColors(ContextCompat.getColor(this, R.color.gray_33), ContextCompat.getColor(this, R.color.orange));
        mTabTl.setSelectedTabIndicatorColor(ContextCompat.getColor(this, R.color.white));
        mTabTl.setTabMode(TabLayout.MODE_FIXED);
        ViewCompat.setElevation(mTabTl, 10);
        mTabTl.setupWithViewPager(mContentVp);
        mContentVp.setSmoothScroll(false);
        mContentVp.setScrollable(false);
    }

    private List<String> tabIndicators;
    private List<Fragment> tabFragments;

    private void initContent() {
        tabIndicators = new ArrayList<>();
        tabIndicators.add("主页22222");
        tabIndicators.add("消息");
        tabIndicators.add("个人中心");
        tabFragments = new ArrayList<>();
        for (int i = 0; i < tabIndicators.size(); i++) {
            tabFragments.add(createFragment(i));
        }
        contentAdapter = new ContentPagerAdapter(getSupportFragmentManager());
        mContentVp.setAdapter(contentAdapter);
        mContentVp.setOffscreenPageLimit(3);
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_tab_layout, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.tab_add:
//                tabIndicators.add("Tab " + tabIndicators.size());
//                tabFragments.add(TabContentFragment.newInstance(tabIndicators.get(tabIndicators.size()-1)));
//                contentAdapter.notifyDataSetChanged();
//                return true;
//
//            case R.id.tab_mode_fixed:
//                mTabTl.setTabMode(TabLayout.MODE_FIXED);
//                return true;
//
//            case R.id.tab_mode_scrollable:
//                mTabTl.setTabMode(TabLayout.MODE_SCROLLABLE);
//                break;
//        }
//        return super.onOptionsItemSelected(item);
//    }

    private Fragment createFragment(int position) {
        Fragment fragment = null;
        if (tabFragments != null && tabFragments.size() > 0 && tabFragments.size() > position && tabFragments.get(position) != null) {
            return tabFragments.get(position);
        }

        CCResult call = null;
        switch (position) {
            case 0:
                call = CC.obtainBuilder("HomeComponent").setContext(this).setActionName("startMainFragment").build().call();
                fragment = call.getDataItem("fragment");
                break;

            case 1:
                call = CC.obtainBuilder("MessageComponent").setContext(this).setActionName("startMainFragment").build().call();
                fragment = call.getDataItem("fragment");
                break;

            case 2:
                call = CC.obtainBuilder("CenterComponent").setContext(this).setActionName("startMainFragment").build().call();
                fragment = call.getDataItem("fragment");
                break;
        }
        return fragment;

    }

    class ContentPagerAdapter extends FragmentPagerAdapter {

        public ContentPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            return createFragment(position);
        }

        @Override
        public int getCount() {
            return tabIndicators.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return tabIndicators.get(position);
        }
    }

}
