package com.soso.app;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.billy.cc.core.component.CC;
import com.billy.cc.core.component.CCResult;
import com.billy.cc.core.component.IComponentCallback;
import com.soso.sosoframe.base.activity.BaseMvpActivity;
import com.soso.sosolib.BaseApplication;
import com.soso.sosolib.utils.ToastManager;


public class DemoMainActivity extends BaseMvpActivity {
    @Override
    public int getLayoutResId(@Nullable Bundle savedInstanceState) {
        return R.layout.activity_demo_main;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public void initView(@Nullable Bundle savedInstanceState) {
        super.initView(savedInstanceState);

        findViewById(R.id.btn_token).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CC.obtainBuilder("LoginComponent")
                        .setActionName("requestNetTokenWhenAppStart")
                        .setContext(DemoMainActivity.this)
                        .build()
                        .callAsyncCallbackOnMainThread(new IComponentCallback() {
                            @Override
                            public void onResult(CC cc, CCResult result) {
                                Integer loginType = result.getDataItem("loginType");
                                if (loginType != null) {
                                    switch (loginType) {
                                        case 200:
                                            ToastManager.getInstance(BaseApplication.getAppContext()).showText(loginType+"");
                                            break;
                                        default:
                                            break;
                                    }
                                }

                            }
                        });

            }
        });

        findViewById(R.id.btn_home).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CC.obtainBuilder("HomeComponent")
                        .setActionName("startHomeMainActivity")
                        .setContext(DemoMainActivity.this)
                        .build().call();
            }
        });
    }
}
