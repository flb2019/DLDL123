package com.soso.uiwidget.pictureselector;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.text.TextUtils;

import com.soso.uiwidget.pictureselector.entity.LocalMedia;
import com.soso.uiwidget.pictureselector.fragment.PictureSelector;

import java.util.ArrayList;
import java.util.List;

/**
 * 图片选择器帮助类
 * Created by EdgarNg on 2017/10/25.
 */

public class PictureSelectorHelper {
    // 预览图片

    /**
     *
     * @param fragment 支持fragment
     * @param position 图片的位置
     * @param selectList 数据源
     */
    public static void ShowSelectedPicture(Fragment fragment, int position, List<LocalMedia> selectList){
        if (selectList == null || selectList.size() == 0){
            return;
        }
        PictureSelector.create(fragment).externalPicturePreview(position, selectList);
    }

    /**
     *
     * @param fragment 支持fragment
     * @param position 图片的位置
     * @param selectList 数据源
     */
    public static void ShowSelectedPicture(Activity fragment, int position, List<LocalMedia> selectList){
        if (selectList == null || selectList.size() == 0){
            return;
        }
        PictureSelector.create(fragment).externalPicturePreview(position, selectList);
    }

    /**
     *
     * @param fragment 支持fragment
     * @param picUrl 数据源
     */
    public static void ShowSelectedPicture(Activity fragment, String picUrl){
        if (TextUtils.isEmpty(picUrl)){
            return;
        }
        LocalMedia media = new LocalMedia();
        media.setPath(picUrl);
        List<LocalMedia> selectList = new ArrayList<LocalMedia>();
        selectList.add(media);
        PictureSelector.create(fragment).externalPicturePreview(0, selectList);
    }

    /**
     * 数据转换器，string转成localMedia
     * @param selecturls
     * @return
     */
    public static List<LocalMedia> convertPicData(List<String> selecturls){
        List<LocalMedia> selectList = new ArrayList<LocalMedia>();
        if (selecturls != null && selecturls.size() != 0) {

            for (int i = 0; i < selecturls.size(); i++) {

                LocalMedia media = new LocalMedia();
                media.setPath(selecturls.get(i));
                selectList.add(media);
            }
        }
        return selectList;
    }

}
