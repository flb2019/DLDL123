package com.soso.uiwidget.hepler.loadsir;

import android.view.View;

import java.io.Serializable;

/**
 * Created by sumerlin on 2019/2/23 2019/2/23.
 * Describe:
 */
public interface UiViewStateAction {
    void showLoading();

    void showCircularLoading();

    void showSuccess();

    void showError();

    void showEmpty();

//    default void onReload(View v) {
//    }

    interface OnReloadListener extends Serializable{
        void onReloadAction(View v);
    }
}
