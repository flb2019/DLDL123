package com.soso.uiwidget.hepler.loadsir.custom;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.view.View;
import android.widget.ImageView;

import com.soso.uiwidget.R;
import com.soso.uiwidget.hepler.loadsir.callback.Callback;

/**
 * 圆圈loading
 * Created by haipeng.L on 2018/3/26.
 */

public class CircularLoadingCallback extends Callback {

    private AnimationDrawable animationDrawable;
    private ImageView progressbar;

    @Override
    protected int onCreateView() {
        return R.layout.pager_loading;
    }

    @Override
    protected boolean onReloadEvent(Context context, View view) {
        return true;
    }

}
