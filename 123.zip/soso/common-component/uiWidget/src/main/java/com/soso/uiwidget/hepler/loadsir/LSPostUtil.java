package com.soso.uiwidget.hepler.loadsir;

import android.os.Handler;
import android.os.Looper;

import com.soso.uiwidget.hepler.loadsir.callback.Callback;
import com.soso.uiwidget.hepler.loadsir.callback.SuccessCallback;
import com.soso.uiwidget.hepler.loadsir.core.LoadService;
import com.soso.uiwidget.hepler.loadsir.custom.CircularLoadingCallback;
import com.soso.uiwidget.hepler.loadsir.custom.EmptyCallback;
import com.soso.uiwidget.hepler.loadsir.custom.ErrorCallback;
import com.soso.uiwidget.hepler.loadsir.custom.LoadingCallback;


/**
 * Description:
 * Create Time:2017/9/4 15:21
 * Author:KingJA
 * Email:kingjavip@gmail.com
 */
public class LSPostUtil {


    private static Class<? extends Callback> emptyClazz = EmptyCallback.class;
    private static Class<? extends Callback> errorClazz = ErrorCallback.class;
    private static Class<? extends Callback> loadingClazz = LoadingCallback.class;
    private static Class<? extends Callback> circularLoadingClazz = CircularLoadingCallback.class;
    private static Class<? extends Callback> successClazz = SuccessCallback.class;

    private static final int DELAY_TIME = 0;

    public static void postCallback(final LoadService loadService, final Class<? extends Callback> clazz) {
        postCallbackDelayed(loadService, clazz, DELAY_TIME);
    }

    public static void postCallbackDelayed(final LoadService loadService, final Class<? extends Callback> clazz, long
            delay) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                loadService.showCallback(clazz);
            }
        }, delay);
    }

    public static void postSuccess(final LoadService loadService) {
        postSuccessDelayed(loadService, DELAY_TIME);
    }

    public static void postSuccessDelayed(final LoadService loadService, long delay) {
        postCallbackDelayed(loadService, successClazz, delay);
    }

    public static void postLoadingDelayed(LoadService loadService, long delay) {
        postCallbackDelayed(loadService, loadingClazz, delay);
    }

    public static void postLoading(LoadService loadService) {
        postLoadingDelayed(loadService, 0);
    }

    public static void postCircularLoadingDelayed(LoadService loadService, long delay) {
        postCallbackDelayed(loadService, circularLoadingClazz, delay);
    }

    public static void postCircularLoading(LoadService loadService) {
        postCircularLoadingDelayed(loadService, 0);
    }

    public static void postErrorDelayed(LoadService loadService, long delay) {
        postCallbackDelayed(loadService, errorClazz, delay);
    }

    public static void postError(LoadService loadService) {
        postErrorDelayed(loadService, 0);
    }

    public static void postEmptyDelayed(LoadService loadService, long delay) {
        postCallbackDelayed(loadService, emptyClazz, delay);
    }

    public static void postEmpty(LoadService loadService) {
        postEmptyDelayed(loadService, 0);
    }


    public static void setEmptyClazz(Class<? extends Callback> emptyClazz) {
        LSPostUtil.emptyClazz = emptyClazz;
    }

    public static void setErrorClazz(Class<? extends Callback> errorClazz) {
        LSPostUtil.errorClazz = errorClazz;
    }

    public static void setLoadingClazz(Class<? extends Callback> loadingClazz) {
        LSPostUtil.loadingClazz = loadingClazz;
    }

    public static void setSuccessClazz(Class<? extends Callback> successClazz) {
        LSPostUtil.successClazz = successClazz;
    }
}
