package com.soso.uiwidget.hepler.loadsir;

import android.os.Handler;
import android.os.Looper;
import android.view.View;

import com.soso.uiwidget.hepler.loadsir.callback.Callback;
import com.soso.uiwidget.hepler.loadsir.core.LoadService;
import com.soso.uiwidget.hepler.loadsir.core.LoadSir;

/**
 * Created by sumerlin on 2019/2/23 2019/2/23.
 * Describe:单独提供状态助手
 */
public class UiViewStateHelper implements UiViewStateAction {

    private LoadService mLoadService;

    private UiViewStateHelper() {
    }

    /**
     * 实例化 并  初始化
     *
     * @param view
     * @return
     */
    public static UiViewStateHelper createHelper(View view, UiViewStateAction.OnReloadListener onReloadListener) {
        UiViewStateHelper helper = new UiViewStateHelper();
        helper.initForRegister(view, onReloadListener);
        return helper;
    }

    private void initForRegister(View view, UiViewStateAction.OnReloadListener onReloadListener) {
        mLoadService = LoadSir.getDefault().register(view, new Callback.OnReloadListener() {
            @Override
            public void onReload(View v) {
                //BaseFragment.this.onReload(v);
                //UiViewStateHelper.this.onReload(v);
                onReloadListener.onReloadAction(v);
            }
        });
    }

    public LoadService getLoadService() {
        return mLoadService;
    }

    public View getLoadLayout() {
        return mLoadService.getLoadLayout();
    }


    @Override
    public void showLoading() {
        LSPostUtil.postLoading(mLoadService);

    }

    @Override
    public void showCircularLoading() {
        LSPostUtil.postCircularLoading(mLoadService);
    }

    @Override
    public void showSuccess() {
//        LSPostUtil.postSuccess();
//        postCallbackDelayed(SuccessCallback.class, 0);
        LSPostUtil.postSuccess(mLoadService);
    }

    @Override
    public void showError() {
        LSPostUtil.postError(mLoadService);
    }

    @Override
    public void showEmpty() {
        LSPostUtil.postEmpty(mLoadService);
    }


    private void postCallbackDelayed(Class<? extends Callback> clazz, long delay) {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                mLoadService.showCallback(clazz);
            }
        }, delay);

    }
}
