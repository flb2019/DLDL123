package com.soso.uiwidget.hepler.loadsir.custom;


import com.soso.uiwidget.R;
import com.soso.uiwidget.hepler.loadsir.callback.Callback;


/**
 * Description:
 * Create Time:2017/9/4 10:20
 * Author:KingJA
 * Email:kingjavip@gmail.com
 */

public class ErrorCallback extends Callback {
    @Override
    protected int onCreateView() {
        return R.layout.pager_error;
    }
}
