package com.soso.uiwidget.hepler.loadsir;

import android.view.View;

import com.soso.uiwidget.hepler.loadsir.callback.Callback;
import com.soso.uiwidget.hepler.loadsir.core.LoadService;

/**
 * Created by sumerlin on 2018/1/11.
 * 页面 加载多状态布局
 */

public interface UiViewState {

    /**
     * 不同的view  初始化调用
     *
     * @param view
     * @return
     */
    default View initLoadSir(View view) {
        return view;
    }

    default LoadService getLoadService(){
        return null;
    }

    default boolean hideLoading() {
        return true;
    }

    default void onReload(View v){

    }

    default void postCallbackDelayed(final Class<? extends Callback> clazz, long delay) {
    }

    default void showSuccess() {
    }

    default  void onDestrory(){

    }

}