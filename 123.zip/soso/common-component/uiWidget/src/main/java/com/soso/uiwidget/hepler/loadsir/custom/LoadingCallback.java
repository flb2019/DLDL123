package com.soso.uiwidget.hepler.loadsir.custom;


import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.view.View;
import android.widget.ImageView;

import com.soso.uiwidget.R;
import com.soso.uiwidget.hepler.loadsir.callback.Callback;


/**
 * Description:
 * Create Time:2017/9/4 10:22
 * Author:KingJA
 * Email:kingjavip@gmail.com
 */

public class LoadingCallback extends Callback {

    private AnimationDrawable animationDrawable;
    private ImageView progressbar;

    @Override
    protected int onCreateView() {
        return R.layout.pager_runing_loading;
    }

    @Override
    protected boolean onReloadEvent(Context context, View view) {
        return true;
    }

    @Override
    public void onAttach(Context context, View view) {
        super.onAttach(context, view);
        startLoadingAnim(view);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        stopLoadingAnim();
    }

    private void startLoadingAnim(View view) {
        if (progressbar == null) {
            progressbar = (ImageView) view.findViewById(R.id.progressbar);
        }

        if (animationDrawable == null) {
            animationDrawable = (AnimationDrawable) progressbar.getBackground();
        }

        if (!animationDrawable.isRunning()) {

            animationDrawable.start();
        }
    }

    private void stopLoadingAnim() {
        if (animationDrawable != null && animationDrawable.isRunning()) {
            animationDrawable.stop();
        }
    }
}
