package com.soso.common.module.share.core;

/**
 * Created by sumerlin on 2018/1/4.
 * 分享全局配置，包括全局的title ,  content， imgUrl
 */

public class ShareConfig {
    public static String SHARE_TITLE = "优托邦客户端";
    public static String SHARE_CONTENT = "优托邦分享";
    public static String SHARE_LOGO = "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1515059307953&di=9566f546a5464f26ba495c5693833929&imgtype=0&src=http%3A%2F%2Fimg.25pp.com%2Fuploadfile%2Fapp%2Ficon%2F20160626%2F1466911852405210.jpg";
}
