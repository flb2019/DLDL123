package com.soso.common.module.share;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class ShareMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.share_activity_share_main);
    }
}
