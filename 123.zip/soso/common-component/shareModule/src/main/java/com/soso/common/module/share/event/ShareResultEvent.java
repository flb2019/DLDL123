package com.soso.common.module.share.event;

/**
 * 分享结果事件
 * Created by yangjingzhu on 2018/7/30.
 */

public class ShareResultEvent {
    private boolean isSuccess = false;

    public ShareResultEvent(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

    public boolean isSuccess() {
        return isSuccess;
    }
}
