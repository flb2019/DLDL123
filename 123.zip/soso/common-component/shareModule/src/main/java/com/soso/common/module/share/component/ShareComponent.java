package com.soso.common.module.share.component;

import com.billy.cc.core.component.CC;
import com.billy.cc.core.component.CCResult;
import com.billy.cc.core.component.IComponent;
import com.soso.common.module.share.core.ShareDialog;

/**
 * Created by sumerlin on 2019/2/25 2019/2/25.
 * Describe:
 */
public class ShareComponent implements IComponent {
    @Override
    public String getName() {
        return "ShareComponent";
    }

    /**
     * 组件被调用时的入口
     * 要确保每个逻辑分支都会调用到CC.sendCCResult，
     * 包括try-catch,if-else,switch-case-default,startActivity
     *
     * @param cc 组件调用对象，可从此对象中获取相关信息
     * @return true:将异步调用CC.sendCCResult(...),用于异步实现相关功能，例如：文件加载、网络请求等
     * false:会同步调用CC.sendCCResult(...),即在onCall方法return之前调用，否则将被视为不合法的实现
     */
    @Override
    public boolean onCall(CC cc) {
        String actionName = cc.getActionName();
        switch (actionName) {
            case "openShareDialog":
                startShareDialog(cc);
                break;
        }
        CC.sendCCResult(cc.getCallId(), CCResult.success());
        return false;
    }

    private void startShareDialog(CC cc) {
        String shareTitle = cc.getParamItem("shareTitle", "分享的shareTitle");
        String shareContent = cc.getParamItem("shareContent", "分享shareContent");
        String shareImgUrl = cc.getParamItem("shareImgUrl", "https://image.baidu.com/search/detail?ct=503316480&z=0&ipn=d&word=tup&hs=2&pn=3&spn=0&di=189656571060&pi=0&rn=1&tn=baiduimagedetail&is=0%2C0&ie=utf-8&oe=utf-8&cl=2&lm=-1&cs=3006884240%2C1444133691&os=2029103381%2C1967265345&simid=4218248233%2C776471725&adpicid=0&lpn=0&ln=30&fr=ala&fm=&sme=&cg=&bdtype=0&oriquery=tup&objurl=http%3A%2F%2Fhbimg.b0.upaiyun.com%2F01f13dd8fcbfcfd38bd13f92cca49a0bd8ec434b12cea-0yEhtq_fw658&fromurl=ippr_z2C%24qAzdH3FAzdH3Fi7wkwg_z%26e3Bv54AzdH3FrtgfAzdH3Fdldaa99anAzdH3F&gsm=0&islist=&querylist=");
        String shareUrl = cc.getParamItem("shareUrl", "https://www.baidu.com/");
        new ShareDialog(cc.getContext(), shareTitle, shareContent, shareImgUrl, shareUrl);
    }
}
