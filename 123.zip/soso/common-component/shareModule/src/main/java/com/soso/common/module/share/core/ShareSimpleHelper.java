package com.soso.common.module.share.core;

import cn.sharesdk.framework.Platform;
import cn.sharesdk.framework.PlatformActionListener;
import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.tencent.qq.QQ;
import cn.sharesdk.tencent.qzone.QZone;
import cn.sharesdk.wechat.friends.Wechat;
import cn.sharesdk.wechat.moments.WechatMoments;

/**
 * Created by sumerlin on 2018/11/20 16:25.
 * Describe:
 */
public class ShareSimpleHelper {

    public final static int ITEMTEXTTYPE_WECHAT = 1;
    public final static int ITEMTEXTTYPE_WECHATFRIEND = 2;
    public final static int ITEMTEXTTYPE_QQ = 3;
    public final static int ITEMTEXTTYPE_QZONE = 4;

    /**
     * 直接调起 对应的分享
     *
     * @param ItemTextType
     * @param title
     * @param content
     * @param imgUrl
     * @param url
     * @param platformActionListener
     */
    public static void openSimpleShare(int ItemTextType, String title, String content, String imgUrl, String url, PlatformActionListener platformActionListener) {
        String ItemText = "";
        switch (ItemTextType) {
            case ITEMTEXTTYPE_WECHAT:
                ItemText = "微信好友";
                break;
            case ITEMTEXTTYPE_WECHATFRIEND:
                ItemText = "朋友圈";
                break;
            case ITEMTEXTTYPE_QQ:
                ItemText = "QQ";

                break;
            case ITEMTEXTTYPE_QZONE:
                ItemText = "QQ空间";
                break;
            default:
                break;

        }
        openSimpleShare(ItemText, title, content, imgUrl, url, platformActionListener);
    }

    /**
     * 直接调起 对应的分享
     *
     * @param ItemText
     * @param title
     * @param content
     * @param imgUrl
     * @param url
     * @param platformActionListener
     */
    public static void openSimpleShare(String ItemText, String title, String content, String
            imgUrl, String url, PlatformActionListener platformActionListener) {
        switch (ItemText) {
            case "微信好友":
                Platform.ShareParams sp_wechat = new Platform.ShareParams();
                sp_wechat.setShareType(Platform.SHARE_WEBPAGE);
                sp_wechat.setTitle(title);
                sp_wechat.setText(content);
                sp_wechat.setImageUrl(imgUrl);
                sp_wechat.setUrl(url);
                Platform wechat = ShareSDK.getPlatform(Wechat.NAME);
                wechat.setPlatformActionListener(platformActionListener);
                wechat.share(sp_wechat);
                break;
            case "朋友圈":
                Platform.ShareParams sp_wechatFriend = new Platform.ShareParams();
                sp_wechatFriend.setShareType(Platform.SHARE_WEBPAGE);
                sp_wechatFriend.setTitle(title);
                sp_wechatFriend.setText(content);
                sp_wechatFriend.setImageUrl(imgUrl);
                sp_wechatFriend.setUrl(url);
                Platform wechatFriend = ShareSDK.getPlatform(WechatMoments.NAME);
                wechatFriend.setPlatformActionListener(platformActionListener);
                wechatFriend.share(sp_wechatFriend);
                break;
            case "QQ":
                Platform.ShareParams sp_qq = new Platform.ShareParams();
                sp_qq.setTitle(title);
                sp_qq.setTitleUrl(url); // 标题的超链接
                sp_qq.setText(content);
                sp_qq.setImageUrl(imgUrl);//分享网络图片
                Platform qq = ShareSDK.getPlatform(QQ.NAME);
                qq.setPlatformActionListener(platformActionListener);
                qq.share(sp_qq);
                break;
            case "QQ空间":
                Platform.ShareParams sp_qzone = new Platform.ShareParams();
                sp_qzone.setTitle(title);
                sp_qzone.setTitleUrl(url); // 标题的超链接
                sp_qzone.setText(content);
                sp_qzone.setImageUrl(imgUrl);//分享网络图片
                Platform qzone = ShareSDK.getPlatform(QZone.NAME);
                qzone.setPlatformActionListener(platformActionListener);
                qzone.share(sp_qzone);
                break;
            default:
                break;

        }
    }
}
