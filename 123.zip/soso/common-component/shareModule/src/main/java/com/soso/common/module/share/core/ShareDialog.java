package com.soso.common.module.share.core;

import android.app.AlertDialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.mob.MobSDK;
import com.soso.common.module.share.R;
import com.soso.common.module.share.event.ShareResultEvent;
import com.soso.sosolib.art.integration.manager.EventBusManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import cn.sharesdk.framework.Platform;
import cn.sharesdk.framework.PlatformActionListener;
import cn.sharesdk.framework.ShareSDK;
import cn.sharesdk.tencent.qq.QQ;
import cn.sharesdk.tencent.qzone.QZone;
import cn.sharesdk.wechat.friends.Wechat;
import cn.sharesdk.wechat.moments.WechatMoments;

public class ShareDialog {
    private Context mContext;
    private AlertDialog dialog;
    private GridView gridView;
    private GridView fun_gridView;
    private View cancelButton;
    private SimpleAdapter saImageItems, saImageItems1;
    private TextView tvTitle;//这是此网页由mx.app.com提供
    private String title, content, imgUrl, url;
    private int[] image = {R.mipmap.general_qq, R.mipmap.general_weixin, R.mipmap.general_pengyouquan};
    private String[] name = {"QQ", "微信好友", "朋友圈"};


    private int[] fun_image = {R.mipmap.general_shuaxin, R.mipmap.general_copylink};
    private String[] fun_name = {"刷新", "复制链接"};

    PlatformActionListener platformActionListener = new PlatformActionListener() {
        @Override
        public void onComplete(Platform platform, int i, HashMap<String, Object> hashMap) {
//            ToastManager.getInstance(mContext).showText("分享成功");
            EventBusManager.getInstance().post(new ShareResultEvent(true));
        }

        @Override
        public void onError(Platform platform, int i, Throwable throwable) {
//            ToastManager.getInstance(mContext).showText("分享失败");
            EventBusManager.getInstance().post(new ShareResultEvent(false));
        }

        @Override
        public void onCancel(Platform platform, int i) {
//            ToastManager.getInstance(mContext).showText("取消分享");
            EventBusManager.getInstance().post(new ShareResultEvent(false));
        }
    };

    /**
     * 分享弹窗
     *
     * @param context 上下文
     * @param title   分享的标题
     * @param content 分享的内容
     * @param imgUrl  分享的图片
     * @param url     跳转的url
     */
    public ShareDialog(Context context, String title, String content, String imgUrl, String url) {

        if (TextUtils.isEmpty(url)) {
            return;
        }
        this.mContext = context;
        this.title = title;
        this.content = content;
        this.imgUrl = imgUrl;
        this.url = url;
        MobSDK.init(context.getApplicationContext(), "202a59954e20a", "44434fc4568036d4472bf334a64593bc");
        dialog = new AlertDialog.Builder(context).create();
        dialog.show();

        Window window = dialog.getWindow();
        window.setContentView(R.layout.share_dialog);
        window.setBackgroundDrawableResource(android.R.color.transparent);
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.gravity = Gravity.BOTTOM;
        window.setAttributes(lp);

        gridView = (GridView) window.findViewById(R.id.share_gridView);
        cancelButton = window.findViewById(R.id.share_cancel);
        List<HashMap<String, Object>> shareList = new ArrayList<HashMap<String, Object>>();
        for (int i = 0; i < image.length; i++) {
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("ItemImage", image[i]);//添加图像资源的ID
            map.put("ItemText", name[i]);//按序号做ItemText
            shareList.add(map);
        }

        saImageItems = new SimpleAdapter(context, shareList, R.layout.share_item, new String[]{"ItemImage", "ItemText"}, new int[]{R.id.imageView1, R.id.textView1});
        gridView.setAdapter(saImageItems);


        List<HashMap<String, Object>> funList = new ArrayList<HashMap<String, Object>>();
        for (int i = 0; i < fun_image.length; i++) {
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("ItemImage", fun_image[i]);//添加图像资源的ID
            map.put("ItemText", fun_name[i]);//按序号做ItemText
            funList.add(map);
        }

        fun_gridView = (GridView) window.findViewById(R.id.function_gridView);
        saImageItems1 = new SimpleAdapter(context, funList, R.layout.share_item, new String[]{"ItemImage", "ItemText"}, new int[]{R.id.imageView1, R.id.textView1});
        fun_gridView.setAdapter(saImageItems1);

        tvTitle = (TextView) window.findViewById(R.id.titleWebSite);
        if (url.contains("http")) {
            url = url.split("/")[2];
        } else {
            url = url.split("/")[0];
        }
        tvTitle.setText("此网页由" + url + "提供");
        initClickListener();
    }

    /**
     * 初始化默认点击事件
     */
    private void initClickListener() {
        setCancelButtonOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShareDialog.this.dismiss();
            }
        });


        setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, Object> item = (HashMap<String, Object>) parent.getItemAtPosition(position);

                switch (item.get("ItemText").toString()) {
                    case "微信好友":
                        Platform.ShareParams sp_wechat = new Platform.ShareParams();
                        sp_wechat.setShareType(Platform.SHARE_WEBPAGE);
                        sp_wechat.setTitle(title);
                        sp_wechat.setText(content);
                        sp_wechat.setImageUrl(imgUrl);
                        sp_wechat.setUrl(url);
                        Platform wechat = ShareSDK.getPlatform(Wechat.NAME);
                        wechat.setPlatformActionListener(platformActionListener);
                        wechat.share(sp_wechat);
                        break;
                    case "朋友圈":
                        Platform.ShareParams sp_wechatFriend = new Platform.ShareParams();
                        sp_wechatFriend.setShareType(Platform.SHARE_WEBPAGE);
                        sp_wechatFriend.setTitle(title);
                        sp_wechatFriend.setText(content);
                        sp_wechatFriend.setImageUrl(imgUrl);
                        sp_wechatFriend.setUrl(url);
                        Platform wechatFriend = ShareSDK.getPlatform(WechatMoments.NAME);
                        wechatFriend.setPlatformActionListener(platformActionListener);
                        wechatFriend.share(sp_wechatFriend);
                        break;
                    case "QQ":
                        Platform.ShareParams sp_qq = new Platform.ShareParams();
                        sp_qq.setTitle(title);
                        sp_qq.setTitleUrl(url); // 标题的超链接
                        sp_qq.setText(content);
                        sp_qq.setImageUrl(imgUrl);//分享网络图片
                        Platform qq = ShareSDK.getPlatform(QQ.NAME);
                        qq.setPlatformActionListener(platformActionListener);
                        qq.share(sp_qq);
                        break;
                    case "QQ空间":
                        Platform.ShareParams sp_qzone = new Platform.ShareParams();
                        sp_qzone.setTitle(title);
                        sp_qzone.setTitleUrl(url); // 标题的超链接
                        sp_qzone.setText(content);
                        sp_qzone.setImageUrl(imgUrl);//分享网络图片
                        Platform qzone = ShareSDK.getPlatform(QZone.NAME);
                        qzone.setPlatformActionListener(platformActionListener);
                        qzone.share(sp_qzone);
                        break;
                    default:
                        break;

                }
                ShareDialog.this.dismiss();
            }
        });


        setOnFunctionItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, Object> item = (HashMap<String, Object>) parent.getItemAtPosition(position);
                switch (item.get("ItemText").toString()) {
                    case "刷新":
                        ShareDialog.this.dismiss();
                        break;
                    case "复制链接":
                        ShareDialog.this.dismiss();
                        ClipboardManager cmb = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                        cmb.setText(url);
                        Toast.makeText(mContext, "已复制邀请链接", Toast.LENGTH_SHORT).show();
                        break;
                    default:
                        break;

                }
            }
        });
    }


    public void setCancelButtonOnClickListener(View.OnClickListener Listener) {
        cancelButton.setOnClickListener(Listener);
    }


    /**
     * 分享监听
     *
     * @param listener
     */
    public void setOnItemClickListener(AdapterView.OnItemClickListener listener) {
        gridView.setOnItemClickListener(listener);
    }

    /**
     * 功能按钮监听
     *
     * @param listener
     */
    public void setOnFunctionItemClickListener(AdapterView.OnItemClickListener listener) {
        fun_gridView.setOnItemClickListener(listener);
    }


    /**
     * 关闭对话框
     */
    public void dismiss() {
        dialog.dismiss();

    }

    /**
     * 设置功能界面是否显示,如果不显示的话,抬头的titleview也改成"分享"
     */
    public void setFunGridViewVisibility(int visibility) {
        fun_gridView.setVisibility(visibility);
        tvTitle.setText("分享");
    }
}