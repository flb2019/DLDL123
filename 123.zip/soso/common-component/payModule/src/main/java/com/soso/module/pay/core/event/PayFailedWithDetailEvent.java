package com.soso.module.pay.core.event;

/**
 * 支付失败后跳到重新支付的时候 eventbus的回调
 * Created by EdgarNg on 2017/10/26.
 */

public class PayFailedWithDetailEvent extends AbsPayEvent {
    public PayFailedWithDetailEvent(String payOrderNo) {
        super(payOrderNo);
    }

    public PayFailedWithDetailEvent(String payOrderNo, String payType, String orderNo) {
        super(payOrderNo, payType, orderNo);
    }
}
