package com.soso.module.pay.core.helper;

/**
 * Created by sumerlin on 2018/9/20 15:40.
 * Describe:
 */
public class PayDtoHelper {
    //1	余额
//2	微信
//3	支付宝
//21	工行微信
//22	工行支付宝

    public static final int PAY_WAY_BALANCE = 1;
    public static final int PAY_WAY_WECHAT = 2;
    public static final int PAY_WAY_ALI = 3;
    public static final int PAY_WAY_GH_WECHAT = 21;
    public static final int PAY_WAY_GH_ALI = 22;
    public static final int PAY_WAY_GH_GZH = 23;
    public static final int PAY_WAY_GH_EWEIMA = 24;
    public static final int PAY_WAY_GH_SHUAKA = 25;


}
