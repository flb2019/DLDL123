package com.soso.module.pay.core.event;

/**
 * 支付成功时候eventbus的回调
 * Created by EdgarNg on 2017/10/26.
 */

public class PaySuccedEvent extends AbsPayEvent {
    public PaySuccedEvent(String payOrderNo) {
        super(payOrderNo);
    }

    public PaySuccedEvent(String payOrderNo, String payType) {
        super(payOrderNo, payType);
    }
}
