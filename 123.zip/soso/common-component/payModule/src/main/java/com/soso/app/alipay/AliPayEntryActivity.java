package com.soso.app.alipay;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;

import com.icbc.paysdk.AliPayAPI;
import com.icbc.paysdk.IAliPayResultHandler;
import com.soso.module.pay.core.Constant;
import com.soso.module.pay.core.helper.PayHelper;
import com.soso.sosolib.utils.ToastManager;

/**
 * Created by kfzx-xuyh on 2017/12/21.
 */

public class AliPayEntryActivity extends Activity implements IAliPayResultHandler {

    TextView result_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.pay_result_handler_layout);
//        result_text = (TextView) findViewById(R.id.pay_result);
        Intent intent = getIntent();
        if (AliPayAPI.getInstance() != null) {
            AliPayAPI.getInstance().handleIntent(getIntent(), this);
        } else {
            finish();
        }

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (AliPayAPI.getInstance() != null) {
            AliPayAPI.getInstance().handleIntent(intent, this);
        }
    }


    @Override
    public void onResp(String resultcode) {
//    if("9000".equals(resultcode)){
//       result_text.setText("支付成功");
////        LiberPayHelper.onPaySuccessed(AliPayEntryActivity.this, WXPayHelper.getWXPayResqByPrepayId(((PayResp) resp).prepayId).getmPayOrderNo());
////        AliPayEntryActivity.this.finish();
//    }else if("6001".equals(resultcode)){
//        result_text.setText("支付取消");
//    }else{
//        result_text.setText("支付失败");
//    }
//    }

        // 判断resultStatus 为9000则代表支付成功
        if (TextUtils.equals(resultcode, "9000")) {
            // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
            PayHelper.onPaySuccessed(this, Constant.payOrderNo);
            AliPayEntryActivity.this.finish();
        } else if ("6001".equals(resultcode)) {
            ToastManager.getInstance(this).showText("支付取消");
            AliPayEntryActivity.this.finish();

        } else {
            // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
            PayHelper.onPayFailed(this, Constant.payOrderNo);
            AliPayEntryActivity.this.finish();
        }
    }
}
