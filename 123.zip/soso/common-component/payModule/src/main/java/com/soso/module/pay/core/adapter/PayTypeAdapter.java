package com.soso.module.pay.core.adapter;

import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.soso.module.pay.R;
import com.soso.module.pay.core.bean.InitPayDto;
import com.soso.module.pay.core.helper.PayDtoHelper;
import com.soso.sosolib.utils.GtNumberUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 选择支付方式的adapter
 * Created by EdgarNg on 2017/10/24.
 */

public class PayTypeAdapter extends RecyclerView.Adapter<PayTypeAdapter.MyViewHolder> {

    protected final String STR_DEFAULT_PAY_TYPE = "请升级尝鲜新的支付方式~";
    protected List<Integer> data = new ArrayList<>();
    protected InitPayDto mInitPayDto;

    private int layoutPosition = -1;

    public PayTypeAdapter() {
    }

    public void setData(List<Integer> data) {
        this.data = data;
    }

    public void setInitPayDto(InitPayDto initPayDto) {
        this.mInitPayDto = initPayDto;
    }

    public void setLayoutPosition(int layoutPosition) {
        this.layoutPosition = layoutPosition;
    }

    public int getLayoutPosition() {
        return layoutPosition;
    }

    protected int getItemLayoutId() {
        return R.layout.pay_item_choice_paytype;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(getItemLayoutId(), parent, false);
        MyViewHolder vh = new MyViewHolder(view);
        return vh;
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {
        holder.txtValue.setText(type2text(data.get(position)));
        if (STR_DEFAULT_PAY_TYPE.equals(holder.txtValue.getText())) {
            holder.txtValue.setEnabled(false);
        } else {
            holder.txtValue.setEnabled(true);
        }
        Drawable[] d = holder.txtValue.getCompoundDrawables();
        final Drawable payTypeDrawable = holder.txtValue.getResources().getDrawable(getDrawableRes(data.get(position)));
        payTypeDrawable.setBounds(d[0].getBounds());//这一步不能省略
        if (data.get(position) == 1 && mInitPayDto.getUserBalance() < mInitPayDto.getOrderTotalMoney()) {
            //余额 不够钱给
            holder.txtValue.setEnabled(false);
            holder.txtValue.setTextColor(holder.txtValue.getResources().getColor(R.color.gray_99));
        }
        holder.txtValue.setCompoundDrawables(payTypeDrawable, d[1], d[2], d[3]);
        holder.txtValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layoutPosition = holder.getLayoutPosition();
                notifyDataSetChanged();
//                mOnItemClickListener.onItemClick(holder.itemView, (String) holder.itemView.getTag(), layoutPosition);
            }
        });
        if (position == layoutPosition) {
            holder.choice.setSelected(holder.txtValue.isEnabled());
            if (!holder.txtValue.isEnabled() && ++layoutPosition >= getItemCount()) {
                layoutPosition = -1;
                if (mPayTypeListener != null) {
                    mPayTypeListener.onNoCanUsePayType();
                }
            }
        } else {
            holder.choice.setSelected(false);
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


    protected String type2text(@NonNull Integer item) {
        switch (item) {
            case PayDtoHelper.PAY_WAY_BALANCE:
                return "余额支付(剩余" + GtNumberUtils.addMoneyFenToYuan(mInitPayDto.getUserBalance()) + ")";
            case PayDtoHelper.PAY_WAY_WECHAT:
                return "-微信支付";
            case PayDtoHelper.PAY_WAY_ALI:
                return "-支付宝支付";
            case PayDtoHelper.PAY_WAY_GH_WECHAT:
                return "微信支付";
            case PayDtoHelper.PAY_WAY_GH_ALI:
                return "支付宝支付";
            case PayDtoHelper.PAY_WAY_GH_GZH:
                return "工行聚合公众号、生活号";
            case PayDtoHelper.PAY_WAY_GH_EWEIMA:
                return "工行二维码";
            case PayDtoHelper.PAY_WAY_GH_SHUAKA:
                return "工行刷卡";
            default:
                return STR_DEFAULT_PAY_TYPE;

        }
    }


    protected int getDrawableRes(@NonNull Integer item) {
        switch (item) {
            case PayDtoHelper.PAY_WAY_BALANCE:
                if (mInitPayDto.getUserBalance() < mInitPayDto.getOrderTotalMoney()) {
                    //不够钱给
                    return R.mipmap.pay_balance_gray;
                } else {
                    return R.mipmap.pay_balance;
                }
            case PayDtoHelper.PAY_WAY_WECHAT:
                return R.mipmap.pay_weixin;
            case PayDtoHelper.PAY_WAY_ALI:
                return R.mipmap.pay_zhifubao;

            case PayDtoHelper.PAY_WAY_GH_WECHAT:
                return R.mipmap.pay_weixin;
            case PayDtoHelper.PAY_WAY_GH_ALI:
                return R.mipmap.pay_zhifubao;
            default:
                return R.mipmap.pay_balance_gray;
        }
    }

    protected class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView txtValue;
        public ImageView choice;

        public MyViewHolder(View itemView) {
            super(itemView);
            txtValue = (TextView) itemView.findViewById(R.id.txtValue);
            choice = (ImageView) itemView.findViewById(R.id.choice);
        }
    }

    private OnPayTypeListener mPayTypeListener;

    public void setPayTypeListener(OnPayTypeListener mPayTypeListener) {
        this.mPayTypeListener = mPayTypeListener;
    }

    public interface OnPayTypeListener {
        //当没有可用的支付方式时候调用
        void onNoCanUsePayType();
    }

}

















