package com.soso.module.pay.core.event;

/**
 * 支付失败后直接返回的时候 eventbus的回调
 * Created by EdgarNg on 2017/10/26.
 */

public class PayFailedWithBackEvent extends AbsPayEvent {
    public PayFailedWithBackEvent(String payOrderNo) {
        super(payOrderNo);
    }
}
