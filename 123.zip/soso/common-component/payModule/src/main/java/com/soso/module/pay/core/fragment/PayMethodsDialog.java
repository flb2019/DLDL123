package com.soso.module.pay.core.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.internal.LinkedTreeMap;
import com.icbc.paysdk.AliPayAPI;
import com.icbc.paysdk.WXPayAPI;
import com.icbc.paysdk.constants.Constants;
import com.icbc.paysdk.model.ThirdPayReq;
import com.soso.module.pay.R;
import com.soso.module.pay.core.Constant;
import com.soso.module.pay.core.adapter.LiberPayStyleAdapter;
import com.soso.module.pay.core.adapter.PayTypeAdapter;
import com.soso.module.pay.core.bean.InitPayDto;
import com.soso.module.pay.core.event.PayFailedEvent;
import com.soso.module.pay.core.event.PayPauseEvent;
import com.soso.module.pay.core.event.PaySuccedEvent;
import com.soso.module.pay.core.helper.AliPayHelper;
import com.soso.module.pay.core.helper.IPayHelperListen;
import com.soso.module.pay.core.helper.PayDtoHelper;
import com.soso.module.pay.core.helper.PayHelper;
import com.soso.module.pay.core.helper.WXPayHelper;
import com.soso.module.pay.core.module.PayModule;
import com.soso.network.bean.NetResultData;
import com.soso.network.callback.NetCallback;
import com.soso.network.exception.ErrorMessage;
import com.soso.sosolib.art.integration.manager.EventBusManager;
import com.soso.sosolib.utils.ConvertUtils;
import com.soso.sosolib.utils.GtNumberUtils;
import com.soso.sosolib.utils.LogUtils;
import com.soso.sosolib.utils.ToastManager;
import com.soso.uiwidget.widgets.dialog.BaseBottomDialog;
import com.tencent.mm.opensdk.modelpay.PayReq;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;

import io.reactivex.disposables.Disposable;

/**
 * Created by yangjingzhu on 2018/1/15.
 */

public class PayMethodsDialog extends BaseBottomDialog implements View.OnClickListener {

    private Context mContext;
    private TextView btnPay;
    private TextView paySumTv;
    private RecyclerView mRecyclerView;
    private ImageView ivClose;

    private InitPayDto mInitPayDto;
    private LiberPayStyleAdapter payTypeAdapter;

    //这个需要从上个页面传过来,支付流水号
    private String payOrderNo;


    public static PayMethodsDialog newInstance(String payOrderNo) {
        PayMethodsDialog dialog = new PayMethodsDialog();
        Bundle bundle = new Bundle();
        bundle.putString("payOrderNo", payOrderNo);
        dialog.setArguments(bundle);
        return dialog;
    }

    //供上层 具体跳转 实现
    public IPayHelperListen mIPayHelperListen;

    public PayMethodsDialog setPayHelperListen(IPayHelperListen payHelperListen) {
        mIPayHelperListen = payHelperListen;
        return this;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EventBusManager.getInstance().register(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBusManager.getInstance().unregister(this);
    }

    @Override
    public int getHeight() {
        return ConvertUtils.dp2px(480);
    }


    @Override
    public int getLayoutRes() {
        return R.layout.pay_dialog_pay_methods;
    }

    @Override
    public void bindView(View view) {
        getDialog().setCanceledOnTouchOutside(false);
        mContext = getActivity();
        payOrderNo = getArguments().getString("payOrderNo");

        mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        btnPay = (TextView) view.findViewById(R.id.btn_pay);
        paySumTv = (TextView) view.findViewById(R.id.tv_pay_sum);
        ivClose = (ImageView) view.findViewById(R.id.iv_close);

        btnPay.setOnClickListener(this);
        ivClose.setOnClickListener(this);

        payTypeAdapter = new LiberPayStyleAdapter();
        payTypeAdapter.setLayoutPosition(0);
        payTypeAdapter.setPayTypeListener(new PayTypeAdapter.OnPayTypeListener() {
            @Override
            public void onNoCanUsePayType() {
                btnPay.setEnabled(false);
            }
        });

        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mRecyclerView.setAdapter(payTypeAdapter);

        this.getDialog().setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface anInterface, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
                    EventBusManager.getInstance().post(new PayPauseEvent(payOrderNo));
                }
                return false;
            }
        });
        requestPayWay();
    }

    @Override
    protected boolean hideLoading() {
        return false;
    }

    /**
     * 获取支付平台支持的支付方式
     */
    private void requestPayWay() {
        PayModule.getPayType(payOrderNo, new NetCallback<InitPayDto>() {
                    @Override
                    public void onStart(Disposable d) {
                        addDisposable(d);
                    }

                    @Override
                    public void onSuccess(NetResultData<InitPayDto> netResult) {
                        InitPayDto initPay = netResult.getData();
                        if (initPay == null)
                            return;
                        paySumTv.setText(GtNumberUtils.addMoneyFenToYuan(initPay.getOrderTotalMoney()));

                        if (initPay.getPayWays() == null) {
                            initPay.setPayWays(new ArrayList<Integer>());
                        }

                        mInitPayDto = initPay;
                        if (initPay.getPayWays() != null && initPay.getPayWays().size() > 0) {
                            payTypeAdapter.setData(initPay.getPayWays());
                            btnPay.setEnabled(true);
                            payTypeAdapter.setLayoutPosition(0);
                            payTypeAdapter.setInitPayDto(mInitPayDto);
                            payTypeAdapter.notifyDataSetChanged();
                        }
                    }

                    @Override
                    public void onError(ErrorMessage error) {
                        initFailed();
                    }

                    @Override
                    public void onFinish() {
                        super.onFinish();
                        getUiViewStateHelper().showSuccess();
                    }
                }

        );
    }


    //第三方支付
    private void thirdPay() {
        if (payTypeAdapter == null || payTypeAdapter.getLayoutPosition() >= mInitPayDto.getPayWays().size() || payTypeAdapter.getLayoutPosition() == -1) {
            ToastManager.getInstance(mContext).showText("请选择有效的支付方式进行支付");
        }
        final int payWay = mInitPayDto.getPayWays().get(payTypeAdapter.getLayoutPosition());
        PayModule.pay(mContext, payWay, payOrderNo, new NetCallback<HashMap>() {

            @Override
            public void onStart(Disposable d) {
                addDisposable(d);
                btnPay.setEnabled(false);
                btnPay.setText("正在支付...");
            }


            @Override
            public void onSuccess(NetResultData<HashMap> netResult) {
                HashMap data = netResult.getData();
                LogUtils.d("生成缴费单成功");
                switch (payWay) {
                    case PayDtoHelper.PAY_WAY_BALANCE:
                        PayHelper.onPaySuccessed(mContext, payOrderNo);
                        break;
                    case PayDtoHelper.PAY_WAY_WECHAT:
                        Constant.payOrderNo = payOrderNo;
                        //微信
                        LinkedTreeMap<String, String> linkedTreeMap = (LinkedTreeMap) data.get("payInfo");
                        PayReq request = new PayReq();
                        request.appId = linkedTreeMap.get("appid");
                        request.partnerId = linkedTreeMap.get("partnerid");
                        request.prepayId = linkedTreeMap.get("prepayid");
                        request.packageValue = linkedTreeMap.get("extension");
                        request.nonceStr = linkedTreeMap.get("noncestr");
                        request.timeStamp = linkedTreeMap.get("timestamp");
                        request.sign = linkedTreeMap.get("sign");
                        WXPayHelper.pay(payOrderNo, request);
                        break;
                    case PayDtoHelper.PAY_WAY_ALI:
                        //支付宝
                        if (((LinkedTreeMap) data.get("payInfo")).size() > 0) {
                            Constant.payOrderNo = payOrderNo;
                            String prepayInfo = (String) ((LinkedTreeMap) data.get("payInfo")).get("prepayInfo");
                            if (!TextUtils.isEmpty(prepayInfo)) {
                                AliPayHelper.pay((Activity) mContext, payOrderNo, prepayInfo);
                            } else {
                                ToastManager.getInstance(mContext).showText("下单失败,请重试");
                            }
                        } else {
                            ToastManager.getInstance(mContext).showText("下单失败,请重试");
                        }

                        break;

                    case PayDtoHelper.PAY_WAY_GH_WECHAT:
                        Constant.payOrderNo = payOrderNo;
                        //工行微信
                        LinkedTreeMap<String, String> linkedTreeMapWeChat = (LinkedTreeMap) data.get("payInfo");
                        // TODO: 2018/9/20  wxAppId
                        Constants.PAY_LIST_IP = linkedTreeMapWeChat.get("urlListMain");
                        Constants.Start_B2C_IP = linkedTreeMapWeChat.get("urlPortal");
                        //已经在启动时注册好
//                        String wx_appid = AppConfig.WECHAT_APPID;
                        String wx_appid = linkedTreeMapWeChat.get("wxAppId");
                        WXPayAPI.init(getActivity().getApplicationContext(), wx_appid); //注册appid
                        ThirdPayReq wxreq = new ThirdPayReq();
//                        wxreq.setInterfaceName(linkedTreeMapWeChat.get("interfaceName"));
//                        wxreq.setInterfaceVersion(linkedTreeMapWeChat.get("interfaceVersion"));
                        wxreq.setInterfaceName("ICBC_WAPB_THIRD");
                        wxreq.setInterfaceVersion("1.0.0.0");
                        wxreq.setTranData(linkedTreeMapWeChat.get("tranData"));
                        wxreq.setMerSignMsg(linkedTreeMapWeChat.get("merSignMsg"));
                        wxreq.setMerCert(linkedTreeMapWeChat.get("merCert"));
//                        wxreq.setClientType(linkedTreeMapWeChat.get("clientType"));
                        wxreq.setClientType("23");
                        WXPayAPI.getInstance().doWXPay(getActivity(), wxreq);
                        break;

                    case PayDtoHelper.PAY_WAY_GH_ALI:
                        Constant.payOrderNo = payOrderNo;
                        //工行支付宝
                        LinkedTreeMap<String, String> linkedTreeMapAli = (LinkedTreeMap) data.get("payInfo");
                        Constants.PAY_LIST_IP = linkedTreeMapAli.get("urlListMain");
                        Constants.Start_B2C_IP = linkedTreeMapAli.get("urlPortal");
                        ThirdPayReq alireq = new ThirdPayReq();
//                        alireq.setInterfaceName(linkedTreeMapAli.get("interfaceName"));
//                        alireq.setInterfaceVersion(linkedTreeMapAli.get("interfaceVersion"));
                        alireq.setInterfaceName("ICBC_WAPB_THIRD");
                        alireq.setInterfaceVersion("1.0.0.0");
                        alireq.setTranData(linkedTreeMapAli.get("tranData"));
                        alireq.setMerSignMsg(linkedTreeMapAli.get("merSignMsg"));
                        alireq.setMerCert(linkedTreeMapAli.get("merCert"));
//                        alireq.setClientType(linkedTreeMapAli.get("clientType"));
                        alireq.setClientType("24");
                        AliPayAPI.getInstance().doAliPay(getActivity(), alireq);
                        break;

                }
            }

            @Override
            public void onError(ErrorMessage error) {
                switch (error.getErrorCode()) {
                    case 12010017:
                        ToastManager.getInstance(mContext).showText("订单已超时,无法支付,请重新下单");
                        break;
                    case 12010005:
                        ToastManager.getInstance(mContext).showText("订单已完成,无需支付");
                        break;
                    default:
                        ToastManager.getInstance(mContext).showText(error.getErrorMsg());

                }
                PayHelper.onPayFailed(mContext, payOrderNo);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                btnPay.setEnabled(true);
                btnPay.setText("立即付款");
            }
        });
    }


    //两个接口,加载失败时候调用
    private void initFailed() {
        ToastManager.getInstance(mContext).showText("亲,加载支付失败,请重试!");
    }


    //订单支付成功时,自动关闭当前activity
    @Subscribe(threadMode = ThreadMode.MAIN) //在ui线程执行
    public void onPaySuccedEvent(PaySuccedEvent event) {
        if (event.getPayOrderNo().equals(payOrderNo)) {
//            LiberPayHelper.goToPaySuccessNormalPage(getActivity(), payOrderNo, 0L,false);.
            if (mIPayHelperListen != null) {
                mIPayHelperListen.goToPaySuccessNormalPage(getActivity(), payOrderNo, 0L, false);
            }
            dismiss(isResumed());
            getActivity().finish();
        }
    }

    //订单支付失败时,自动关闭当前activity
    @Subscribe(threadMode = ThreadMode.MAIN) //在ui线程执行
    public void onPayFailedEvent(PayFailedEvent event) {
        if (event.getPayOrderNo().equals(payOrderNo)) {
            dismiss(isResumed());
        }
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.iv_close) {
            EventBusManager.getInstance().post(new PayPauseEvent(payOrderNo));
            dismiss(isResumed());

        } else if (i == R.id.btn_pay) {
            if (mInitPayDto == null || mInitPayDto.getPayWays() == null || mInitPayDto.getPayWays().size() <= 0) {
                ToastManager.getInstance(mContext).showText("请选择有效的支付方式进行支付");
                return;
            }
            thirdPay();

        }
    }

}
