package com.soso.module.pay.core.bean;

import java.util.List;

public class InitPayDto {


	/** 支付状态 */
	private int payStatus;
	/** 是否设置了支付密码（1：是；0：否） */
	private int pwdStatus;
	/** 余额支付时是否需要支付密码（1：是；0：否） */
	private int needPwd;
	/** 用户余额 */
	private long userBalance;
	/** 支付流水号 */
	private String payOrderNo;
	/** 订单总金额（单位：分） */
	private long orderTotalMoney;
	/** 商品名称 */
	private String subject;
	/** 商品描述 */
	private String body;

	/** 可使用的支付方式 */
	private List<Integer> payWays;

	public int getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(int payStatus) {
		this.payStatus = payStatus;
	}

	public int getPwdStatus() {
		return pwdStatus;
	}

	public void setPwdStatus(int pwdStatus) {
		this.pwdStatus = pwdStatus;
	}

	public int getNeedPwd() {
		return needPwd;
	}

	public void setNeedPwd(int needPwd) {
		this.needPwd = needPwd;
	}

	public long getUserBalance() {
		return userBalance;
	}

	public void setUserBalance(long userBalance) {
		this.userBalance = userBalance;
	}

	public String getPayOrderNo() {
		return payOrderNo;
	}

	public void setPayOrderNo(String payOrderNo) {
		this.payOrderNo = payOrderNo;
	}

	public long getOrderTotalMoney() {
		return orderTotalMoney;
	}

	public void setOrderTotalMoney(long orderTotalMoney) {
		this.orderTotalMoney = orderTotalMoney;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public List<Integer> getPayWays() {
		return payWays;
	}

	public void setPayWays(List<Integer> payWays) {
		this.payWays = payWays;
	}

}
