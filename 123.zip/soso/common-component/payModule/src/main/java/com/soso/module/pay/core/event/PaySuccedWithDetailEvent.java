package com.soso.module.pay.core.event;

/**
 * 支付成功后跳转到详情的时候 eventbus的回调
 * Created by EdgarNg on 2017/10/26.
 */

public class PaySuccedWithDetailEvent extends AbsPayEvent {
    public PaySuccedWithDetailEvent(String payOrderNo) {
        super(payOrderNo);
    }

    public PaySuccedWithDetailEvent(String payOrderNo, String payType, String orderNo) {
        super(payOrderNo, payType, orderNo);
    }
}
