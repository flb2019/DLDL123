package com.soso.module.pay.core.helper;

import com.soso.module.pay.core.bean.WXPayResqDto;
import com.tencent.mm.opensdk.modelpay.PayReq;

import java.util.HashMap;

/**
 * Created by EdgarNg on 2017/11/3.
 */

public class WXPayHelper extends WXHelper {

    private static HashMap<String, WXPayResqDto> mWXPayResq = new HashMap<>();


    public static void pay(String payOrderNo, PayReq payReq) {
        WXPayResqDto wxPayResqDto = new WXPayResqDto();
        wxPayResqDto.setmPayOrderNo(payOrderNo);
        wxPayResqDto.setmPrePayId(payReq.prepayId);
        mWXPayResq.put(payReq.prepayId, wxPayResqDto);
        mWxApi.sendReq(payReq);
    }

    /**
     * 已废弃,之前使用这个方法获取payorderno,现在不需要了
     * 根据微信的prepayId 获取请求参数(PayOrderNo等)
     *
     * @param prepayId
     * @return
     */
    @Deprecated
    public static WXPayResqDto getWXPayResqByPrepayId(String prepayId) {
        if (mWXPayResq != null) {
            return mWXPayResq.get(prepayId);
        } else {
            return null;
        }
    }

}
