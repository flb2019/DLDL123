package com.soso.module.pay.core.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.soso.module.pay.R;
import com.soso.module.pay.core.helper.PayHelperListen;
import com.soso.sosolib.BaseApplication;
import com.soso.uiactivity.base.fragment.SoSoCommonFragment;
import com.soso.uiwidget.widgets.title.ITitleWrapper;

/**
 * Created by sumerlin on 2019/2/25 2019/2/25.
 * Describe:
 */
public class PayMethodsMainFragment extends SoSoCommonFragment {
    public static PayMethodsMainFragment getInstance() {
        PayMethodsMainFragment fragment = new PayMethodsMainFragment();
        return fragment;
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.pay_fragment_main;
    }


    @Override
    protected ITitleWrapper initTitle(View titleView) {
        titleView.setVisibility(View.GONE);
        return null;
    }

    @Override
    protected void initBodyView(View view, @Nullable Bundle savedInstanceState) {
        super.initBodyView(view, savedInstanceState);

    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        View viewById = view.findViewById(R.id.fm_root);
        viewById.setBackgroundColor(BaseApplication.getResourcesObj().getColor(R.color.transparent));

        showSuccess();
        String callId = getActivity().getIntent().getStringExtra("callId");
        String payOrderNo = getActivity().getIntent().getStringExtra("payOrderNo");
        PayMethodsDialog.newInstance(payOrderNo)
                .setPayHelperListen(new PayHelperListen())
                .show(getFragmentManager());
    }
}
