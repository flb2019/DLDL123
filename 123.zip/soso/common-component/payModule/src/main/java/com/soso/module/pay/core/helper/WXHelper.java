package com.soso.module.pay.core.helper;

import android.content.Context;
import android.text.TextUtils;

import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

/**
 * Created by EdgarNg on 2017/11/3.
 */

public class WXHelper {
    protected static IWXAPI mWxApi;
    protected static String APPID;

    public static void registToWX(Context context, String WXAPPID) {
        APPID = WXAPPID;
        //AppConst.WEIXIN.APP_ID是指你应用在微信开放平台上的AppID，记得替换。
        mWxApi = WXAPIFactory.createWXAPI(context, APPID, false);
        // 将该app注册到微信
        mWxApi.registerApp(APPID);
    }


    public static String getAPPID() {
        if (TextUtils.isEmpty(APPID)) {
            throw new RuntimeException("pls call method registToWX() to set appid");
        }
        return APPID;
    }

    public static IWXAPI getWXApi() {
        if (mWxApi == null) {
            throw new RuntimeException("pls call method registToWX() to set mWxApi");
        }
        return mWxApi;
    }
}
