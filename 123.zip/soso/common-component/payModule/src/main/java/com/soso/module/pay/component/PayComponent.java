package com.soso.module.pay.component;

import android.support.v7.app.AppCompatActivity;

import com.billy.cc.core.component.CC;
import com.billy.cc.core.component.CCResult;
import com.billy.cc.core.component.IComponent;
import com.soso.module.pay.core.fragment.PayMethodsDialog;
import com.soso.module.pay.core.helper.PayHelperListen;

/**
 * Created by sumerlin on 2019/2/25 2019/2/25.
 * Describe:
 */
public class PayComponent implements IComponent {
    @Override
    public String getName() {
        return "PayComponent";
    }

    /**
     * 组件被调用时的入口
     * 要确保每个逻辑分支都会调用到CC.sendCCResult，
     * 包括try-catch,if-else,switch-case-default,startActivity
     *
     * @param cc 组件调用对象，可从此对象中获取相关信息
     * @return true:将异步调用CC.sendCCResult(...),用于异步实现相关功能，例如：文件加载、网络请求等
     * false:会同步调用CC.sendCCResult(...),即在onCall方法return之前调用，否则将被视为不合法的实现
     */
    @Override
    public boolean onCall(CC cc) {
        String actionName = cc.getActionName();
        switch (actionName) {
            case "openPayDialog":
                openPayDialog(cc);
                break;
        }
        CC.sendCCResult(cc.getCallId(), CCResult.success());
        return false;
    }

    private void openPayDialog(CC cc) {
//        HashMap<String, Object> paramMap = UIModelHelper.createParamMap();
//        paramMap.put("callId", cc.getCallId());
//        paramMap.put("payOrderNo", cc.getParamItem("payOrderNo",""));
//        UIModelHelper.startNextAct(cc.getContext(), PayMethodsMainFragment.class.getName(),paramMap );

        if(cc!= null && cc.getContext() instanceof AppCompatActivity){
            //String callId = getActivity().getIntent().getStringExtra("callId");
            //String payOrderNo = getActivity().getIntent().getStringExtra("payOrderNo");
            AppCompatActivity activity = (AppCompatActivity) cc.getContext();
            String callId = cc.getCallId();
            String payOrderNo = cc.getParamItem("payOrderNo", "");
            PayMethodsDialog.newInstance(payOrderNo)
                    .setPayHelperListen(new PayHelperListen())
                    .show(activity.getSupportFragmentManager());
        }


    }
}
