package com.soso.module.pay.core.event;

/**
 * 支付失败时候eventbus的回调
 * Created by EdgarNg on 2017/10/26.
 */

public class PayFailedEvent extends AbsPayEvent {
    public PayFailedEvent(String payOrderNo) {
        super(payOrderNo);
    }

    public PayFailedEvent(String payOrderNo, String payType) {
        super(payOrderNo, payType);
    }
}
