package com.soso.app.wxapi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.icbc.paysdk.WXPayAPI;
import com.soso.module.pay.core.Constant;
import com.soso.module.pay.core.helper.PayHelper;
import com.soso.sosolib.utils.ToastManager;
import com.tencent.mm.opensdk.constants.ConstantsAPI;
import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;

public class WXPayEntryActivity extends Activity implements IWXAPIEventHandler {

    private static final String TAG = "WXPayEntryActivity";

    private IWXAPI api;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        api = WXAPIFactory.createWXAPI(this, AppConfig.WECHAT_APPID);
//        api.handleIntent(getIntent(), this);
//        setContentView(R.layout.pay_result_handler_layout);
        if (WXPayAPI.getInstance() != null) {
            WXPayAPI.getInstance().getWXApi().handleIntent(getIntent(), this);
        } else {
            finish();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
//        api.handleIntent(intent, this);
        if (WXPayAPI.getInstance() != null) {
            WXPayAPI.getInstance().getWXApi().handleIntent(intent, this);
        }
    }

    @Override
    public void onReq(BaseReq req) {
        //......这里是用来处理接收的请求,暂不做讨论

    }

    @Override
    public void onResp(BaseResp resp) {
        if (resp.getType() == ConstantsAPI.COMMAND_PAY_BY_WX) {
            if (resp.errCode == BaseResp.ErrCode.ERR_OK) {
//                ToastManager.getInstance(WXPayEntryActivity.this).showText("支付成功");
//                LiberPayHelper.onPaySuccessed(WXPayEntryActivity.this, WXPayHelper.getWXPayResqByPrepayId(((PayResp) resp).prepayId).getmPayOrderNo());
//                LiberPayHelper.onPaySuccessed(WXPayEntryActivity.this, LiberPayPlaceDialog.getPayOrderNo() );
                PayHelper.onPaySuccessed(WXPayEntryActivity.this, Constant.payOrderNo);
                finish();

            } else if (resp.errCode == BaseResp.ErrCode.ERR_COMM) {
                ToastManager.getInstance(WXPayEntryActivity.this).showText("支付失败");
                finish();
            } else if (resp.errCode == BaseResp.ErrCode.ERR_USER_CANCEL) {
                ToastManager.getInstance(WXPayEntryActivity.this).showText("支付取消");
                finish();
            } else if (resp.errCode == BaseResp.ErrCode.ERR_AUTH_DENIED) {
                ToastManager.getInstance(WXPayEntryActivity.this).showText("支付拒绝");
                finish();
            }

        }

    }

//    @Override
//    public void onResume() {
//        StatService.onResume(this);
//        super.onResume();
//    }
//
//    @Override
//    public void onPause() {
//        StatService.onPause(this);
//        super.onPause();
//    }
}