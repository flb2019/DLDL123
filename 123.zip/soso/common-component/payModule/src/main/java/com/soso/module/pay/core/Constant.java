package com.soso.module.pay.core;

/**
 * Created by zhouwei2 on 2018/10/11.
 */

public class Constant {
    public static String payOrderNo;


}
