package com.soso.module.pay.core.helper;

import android.app.Activity;
import android.os.Looper;
import android.text.TextUtils;

import com.alipay.sdk.app.PayTask;
import com.soso.module.pay.core.bean.PayResult;
import com.soso.sosolib.utils.LogUtils;
import com.soso.sosolib.utils.ToastManager;

import java.util.Map;

/**
 * 支付宝支付
 * Created by EdgarNg on 2017/11/13.
 */

public class AliPayHelper {

    /**
     * 支付宝支付
     *
     * @param activity
     * @param payOrderNo 公司内部的支付流水号
     * @param orderInfo  支付宝的请求参数
     *                   9000	订单支付成功
     *                   8000	正在处理中，支付结果未知（有可能已经支付成功），请查询商户订单列表中订单的支付状态
     *                   4000	订单支付失败
     *                   5000	重复请求
     *                   6001	用户中途取消
     *                   6002	网络连接出错
     *                   6004	支付结果未知（有可能已经支付成功），请查询商户订单列表中订单的支付状态
     *                   其它	其它支付错误
     */
    public static void pay(final Activity activity, final String payOrderNo, final String orderInfo) {
        Runnable payRunnable = new Runnable() {
            @Override
            public void run() {
                PayTask alipay = new PayTask(activity);
                Map<String, String> result = alipay.payV2(orderInfo, true);

                PayResult payResult = new PayResult(result);
                String resultStatus = payResult.getResultStatus();
                // 判断resultStatus 为9000则代表支付成功
                if (TextUtils.equals(resultStatus, "9000")) {
                    // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                    PayHelper.onPaySuccessed(activity, payOrderNo);
                    LogUtils.d("支付成功!");
                } else if ("6001".equals(resultStatus)) {
                    try {
                        Looper.prepare();
                    } catch (Exception e) {

                    }
                    ToastManager.getInstance(activity).showText("支付取消");
                } else {
                    // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                    LogUtils.d("支付失败!");
                    PayHelper.onPayFailed(activity, payOrderNo);
                }
            }
        };

        Thread payThread = new Thread(payRunnable);
        payThread.start();
    }

}
