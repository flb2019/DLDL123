package com.soso.module.pay.core.module;

import android.content.Context;

import com.soso.module.pay.core.helper.WXPayHelper;
import com.soso.network.ApiFactory;
import com.soso.network.callback.NetCallback;
import com.soso.sosolib.utils.ToastManager;

import java.util.HashMap;

/**
 * Created by yangjingzhu on 2018/1/15.
 */

public class PayModule {
    private static String pay_methods_url = "";
    private static String pay_goto_url = "";
    //向支付平台获取支付方式
    public static void getPayType(String payOrderNo, NetCallback netCallback) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("payOrderNo", payOrderNo);
        ApiFactory.getInstance().postBody(pay_methods_url, params, netCallback);
    }

    //支付
    public static void pay(Context mContext, int payWay, String payOrderNo, NetCallback netCallback) {
        HashMap<String, Object> params = new HashMap<>();
        if (2 == payWay && !WXPayHelper.getWXApi().isWXAppInstalled()) {
            ToastManager.getInstance(mContext).showText("亲,你还没有安装微信哦,请安装微信后继续支付~");
        }

        params.put("payWay", payWay);
        params.put("payOrderNo", payOrderNo);
        ApiFactory.getInstance().postBody(pay_goto_url, params, netCallback);
    }

}
