package com.soso.module.pay.core.bean;

/**
 * 微信回调后的支付返回的实体类
 * 之前用来获取payorderno,现在不需要了
 * Created by EdgarNg on 2017/11/3.
 */
@Deprecated
public class WXPayResqDto {
    //微信支付前的id
    private String mPrePayId;
    //高德支付平台的payOrderNo
    private String mPayOrderNo;

    public String getmPrePayId() {
        return mPrePayId;
    }

    public void setmPrePayId(String mPrePayId) {
        this.mPrePayId = mPrePayId;
    }

    public String getmPayOrderNo() {
        return mPayOrderNo;
    }

    public void setmPayOrderNo(String mPayOrderNo) {
        this.mPayOrderNo = mPayOrderNo;
    }
}
