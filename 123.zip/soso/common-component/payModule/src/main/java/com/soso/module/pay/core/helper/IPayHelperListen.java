package com.soso.module.pay.core.helper;

import android.content.Context;

/**
 * Created by sumerlin on 2018/9/30 10:05.
 * Describe:
 */
public interface IPayHelperListen {

    /**
     * 跳去通用的支付失败页面
     *
     * @param mContext
     * @param payOrderNo
     */
    void goToPayFailNormalPage(Context mContext, String payOrderNo);

    /**
     * 跳去通用的支付成功页面
     *
     * @param mContext
     * @param payOrderNo
     */
    void goToPaySuccessNormalPage(Context mContext, String payOrderNo, long payPrice, boolean isCommitToService);

}
