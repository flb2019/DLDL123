package com.soso.module.pay.core.adapter;

import android.support.annotation.NonNull;

import com.soso.module.pay.R;
import com.soso.module.pay.core.helper.PayDtoHelper;

/**
 * Created by yangjingzhu on 2018/1/15.
 */

public class LiberPayStyleAdapter extends PayTypeAdapter {

    @Override
    protected int getItemLayoutId() {
        return R.layout.pay_item_choice_paytype;
    }

    protected int getDrawableRes(@NonNull Integer item) {
        switch (item) {
            case PayDtoHelper.PAY_WAY_BALANCE:
                if (mInitPayDto.getUserBalance() < mInitPayDto.getOrderTotalMoney()) {
                    //不够钱给
                    return R.mipmap.pay_balance_gray;
                } else {
                    return R.mipmap.pay_balance;
                }
            case PayDtoHelper.PAY_WAY_WECHAT:
                return R.mipmap.pay_weixin;
            case PayDtoHelper.PAY_WAY_ALI:
                return R.mipmap.pay_zhifubao;

            case PayDtoHelper.PAY_WAY_GH_WECHAT:
                return R.mipmap.pay_weixin;
            case PayDtoHelper.PAY_WAY_GH_ALI:
                return R.mipmap.pay_zhifubao;
            default:
                return R.mipmap.pay_balance_gray;
        }
    }

//    @Override
//    protected int getDrawableRes(@NonNull Integer item) {
//        switch (item) {
//            case 1:
//                if (mInitPayDto.getUserBalance() < mInitPayDto.getOrderTotalMoney()) {
//                    //不够钱给
//                    return R.mipmap.pay_balance_gray;
//                } else {
//                    return R.mipmap.pay_balance;
//                }
//            case 2:
//                return R.mipmap.pay_wechat;
//            case 3:
//                return R.mipmap.pay_zhifubao;
//            default:
//                return R.mipmap.pay_balance_gray;
//        }
//    }
}