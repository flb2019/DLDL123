package com.soso.module.pay.core.fragment;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.soso.module.pay.R;
import com.soso.module.pay.core.helper.PayHelper;
import com.soso.uiactivity.base.fragment.SoSoCommonFragment;
import com.soso.uiwidget.widgets.title.ITitleWrapper;


/**
 * 支付成功的页面
 * Created by EdgarNg on 2017/9/25.
 */
public class PaySuccessNormalFragment extends SoSoCommonFragment {

    protected String payOrderNo;


    @Nullable
    @Override
    protected int getLayoutResId() {
        return R.layout.pay_fragment_pay_succ_normal;
    }
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        payOrderNo = getActivity().getIntent().getStringExtra("payOrderNo");
    }

    @Override
    protected ITitleWrapper initTitle(View titleView) {


        return new ITitleWrapper() {
            @Override
            public int getTitleBarType() {
                return FLAG_BACK | FLAG_TXT;
            }

            @Override
            public boolean onPageBack(View view) {
                PayHelper.onPaySuccessedWithBack(getActivity(), payOrderNo);
                return false;
            }

            @Override
            public String getTitle(View view) {
                return "支付成功";
            }
        };
    }



    @Override
    protected void initBodyView(View view, @Nullable Bundle savedInstanceState) {
        super.initBodyView(view, savedInstanceState);
        view.findViewById(R.id.txtDetail).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击查看详情
                PayHelper.onPaySuccessedWithDetail(getActivity(), payOrderNo);
                getActivity().finish();
            }
        });
    }
}
