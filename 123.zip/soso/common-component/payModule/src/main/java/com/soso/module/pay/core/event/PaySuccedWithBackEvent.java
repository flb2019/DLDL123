package com.soso.module.pay.core.event;

/**
 * 支付成功后直接返回的时候 eventbus的回调
 * Created by EdgarNg on 2017/10/26.
 */

public class PaySuccedWithBackEvent extends AbsPayEvent {
    public PaySuccedWithBackEvent(String payOrderNo) {
        super(payOrderNo);
    }
}
