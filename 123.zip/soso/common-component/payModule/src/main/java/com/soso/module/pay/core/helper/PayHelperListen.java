package com.soso.module.pay.core.helper;

import android.content.Context;

import com.soso.module.pay.core.fragment.PayFailNormalFragment;
import com.soso.uiactivity.base.UIModelHelper;

import java.util.HashMap;

/**
 * Created by sumerlin on 2018/9/30 10:15.
 * Describe:
 */
public class PayHelperListen implements IPayHelperListen {
    private ListenModel mListenModel;

    public static class ListenModel {
        //    public int serviceStatus;//业务订单状态（-1:无效订单，0:待付款，1:待发货， 2:已发货，3:已完成, 4:已关闭，5:售后 6:退款中 7:已退款）
        public Integer serviceStatus;

        public ListenModel(Integer serviceStatus) {
            this.serviceStatus = serviceStatus;
        }
    }

    public PayHelperListen() {
    }

    public PayHelperListen(ListenModel listenModel) {
        this.mListenModel = listenModel;
    }

    @Override
    public void goToPayFailNormalPage(Context mContext, String payOrderNo) {
        HashMap params = new HashMap();
        params.put("payOrderNo", payOrderNo);
        UIModelHelper.startNextAct(mContext, PayFailNormalFragment.class.getName(), params);
    }

    @Override
    public void goToPaySuccessNormalPage(Context mContext, String payOrderNo, long payPrice, boolean isCommitToService) {
//        LiberPaySuccessNormalFragment.startFragment(mContext , null ,  payOrderNo, payPrice, isCommitToService);
    }
}
