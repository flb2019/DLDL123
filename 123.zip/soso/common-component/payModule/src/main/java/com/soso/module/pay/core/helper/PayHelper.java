package com.soso.module.pay.core.helper;

import android.content.Context;

import com.soso.module.pay.core.event.PayFailedEvent;
import com.soso.module.pay.core.event.PayFailedWithBackEvent;
import com.soso.module.pay.core.event.PayFailedWithDetailEvent;
import com.soso.module.pay.core.event.PaySuccedEvent;
import com.soso.module.pay.core.event.PaySuccedWithBackEvent;
import com.soso.module.pay.core.event.PaySuccedWithDetailEvent;
import com.soso.module.pay.core.fragment.PayFailNormalFragment;
import com.soso.module.pay.core.fragment.PaySuccessNormalFragment;
import com.soso.sosolib.art.integration.manager.EventBusManager;
import com.soso.uiactivity.base.UIModelHelper;

import java.util.HashMap;

/**
 * Created by EdgarNg on 2017/10/26.
 */

public class PayHelper {
    /**
     * 支付成功后调用
     *
     * @param mContext
     * @param payOrderNo
     */
    public static void onPaySuccessed(Context mContext, String payOrderNo) {
        PaySuccedEvent paySuccedEvent = new PaySuccedEvent(payOrderNo);
        EventBusManager.getInstance().post(paySuccedEvent);

    }

    /**
     * 支付失败后跳转到再次支付
     *
     * @param mContext
     * @param payOrderNo
     */
    public static void onPayFailed(Context mContext, String payOrderNo) {
        PayFailedEvent payFailedEvent = new PayFailedEvent(payOrderNo);
        EventBusManager.getInstance().post(payFailedEvent);
    }

    /**
     * 支付成功后直接返回
     * (当使用通用支付成功页/失败页时会调用,支付模块不会主动调用)
     *
     * @param mContext
     * @param payOrderNo
     */
    public static void onPaySuccessedWithBack(Context mContext, String payOrderNo) {
        PaySuccedWithBackEvent paySuccedWithoutDetailEvent = new PaySuccedWithBackEvent(payOrderNo);
        EventBusManager.getInstance().post(paySuccedWithoutDetailEvent);

    }

    /**
     * 支付失败后直接返回
     * (当使用通用支付成功页/失败页时会调用,支付模块不会主动调用)
     *
     * @param mContext
     * @param payOrderNo
     */
    public static void onPayFailedWithBack(Context mContext, String payOrderNo) {
        PayFailedWithBackEvent payFailedWithoutDetailEvent = new PayFailedWithBackEvent(payOrderNo);
        EventBusManager.getInstance().post(payFailedWithoutDetailEvent);

    }


    /**
     * 支付成功后 跳到业务详情页
     * (当使用通用支付成功页/失败页时会调用,支付模块不会主动调用)
     *
     * @param mContext
     * @param payOrderNo
     */
    public static void onPaySuccessedWithDetail(Context mContext, String payOrderNo) {
        PaySuccedWithDetailEvent paySuccedWithoutDetailEvent = new PaySuccedWithDetailEvent(payOrderNo);
        EventBusManager.getInstance().post(paySuccedWithoutDetailEvent);

    }

    /**
     * 支付失败后 跳到业务详情页
     * (当使用通用支付成功页/失败页时会调用,支付模块不会主动调用)
     *
     * @param mContext
     * @param payOrderNo
     */
    public static void onPayFailedWithDetail(Context mContext, String payOrderNo) {
        PayFailedWithDetailEvent payFailedWithDetailEvent = new PayFailedWithDetailEvent(payOrderNo);
        EventBusManager.getInstance().post(payFailedWithDetailEvent);

    }

    /**
     * 跳去通用的支付失败页面
     *
     * @param mContext
     * @param payOrderNo
     */
    public static void goToPayFailNormalPage(Context mContext, String payOrderNo) {
        HashMap params = new HashMap();
        params.put("payOrderNo", payOrderNo);
        UIModelHelper.startNextAct(mContext, PayFailNormalFragment.class.getName(), params);
    }

    /**
     * 跳去通用的支付成功页面
     *
     * @param mContext
     * @param payOrderNo
     */
    public static void goToPaySuccessNormalPage(Context mContext, String payOrderNo) {
        HashMap params = new HashMap();
        params.put("payOrderNo", payOrderNo);
        UIModelHelper.startNextAct(mContext, PaySuccessNormalFragment.class.getName(), params);
    }

}
