package com.soso.module.pay.core.event;

import android.text.TextUtils;

/**
 * 支付的eventbus的回调
 * Created by EdgarNg on 2017/10/26.
 */

public abstract class AbsPayEvent {
    //支付方式:微信
    public static final String PAYTYPE_WX = "PAYTYPE_WX";
    //支付方式:支付宝
    public static final String PAYTYPE_ALI = "PAYTYPE_ALI";
    //支付方式:高德的余额,暂时仅只用于测试
    public static final String PAYTYPE_GT = "PAYTYPE_GT";


    public AbsPayEvent(String payOrderNo) {
        this(payOrderNo, "");
    }

    public AbsPayEvent(String payOrderNo, String payType) {
        this(payOrderNo, payType, "");
    }

    public AbsPayEvent(String payOrderNo, String payType, String orderNo) {
        this.payOrderNo = payOrderNo;
        this.payType = payType;
        this.orderNo = orderNo;
    }

    //支付流水号
    protected String payOrderNo;

    //支付方式
    protected String payType;

    //附加字段,orderNo
    protected String orderNo;

    //附加字段,看业务需求
    protected String extData;

    public String getOrderNo() {
        return orderNo;
    }

    public String getPayOrderNo() {
        return payOrderNo;
    }

    public String getPayType() {
        return TextUtils.isEmpty(payType) ? "" : payType;
    }

    public String getExtData() {
        return extData;
    }

    public void setPayOrderNo(String payOrderNo) {
        this.payOrderNo = payOrderNo;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }



    public void setExtData(String extData) {
        this.extData = extData;
    }
}
