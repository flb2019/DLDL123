package com.soso.module.pay.todo;

/**
 * Created by sumerlin on 2019/2/25 2019/2/25.
 * Describe:
 */
public class Config {
    //微信 APPID -- 高维
    public static String WECHAT_APPID = "wx58f5ec7f363bc6ff";//(2.8版本以及2.8以上版本用高维)
}
