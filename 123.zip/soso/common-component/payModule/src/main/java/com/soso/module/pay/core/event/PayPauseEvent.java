package com.soso.module.pay.core.event;

/**
 * Created by 52280 on 2018/1/19.
 */

public class PayPauseEvent {
    public String payOrderNo;

    public PayPauseEvent(String payOrderNo) {
        this.payOrderNo = payOrderNo;
    }
}
