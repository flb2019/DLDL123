package com.soso.uiactivity.base.activity;

/**
 * Created by sumerlin on 2019/2/21 2019/2/21.
 * Describe:
 */
public class BaseMvpStubActivitySingleTask extends  BaseMvpStubActivity {
}
