package com.soso.uiactivity.base;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment;

import com.soso.uiactivity.base.activity.BaseMvpStubActivity;
import com.soso.uiactivity.base.activity.BaseMvpStubActivitySingleTask;

import java.io.Serializable;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;


public class UIModelHelper {
    // Activity的启动模式key
    public static final String START_TYPE = "START_TYPE";
    // Activity的启动模式 -singleTask;
    public static final String START_TYPE_SINGLETASK = "START_TYPE_SINGLETASK";
    // tag - TAG_JUMP_FROM
    public static final String TAG_JUMP_FROM = "TAG_JUMP_FROM";

    /**
     * 创建Fragment
     *
     * @param className
     * @return
     */
    public static /*SoSoCommonFragment*/ Fragment createFragment(String className) {
        try {
            Class<?> c = Class.forName(className);
            return /*(SoSoCommonFragment)*/ (Fragment) c.newInstance();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    private static Class getStartActivityType(String type) {
        switch (type) {
            case START_TYPE_SINGLETASK:
                return BaseMvpStubActivitySingleTask.class;
            default:
                return BaseMvpStubActivity.class;
        }
    }

    private static Class getStartMvpActivityType(String type) {
        switch (type) {
            case START_TYPE_SINGLETASK:
                return BaseMvpStubActivitySingleTask.class;
            default:
                return BaseMvpStubActivity.class;
        }
    }

    /**
     * 启动页面
     *
     * @param c
     * @param className
     */
    public static void startNextAct(Context c, String className) {
        Intent i = new Intent(c, BaseMvpStubActivity.class);
        i.putExtra("fragment", className);
        if (!(c instanceof Activity)) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        c.startActivity(i);
    }

    /**
     * 启动页面
     *
     * @param c
     * @param className
     * @param params
     */
    public static void startNextAct(Context c, String className, HashMap<String, Object> params) {
        String activityType = "";
        if (params != null && params.containsKey(START_TYPE)) {
            activityType = (String) params.get(START_TYPE);
        }
        Intent i = new Intent(c, getStartActivityType(activityType));
        if (params != null) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                putExtra(i, entry);
            }
        }
        i.putExtra("fragment", className);
        if (!(c instanceof Activity)) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        c.startActivity(i);
    }

    /**
     * 启动页面
     *
     * @param c
     * @param className
     * @param params
     */
    public static void startNextMvpAct(Context c, String className, HashMap<String, Object> params) {
        String activityType = "";
        if (params != null && params.containsKey(START_TYPE)) {
            activityType = (String) params.get(START_TYPE);
        }
        Intent i = new Intent(c, getStartMvpActivityType(activityType));
        if (params != null) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                putExtra(i, entry);
            }
        }
        i.putExtra("fragment", className);
        if (!(c instanceof Activity)) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        c.startActivity(i);
    }



    /**
     * 启动页面
     *
     * @param c
     * @param className
     * @param params
     */
    public static void startNextAct(Context c, String className, Class stubActivity, HashMap<String, Object> params) {
        Intent i = new Intent(c, stubActivity);
        if (params != null) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                putExtra(i, entry);
            }
        }
        i.putExtra("fragment", className);
        if (!(c instanceof Activity)) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        c.startActivity(i);
    }

    /**
     * 启动页面
     *
     * @param c
     * @param className
     * @param params
     * @param requestCode
     */
    public static void startNextActForResult(Activity c, String className, HashMap<String, Object> params, int requestCode) {
        Intent i = new Intent(c, BaseMvpStubActivity.class);
        if (params != null) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                putExtra(i, entry);
            }
        }
        i.putExtra("fragment", className);
        c.startActivityForResult(i, requestCode);
    }

    /**
     * 启动页面
     *
     * @param c
     * @param className
     * @param params
     * @param requestCode
     */
    public static void startNextActForResult2(Fragment c, String className, HashMap<String, Object> params, int requestCode) {
        Intent i = new Intent(c.getActivity(),BaseMvpStubActivity.class);
        if (params != null) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                putExtra(i, entry);
            }
        }
        i.putExtra("fragment", className);
        c.startActivityForResult(i, requestCode);
    }

    /**
     * 启动页面
     *
     * @param a
     * @param className
     * @param requestCode
     */
    public static void startNextActForResult(Activity a, String className, int requestCode) {
        Intent i = new Intent(a, BaseMvpStubActivity.class);
        i.putExtra("fragment", className);
        a.startActivityForResult(i, requestCode);
    }

/*    *//**
     * 启动页面
     * @param c
     * @param className
     *//*
    public static void startNextActNoSoft(Context c, String className){
		Intent i = new Intent(c, StubActivityNoSoft.class);
		i.putExtra("fragment", className);
		c.startActivity(i);
	}

    */

    /**
     * 启动页面
     *
     * @param
     * @param
     * @param
     * @param
     *//*
    public static void startNextActNoSoft(Context c, String className,String flag,HashMap<String, Object> hash){
		Intent i = new Intent(c, StubActivityNoSoft.class);
		i.putExtra("fragment", className);
		i.putExtra(flag, hash);
		c.startActivity(i);
	}*/
    public static boolean isMoreThanToday(long time) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(System.currentTimeMillis());
        c.add(Calendar.DAY_OF_YEAR, 1);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long tomTime = c.getTimeInMillis();

        return time > tomTime;
    }

    public static boolean isMoreThanyesterday(long time) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(System.currentTimeMillis());
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long tomTime = c.getTimeInMillis();

        return time > tomTime;
    }

    public static String twoDigital(int i) {
        if (i < 10) {
            return "0" + i;
        } else {
            return String.valueOf(i);
        }
    }

    /**
     * 添加参数
     *
     * @param intent
     * @param entry
     */
    private static void putExtra(Intent intent, Map.Entry<String, Object> entry) {
        String name = entry.getKey();
        Object value = entry.getValue();
        if (value instanceof CharSequence) {
            intent.putExtra(name, (CharSequence) value);
        } else if (value instanceof CharSequence[]) {
            intent.putExtra(name, (CharSequence[]) value);
        } else if (value instanceof Boolean) {
            intent.putExtra(name, (Boolean) value);
        } else if (value instanceof Boolean[]) {
            intent.putExtra(name, (Boolean[]) value);
        } else if (value instanceof Bundle) {
            intent.putExtra(name, (Bundle) value);
        } else if (value instanceof Byte) {
            intent.putExtra(name, (Byte) value);
        } else if (value instanceof Byte[]) {
            intent.putExtra(name, (Byte[]) value);
        } else if (value instanceof Character) {
            intent.putExtra(name, (Character) value);
        } else if (value instanceof Character[]) {
            intent.putExtra(name, (Character[]) value);
        } else if (value instanceof Double) {
            intent.putExtra(name, (Double) value);
        } else if (value instanceof Double[]) {
            intent.putExtra(name, (Double[]) value);
        } else if (value instanceof Float) {
            intent.putExtra(name, (Float) value);
        } else if (value instanceof Float[]) {
            intent.putExtra(name, (Float[]) value);
        } else if (value instanceof Integer) {
            intent.putExtra(name, (Integer) value);
        } else if (value instanceof Integer[]) {
            intent.putExtra(name, (Integer[]) value);
        } else if (value instanceof Long) {
            intent.putExtra(name, (Long) value);
        } else if (value instanceof Long[]) {
            intent.putExtra(name, (Long[]) value);
        } else if (value instanceof Parcelable) {
            intent.putExtra(name, (Parcelable) value);
        } else if (value instanceof Serializable) {
            intent.putExtra(name, (Serializable) value);
        }
    }

    public static HashMap<String, Object> createParamMap() {
        return new HashMap<String, Object>();
    }
}
