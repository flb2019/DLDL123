package com.soso.uiactivity.mvp;

import com.soso.sosoframe.base.mvp.IView;
import com.soso.uiwidget.hepler.loadsir.UiViewStateAction;

/**
 * Created by sumerlin on 2019/2/24 2019/2/24.
 * Describe:
 */
public interface SoSoView extends IView, UiViewStateAction {
    @Override
    default void showLoadView() {
        showLoading();

    }

    @Override
    default void hideLoadView() {
        showSuccess();
    }

    @Override
    default void showCircularLoading() {

    }

    @Override
    default void showSuccess() {

    }

    @Override
    default void showError() {

    }

    @Override
    default void showEmpty() {

    }
}
