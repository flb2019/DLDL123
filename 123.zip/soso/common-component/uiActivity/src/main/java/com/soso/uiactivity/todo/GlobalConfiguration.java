package com.soso.uiactivity.todo;

import android.app.Application;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;

import com.soso.sosolib.art.base.delegate.AppLifecycles;
import com.soso.sosolib.art.di.module.GlobalConfigModule;
import com.soso.sosolib.art.integration.ConfigModule;
import com.soso.sosolib.utils.LogUtils;
import com.soso.uiwidget.hepler.loadsir.LSPostUtil;
import com.soso.uiwidget.hepler.loadsir.core.LoadSir;
import com.soso.uiwidget.hepler.loadsir.custom.CircularLoadingCallback;
import com.soso.uiwidget.hepler.loadsir.custom.CustomCallback;
import com.soso.uiwidget.hepler.loadsir.custom.EmptyCallback;
import com.soso.uiwidget.hepler.loadsir.custom.ErrorCallback;
import com.soso.uiwidget.hepler.loadsir.custom.LoadingCallback;

import java.util.List;

/**
 * Created by sumerlin on 2019/2/20 2019/2/20.
 * Describe: app 单独配置
 */
public class GlobalConfiguration implements ConfigModule {


    @Override
    public void applyOptions(Context context, GlobalConfigModule.Builder builder) {
    }

    @Override
    public void injectAppLifecycle(Context context, List<AppLifecycles> lifecycles) {
        lifecycles.add(new AppLifecycles() {
            @Override
            public void attachBaseContext(@NonNull Context base) {

            }

            @Override
            public void onCreate(@NonNull Application application) {
                LogUtils.i("uiActivity.....GlobalConfiguration.....injectAppLifecycle...........onCreate");
                initLoadSir();
            }

            @Override
            public void onTerminate(@NonNull Application application) {

            }
        });

    }

    @Override
    public void injectActivityLifecycle(Context context, List<Application.ActivityLifecycleCallbacks> lifecycles) {

    }

    @Override
    public void injectFragmentLifecycle(Context context, List<FragmentManager.FragmentLifecycleCallbacks> lifecycles) {

    }


    /**
     * 配置loadSir，单例获取LoadSir，添加相关状态
     */
    private void initLoadSir() {
        LoadSir.beginBuilder()
                .addCallback(new ErrorCallback())
                .addCallback(new EmptyCallback())
                .addCallback(new LoadingCallback())
                .addCallback(new CustomCallback())
                .addCallback(new CircularLoadingCallback())
                .setDefaultCallback(LoadingCallback.class)
                .commit();

        LSPostUtil.setEmptyClazz(EmptyCallback.class);
        LSPostUtil.setErrorClazz(ErrorCallback.class);
        LSPostUtil.setLoadingClazz(LoadingCallback.class);
    }
}
