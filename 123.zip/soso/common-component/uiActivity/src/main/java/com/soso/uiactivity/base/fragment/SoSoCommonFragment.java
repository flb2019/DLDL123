package com.soso.uiactivity.base.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.soso.sosoframe.R;
import com.soso.sosoframe.base.fragment.BaseArtMvpFragment;
import com.soso.sosoframe.base.mvp.IPresenter;
import com.soso.sosolib.utils.ToastManager;
import com.soso.uiwidget.hepler.loadsir.UiViewStateAction;
import com.soso.uiwidget.hepler.loadsir.UiViewStateHelper;
import com.soso.uiwidget.hepler.loadsir.core.LoadService;
import com.soso.uiwidget.widgets.title.ITitleWrapper;
import com.soso.uiwidget.widgets.title.SosoTitileView;

/**
 * Created by sumerlin on 2019/2/18 2019/2/18.
 * Describe:
 */
public abstract class SoSoCommonFragment<P extends IPresenter> extends BaseArtMvpFragment<P> implements UiViewStateAction {

    //无标题栏
    public static final int FLAG_NONE = 0;
    //有文本
    public static final int FLAG_TXT = 1;
    //有返回
    public static final int FLAG_BACK = 2;
    //有按钮
    public static final int FLAG_BTN = 4;
    //有按钮2
    public static final int FLAG_BTN2 = 8;
    //有按钮
    public static final int FLAG_ALL = FLAG_TXT | FLAG_BACK | FLAG_BTN | FLAG_BTN2;

    protected View mRootView;
    private UiViewStateHelper mUiViewStateHelper;


    /*****************初始化及界面渲染 - start ******************************/
    /**
     * 获取基层界面文件
     *
     * @return
     */
    protected int getContentView() {
        return R.layout.abs_fragment;
    }

    /**
     * 正文文件 layout res Id
     *
     * @return
     */
    protected abstract int getLayoutResId();

//    /**
//     * 界面初始化组件的地方,获取titlebartype
//     *
//     * @return
//     */
//    protected abstract int getTitleBarType();

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
//        if (hideLoading()) {
//            showSuccess();
//        }
//        showSuccess();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public View initView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = null;
        try {
            //【1】初始化基层组件
            v = inflater.inflate(getContentView(), null);
            ViewGroup root = (ViewGroup) v.findViewById(R.id.fm_root);
            //【2】加载标题组件
//            View titleView = null;
//            if (getTitleViewResId() > 0 && getTitleBarType() != FLAG_NONE) {
//                titleView = inflater.inflate(getTitleViewResId(), root, false);
//                if (titleView != null) {
//                    int num = isTitleFloating() ? 1 : 0;
//                    root.addView(titleView, num);
//                }
//            }

            ///dddd
            SosoTitileView titleView = new SosoTitileView(this.getActivity());
            root.addView(titleView, 0);
            //初始化标题
            //initTitle();
            ITitleWrapper iTitleWrapper = initTitle(titleView);
            if (iTitleWrapper != null) {
                titleView.config(iTitleWrapper);
            }
            //【3】加载正文组件
            ViewGroup content = (ViewGroup) v.findViewById(R.id.fm_content);
            initLoadSir(content);
            if (getLayoutResId() > 0) {
                View body = inflater.inflate(getLayoutResId(), content, false);
                content.addView(body, 0);
            }
            mRootView = root;
            //页面初始化自己的组件
            initBodyView(root, savedInstanceState);
            initData(savedInstanceState);
        } catch (Exception e) {
            ToastManager.getInstance(getActivity()).showText(
                    R.string.error_common);
            e.printStackTrace();
        }

        return v;

    }

    /***************************   标题 - start****************************/

    /**
     * 标题栏是否使用市面酷炫的标题在内容的上面
     *
     * @return true是在上面, false是普通的那种
     */
    protected boolean isTitleFloating() {
        return false;
    }

    protected ITitleWrapper initTitle(View titleView) {
        //初始化标题类型
        //setTitleType(view, getTitleBarType());
        return null;
    }

    /***************************   正文 - start****************************/
    /**
     * 界面初始化数据的地方
     *
     * @param view
     * @param savedInstanceState
     */
    protected void initBodyView(View view, @Nullable Bundle savedInstanceState) {

    }


    /**************************** loadsir - start ***************************/
    private LoadService mLoadService;

    private View initLoadSir(View view) {
//        mLoadService = LoadSir.getDefault().register(view, new Callback.OnReloadListener() {
//            @Override
//            public void onReload(View v) {
//                SoSoFrameFragment.this.onReload(v);
//            }
//        });
//        return mLoadService.getLoadLayout();

        mUiViewStateHelper = UiViewStateHelper.createHelper(view, new OnReloadListener() {
            @Override
            public void onReloadAction(View v) {
                onReload(v);
            }
        });
        mLoadService = mUiViewStateHelper.getLoadService();
        return mUiViewStateHelper.getLoadLayout();
    }

    @Override
    public void showLoading() {
        mUiViewStateHelper.showLoading();
    }

    @Override
    public void showCircularLoading() {
        mUiViewStateHelper.showCircularLoading();
    }

    @Override
    public void showSuccess() {
        mUiViewStateHelper.showSuccess();
    }

    @Override
    public void showError() {
        mUiViewStateHelper.showError();
    }

    @Override
    public void showEmpty() {
        mUiViewStateHelper.showEmpty();
    }

    protected void onReload(View v) {
    }
}
