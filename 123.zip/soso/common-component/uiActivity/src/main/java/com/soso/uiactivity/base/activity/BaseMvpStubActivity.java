package com.soso.uiactivity.base.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.soso.sosoframe.R;
import com.soso.sosoframe.base.activity.BaseMvpActivity;
import com.soso.sosoframe.base.mvp.IPresenter;
import com.soso.sosolib.utils.KeyboardUtils;
import com.soso.uiactivity.base.UIModelHelper;
import com.soso.uiactivity.base.fragment.SoSoCommonFragment;

/**
 * Created by sumerlin on 2019/2/21 2019/2/21.
 * Describe:
 */
public class BaseMvpStubActivity <P extends IPresenter>  extends BaseMvpActivity<P> {
    private SoSoCommonFragment fragment;
    @Override
    public int getLayoutResId(@Nullable Bundle savedInstanceState) {
        return R.layout.abs_activity;
    }

    @Override
    public void initView(@Nullable Bundle savedInstanceState) {
        super.initView(savedInstanceState);
        String fragmentClass = this.getIntent().getStringExtra("fragment");
        if (fragmentClass == null) {
            // fragmentClass为空的时候,就跳到登陆页
//            fragmentClass = LoginFragment.class.getName();
        }
        fragment = (SoSoCommonFragment) UIModelHelper.createFragment(fragmentClass);
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction().add(R.id.content_frame, fragment).commit();
        }
    }

    @Override
    protected void onPause() {
        hideKeyBoard();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
//        if (fragment != null) {
//            if (!fragment.onBackPressed()) {
//                super.onBackPressed();
//            }
//        } else {
//            super.onBackPressed();
//        }
        super.onBackPressed();
    }

    /*****基类对外提供公共方法***********************************************************************/
    /**
     * 隐藏键盘
     */
    protected void hideKeyBoard() {
        View view = getCurrentFocus();
        if (view != null) {
            KeyboardUtils.hideSoftInput(this);
        }
    }
}
