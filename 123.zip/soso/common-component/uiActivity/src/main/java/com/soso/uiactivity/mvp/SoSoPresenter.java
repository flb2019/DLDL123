package com.soso.uiactivity.mvp;

import com.soso.sosoframe.base.mvp.BaseModel;
import com.soso.sosoframe.base.mvp.BasePresenter;

/**
 * Created by sumerlin on 2019/2/24 2019/2/24.
 * Describe:
 */
public class SoSoPresenter<V extends SoSoView> extends BasePresenter<V, BaseModel> {
    /**
     * 如果当前页面不需要操作数据,只需要 View 层,则使用此构造函数
     *
     * @param rootView
     */
    public SoSoPresenter(V rootView) {
        super(rootView);
    }

    public SoSoPresenter() {
        super();
    }

}
