package com.soso.common.assist;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.soso.common.assist.keeplive.service.AutoHideNotificationService;
import com.soso.common.assist.keeplive.service.ForegroundService;
import com.soso.common.assist.keeplive.service.GuardService;
import com.soso.common.assist.keeplive.service.KeepDoubleStartService;
import com.soso.common.assist.keeplive.service.OtherGuardService;
import com.soso.sosolib.utils.ToastManager;
import com.umeng.analytics.MobclickAgent;

public class AssistMainActivity extends AppCompatActivity {

    public static void start(Context context) {
        Intent intent = new Intent(context, AssistMainActivity.class);
        context.startActivity(intent);

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.assist_activity_assist_main);
        findViewById(R.id.btn_LeakCanary).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Test instance = Test.getInstance(AssistMainActivity.this);
            }
        });
        findViewById(R.id.btn_umeng_event).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MobclickAgent.onEvent(AssistMainActivity.this,"event_umeng_test");
                ToastManager.getInstance(AssistMainActivity.this).showText("点击");
            }
        });

        findViewById(R.id.btn_umeng_crash).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = 1 / 0;
            }
        });

        findViewById(R.id.btn_ForegroundService).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startService(new Intent(AssistMainActivity.this, ForegroundService.class));
            }
        });

        findViewById(R.id.btn_AutoHideNotificationService).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startService(new Intent(AssistMainActivity.this, AutoHideNotificationService.class));
            }
        });




        findViewById(R.id.btn_KeepDoubleStartService).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startDoubleService();
            }

        });



    }



    private boolean isDoubleService=false;
    private KeepDoubleStartService.DownloadBinder mDownloadBinder;
    //被保护 KeepDoubleStartService 服务 重新连接要做的事情
    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mDownloadBinder = (KeepDoubleStartService.DownloadBinder) service;
            mDownloadBinder.setOnTimeChangeListener(new KeepDoubleStartService.OnTimeChangeListener() {
                @Override
                public void showTime(final String time) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.e("mServiceConnection:",time+"");
                        }
                    });
                }
            });
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }
    };

    private void startDoubleService() {
        isDoubleService=true;
        //先startService, 之后bindService
        Intent intent = new Intent(this, KeepDoubleStartService.class);
        startService(intent);
        bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
        //双守护线程，优先级不一样
        startAllServices();
    }

    private void startAllServices() {
        startService(new Intent(this, GuardService.class));
        startService(new Intent(this, OtherGuardService.class));
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isDoubleService){
            unbindService(mServiceConnection);
        }
    }

    public static class Test {
        private static Test instance;
        public Context mContext;

        public static Test getInstance(Context context) {
            instance = new Test(context);

            return instance;
        }

        private Test(Context context) {
            mContext = context;
        }
    }
}
