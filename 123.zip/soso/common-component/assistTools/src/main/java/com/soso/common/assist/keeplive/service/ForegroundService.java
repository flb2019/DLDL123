package com.soso.common.assist.keeplive.service;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

/**
 * Created by Zc on 2019/2/22.
 * 已经完成了Service的优先级提升。不过在通知栏会出现“XXX”正在运行。的字样，取消他也很简单。
 * 再开启一个Service用来和当前的通知栏上XXX共用，然后关闭当前的Service，可以通知栏“XXX”正在运行消失。关闭这个Service不会影响ForegroundService的优先级以及存活状态。

 作者：張文靖同學
 链接：https://www.jianshu.com/p/7bd16771c81e
 来源：简书
 简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。
 *
 */

public class ForegroundService extends Service {

    /**
     * 前台进程的NotificationId  不可为0
     */
    private final static int SERVICE_ID = 1001;
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(SERVICE_ID, new Notification());
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}
