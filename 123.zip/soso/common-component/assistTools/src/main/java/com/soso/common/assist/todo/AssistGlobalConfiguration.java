package com.soso.common.assist.todo;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

import com.soso.common.assist.BuildConfig;
import com.soso.sosolib.art.base.delegate.AppLifecycles;
import com.soso.sosolib.art.di.module.GlobalConfigModule;
import com.soso.sosolib.art.integration.ConfigModule;
import com.soso.sosolib.art.integration.cache.Cache;
import com.soso.sosolib.art.tools.AppComponentUtils;
import com.squareup.leakcanary.LeakCanary;
import com.squareup.leakcanary.RefWatcher;
import com.umeng.analytics.MobclickAgent;
import com.umeng.commonsdk.UMConfigure;

import java.util.List;

/**
 * Created by sumerlin on 2019/3/3 2019/3/3.
 * Describe:
 */
public class AssistGlobalConfiguration implements ConfigModule {

    public static final long sessionInterval =  30 * 60 * 1000;
    @Override
    public void applyOptions(Context context, GlobalConfigModule.Builder builder) {

    }

    @Override
    public void injectAppLifecycle(Context context, List<AppLifecycles> lifecycles) {
        lifecycles.add(new AppLifecycles() {
            @Override
            public void attachBaseContext(@NonNull Context base) {

            }

            @Override
            public void onCreate(@NonNull Application application) {
                // LeakCanary内存泄露检查
                if (LeakCanary.isInAnalyzerProcess(application)) {
                    // This process is dedicated to LeakCanary for heap analysis.
                    // You should not init your app in this process.
                    //在注册之前先判断LeakCanary是否已经运行在手机上，比如你同时有多个APP集成了LeakCanary，其他app已经运行了LeakCanary则不需要重新install
                } else {
                    Cache<String, Object> extras = AppComponentUtils.getAppComponent().extras();
                    extras.put(RefWatcher.class.getName(), BuildConfig.DEBUG_FLAG ? LeakCanary.install(application) : RefWatcher.DISABLED);
                }
                //友盟统计
                /**
                 * 初始化common库
                 * 参数1:上下文，必须的参数，不能为空
                 * 参数2:友盟 app key，非必须参数，如果Manifest文件中已配置app key，该参数可以传空，则使用Manifest中配置的app key，否则该参数必须传入
                 * 参数3:友盟 channel，非必须参数，如果Manifest文件中已配置channel，该参数可以传空，则使用Manifest中配置的channel，否则该参数必须传入，channel命名请详见channel渠道命名规范
                 * 参数4:设备类型，必须参数，传参数为UMConfigure.DEVICE_TYPE_PHONE则表示手机；传参数为UMConfigure.DEVICE_TYPE_BOX则表示盒子；默认为手机
                 * 参数5:Push推送业务的secret，需要集成Push功能时必须传入Push的secret，否则传空
                 */
                //如果AndroidManifest.xml清单配置中没有设置appkey和channel，则可以在这里设置
                //        UMConfigure.init(this, "58edcfeb310c93091c000be2", "Umeng", UMConfigure.DEVICE_TYPE_PHONE, "1fe6a20054bcef865eeb0991ee84525b");
                // 打开统计SDK调试模式
                UMConfigure.setLogEnabled(true);
                UMConfigure.init(application, UMConfigure.DEVICE_TYPE_PHONE,"");
                // interval: 单位是毫秒，默认Session间隔时间是30秒
                //当应用在后台运行超过30秒（默认）再回到前台，将被认为是两次独立的Session(启动)，例如：用户回到home，或进入其他程序，经过一段时间后再返回之前的应用。即被认为是两个独立的Session。
                MobclickAgent.setSessionContinueMillis(sessionInterval);
                // isEnable: false-关闭错误统计功能；true-打开错误统计功能（默认打开）,//调用上传服务器 MobclickAgent.reportError(mContext, "Parameter Error");
                //SDK通过Thread.UncaughtExceptionHandler 捕获程序崩溃日志，并在程序下次启动时发送到服务器。
                MobclickAgent.setCatchUncaughtExceptions(true);
                // 选用AUTO页面采集模式:
                //【AUTO 自动模式】， 不需要在 Activity 中设置onResume/onPause埋点。非Activity页面，如Fragment、CustomView及用户自定义的页面场景，通过onPageStart/onPageEnd接口对非Activity页面埋点
                //【MANUAL手动模式】，需要在 Activity 中设置onResume/onPause埋点。非Activity页面，如Fragment、CustomView及用户自定义的页面场景，通过onPageStart/onPageEnd接口对非Activity页面埋点
                MobclickAgent.setPageCollectionMode(MobclickAgent.PageMode.MANUAL);

            }

            @Override
            public void onTerminate(@NonNull Application application) {

            }
        });

    }

    @Override
    public void injectActivityLifecycle(Context context, List<Application.ActivityLifecycleCallbacks> lifecycles) {
        lifecycles.add(new Application.ActivityLifecycleCallbacks() {
            @Override
            public void onActivityCreated(Activity activity, Bundle bundle) {

            }

            @Override
            public void onActivityStarted(Activity activity) {

            }

            @Override
            public void onActivityResumed(Activity activity) {
                MobclickAgent.onResume(activity);

            }

            @Override
            public void onActivityPaused(Activity activity) {
                MobclickAgent.onPause(activity);

            }

            @Override
            public void onActivityStopped(Activity activity) {

            }

            @Override
            public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {

            }

            @Override
            public void onActivityDestroyed(Activity activity) {
                //退出时分析监控
                RefWatcher refWatcher = (RefWatcher) (AppComponentUtils.getAppComponent()).extras().get(RefWatcher.class.getName());
                refWatcher.watch(activity);
            }
        });

    }

    @Override
    public void injectFragmentLifecycle(Context context, List<FragmentManager.FragmentLifecycleCallbacks> lifecycles) {


        lifecycles.add(new FragmentManager.FragmentLifecycleCallbacks() {
            @Override
            public void onFragmentDestroyed(FragmentManager fm, Fragment f) {
                super.onFragmentDestroyed(fm, f);
                //退出时分析监控
                RefWatcher refWatcher = (RefWatcher) (AppComponentUtils.getAppComponent()).extras().get(RefWatcher.class.getName());
                refWatcher.watch(f);
            }
        });

    }
}
