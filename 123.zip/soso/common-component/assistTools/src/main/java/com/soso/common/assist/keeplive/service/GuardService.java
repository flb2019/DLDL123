package com.soso.common.assist.keeplive.service;

import android.app.Notification;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import com.soso.common.assist.IKeepAliveConnection;
import com.soso.common.assist.keeplive.ServiceAliveUtils;


/**
 * 双进程守护Service, 辅助进程。
 * 原理：启动时检查KeepDoubleStartService 是否存活连接。 没有就启动拉起。 如果本Service 断链 ， 就启动第二进程Service来守护KeepDoubleStartService
 * 流程：bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
 * onCreate ——》onBind ——》ServiceConnection.onServiceConnected
 * onUnbind ——》onDestroy
 *
 */
public class GuardService extends Service {
    private final static String TAG = GuardService.class.getSimpleName();
    //用来监听启动其他服务的状态
    private ServiceConnection mServiceConnection = new ServiceConnection() {
        /**
         * 与服务连接时，系统会回调onServiceConnected
         * @param componentName
         * @param iBinder
         */
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            Log.e(TAG, "GuardService建立链接");
            boolean isServiceRunning = ServiceAliveUtils.isServiceAlice("KeepDoubleStartService");
            if (!isServiceRunning) {
                Intent i = new Intent(GuardService.this, KeepDoubleStartService.class);
                startService(i);
                Log.e(TAG, "KeepDoubleStartService kill");
            }else {
                Log.e(TAG, "KeepDoubleStartService存活");
            }
        }


        /**
         * 客户端调用unbindService()解绑服务。注意，此时不会回调onServiceDisconnected()，这个方法只会在服务crash或killed才会被回调。
         * @param componentName
         */
        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            // 断开链接
            startService(new Intent(GuardService.this, OtherGuardService.class));
            // 重新绑定
            bindService(new Intent(GuardService.this, OtherGuardService.class), mServiceConnection, Context.BIND_IMPORTANT);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1111, new Notification());
        // 绑定建立链接
        bindService(new Intent(this, OtherGuardService.class), mServiceConnection, Context.BIND_IMPORTANT);
        Log.e(TAG, "onStartCommand");
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
//        return (IBinder) GuardService.this;
        return new IKeepAliveConnection.Stub() {
        };
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }
}
