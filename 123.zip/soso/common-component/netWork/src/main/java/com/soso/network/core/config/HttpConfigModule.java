package com.soso.network.core.config;

import android.text.TextUtils;

import com.soso.network.core.listen.NetworkInterceptorHandler;

import java.util.List;

import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;

/**
 * Created by sumerlin on 2019/2/26 2019/2/26.
 * Describe:
 */
public class HttpConfigModule {
    private HttpUrl httpUrl;
    private BaseUrl baseUrl;
    private CookieJar cookie;
    private HttpConfig.RetrofitConfiguration retrofitConfiguration;
    private HttpConfig.OkHttpConfiguration okHttpConfiguration;
    private HttpConfig.RxCacheConfiguration rxCacheConfiguration;
    private Interceptor headersInterceptor;
    private Interceptor tokenNetWorkInterceptor;
    private List<Interceptor> interceptors;
    private NetworkInterceptorHandler networkInterceptorHandler;


    public HttpConfigModule(Builder buidler) {
        this.retrofitConfiguration = buidler.retrofitConfiguration;
        this.okHttpConfiguration = buidler.okHttpConfiguration;
        this.rxCacheConfiguration = buidler.rxCacheConfiguration;
        this.headersInterceptor = buidler.headersInterceptor;
        this.tokenNetWorkInterceptor = buidler.tokenNetWorkInterceptor;
        this.interceptors = buidler.interceptors;
        this.networkInterceptorHandler = buidler.networkInterceptorHandler;
        this.httpUrl = buidler.httpUrl;
        this.baseUrl = buidler.baseUrl;
        this.cookie = buidler.cookie;
    }

    public static Builder builder() {
        return new Builder();
    }


    public HttpUrl getHttpUrl() {
        return httpUrl;
    }

    public BaseUrl getBaseUrl() {
        return baseUrl;
    }

    public CookieJar getCookie() {
        return cookie;
    }

    public NetworkInterceptorHandler getNetworkInterceptorHandler() {
        return networkInterceptorHandler;
    }

    public HttpConfig.RetrofitConfiguration getRetrofitConfiguration() {
        return retrofitConfiguration;
    }

    public HttpConfig.OkHttpConfiguration getOkHttpConfiguration() {
        return okHttpConfiguration;
    }

    public HttpConfig.RxCacheConfiguration getRxCacheConfiguration() {
        return rxCacheConfiguration;
    }

    public List<Interceptor> getInterceptors() {
        return interceptors;
    }

    public Interceptor getHeadersWorkInterceptor() {
        return this.headersInterceptor;
    }

    public Interceptor getTokenNetWorkInterceptor() {
        return this.tokenNetWorkInterceptor;
    }



    public static class Builder {
        private HttpUrl httpUrl;
        private BaseUrl baseUrl;
        private CookieJar cookie;
        private HttpConfig.RetrofitConfiguration retrofitConfiguration;
        private HttpConfig.OkHttpConfiguration okHttpConfiguration;
        private HttpConfig.RxCacheConfiguration rxCacheConfiguration;
        private List<Interceptor> interceptors;
        private Interceptor headersInterceptor;
        private Interceptor tokenNetWorkInterceptor;
        private NetworkInterceptorHandler networkInterceptorHandler;
        public HttpConfigModule build() {
            return new HttpConfigModule(this);
        }

        public Builder setRetrofitConfiguration(HttpConfig.RetrofitConfiguration retrofitConfiguration) {
            this.retrofitConfiguration = retrofitConfiguration;
            return this;

        }

        public Builder setOkHttpConfiguration(HttpConfig.OkHttpConfiguration okHttpConfiguration) {
            this.okHttpConfiguration = okHttpConfiguration;
            return this;
        }

        public Builder setRxCacheConfiguration(HttpConfig.RxCacheConfiguration rxCacheConfiguration) {
            this.rxCacheConfiguration = rxCacheConfiguration;
            return this;
        }

        public Builder setInterceptors(List<Interceptor> interceptors) {
            this.interceptors = interceptors;
            return this;
        }

        public Builder setNetworkInterceptorHandler(NetworkInterceptorHandler networkInterceptorHandler) {
            this.networkInterceptorHandler = networkInterceptorHandler;
            return this;
        }

        public Builder setHttpUrl(String httpUrl) {
            if (TextUtils.isEmpty(httpUrl)) {
                throw new IllegalArgumentException("httpUrl can not be empty!");
            }
            this.httpUrl = HttpUrl.parse(httpUrl);
            return this;
        }

        public Builder setBaseUrl(BaseUrl baseUrl) {
            this.baseUrl = baseUrl;
            return this;
        }

        public Builder setCookie(CookieJar cookie) {
            this.cookie = cookie;
            return this;
        }

        public Builder setHeadersInterceptor(Interceptor headersInterceptor) {
            this.headersInterceptor = headersInterceptor;
            return this;
        }

        public Builder setTokenNetWorkInterceptor(Interceptor tokenNetWorkInterceptor) {
            this.tokenNetWorkInterceptor = tokenNetWorkInterceptor;
            return this;
        }
    }


}
