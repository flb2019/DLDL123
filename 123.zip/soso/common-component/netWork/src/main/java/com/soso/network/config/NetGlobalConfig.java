package com.soso.network.config;

/**
 * Created by sumerlin on 2019/2/17 2019/2/17.
 * Describe:
 */
public class NetGlobalConfig {
}
