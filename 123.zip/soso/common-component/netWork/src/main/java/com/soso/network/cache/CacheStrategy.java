package com.soso.network.cache;

/**
 * Created by sumerlin on 2019/4/14 2019/4/14.
 * Describe:
 */
public class CacheStrategy {
    public String key;
    public int time;
    public XCCacheManager.Strategy mStrategy;

    public String getKey() {
        return key;
    }

    public CacheStrategy setKey(String key) {
        this.key = key;
        return this;
    }

    public int getTime() {
        return time;
    }

    public CacheStrategy setTime(int time) {
        this.time = time;
        return this;
    }

    public XCCacheManager.Strategy getStrategy() {
        return mStrategy;
    }

    public CacheStrategy setStrategy(XCCacheManager.Strategy strategy) {
        mStrategy = strategy;
        return this;
    }
}
