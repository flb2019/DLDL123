package com.soso.network.exception;

/**
 * Created by sumerlin on 2019/1/17 2019/1/17.
 * Describe:
 */
public class ApiRequestException extends Exception{
    private int errorCode;
    private String errorMsg;

    public ApiRequestException(int errorCode, String errorMsg) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
}
