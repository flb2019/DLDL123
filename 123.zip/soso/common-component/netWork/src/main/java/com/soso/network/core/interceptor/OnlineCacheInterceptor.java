package com.soso.network.core.interceptor;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by sumerlin on 2019/4/13 2019/4/13.
 * Describe:  在有网络的情况下，先去读缓存，设置的缓存时间到了，在去网络获取
 */
public class OnlineCacheInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
//        String cacheStrategyModel = request.header("CacheStrategyModel");
//        CacheControl cacheControl = CacheStrategyModel.toCacheControl(cacheStrategyModel);
        Response response = chain.proceed(request);
        int onlineCacheTime = 120;//在线的时候的缓存过期时间，如果想要不缓存，直接时间设置为0
        Response.Builder builder = response.newBuilder();
        builder.removeHeader("Cache-Control");
        return builder
                .header("Cache-Control", "public, max-age=" + 30)
                .removeHeader("Pragma")
                .build();

//        if(NetworkUtils.isConnected()){
//            //如果有网络，缓存90s
//            Log.e("zhanghe","print");
//            Response response = chain.proceed(request);
//            int maxTime = 90;
//            return response.newBuilder()
//                    .removeHeader("Pragma")
//                    .header("Cache-Control", "public, max-age=" + 50000)
//                    .build();
//        }
//        //如果没有网络，不做处理，直接返回
//        return chain.proceed(request);

//        Response originResponse = chain.proceed(request);
//        //设置响应的缓存时间为60秒，即设置Cache-Control头，并移除pragma消息头，因为pragma也是控制缓存的一个消息头属性
//        originResponse = originResponse.newBuilder()
//                .removeHeader("pragma")
//                .header("Cache-Control", "max-age=600")
//                .build();
//
//        return originResponse;

    }
}
