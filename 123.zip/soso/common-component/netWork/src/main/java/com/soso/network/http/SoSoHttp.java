//package com.soso.network.http;
//
//import android.app.Application;
//import android.content.Context;
//
//import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
//import com.soso.network.cookie.CookieManger;
//import com.soso.network.http.cache.CacheMode;
//import com.soso.network.http.model.HttpHeaders;
//import com.soso.network.http.tools.Utils;
//
//import org.apache.http.params.HttpParams;
//
//import java.io.File;
//import java.net.Proxy;
//import java.util.concurrent.Executor;
//import java.util.concurrent.TimeUnit;
//
//import io.reactivex.annotations.NonNull;
//import io.reactivex.disposables.Disposable;
//import io.reactivex.functions.Consumer;
//import io.rx_cache2.internal.RxCache;
//import okhttp3.Cache;
//import okhttp3.ConnectionPool;
//import okhttp3.Interceptor;
//import okhttp3.OkHttpClient;
//import retrofit2.CallAdapter;
//import retrofit2.Converter;
//import retrofit2.Retrofit;
//
///**
// * Created by sumerlin on 2019/4/12 2019/4/12.
// * Describe:
// */
//public class SoSoHttp {
//
//    private static Application sContext;
//    public static final int DEFAULT_MILLISECONDS = 60000;             //默认的超时时间
//    private static final int DEFAULT_RETRY_COUNT = 3;                 //默认重试次数
//    private static final int DEFAULT_RETRY_INCREASEDELAY = 0;         //默认重试叠加时间
//    private static final int DEFAULT_RETRY_DELAY = 500;               //默认重试延时
//    public static final int DEFAULT_CACHE_NEVER_EXPIRE = -1;          //缓存过期时间，默认永久缓存
//    private Cache mCache = null;                                      //Okhttp缓存对象
//    private CacheMode mCacheMode = CacheMode.NO_CACHE;                //缓存类型
//    private long mCacheTime = -1;                                     //缓存时间
//    private File mCacheDirectory;                                     //缓存目录
//    private long mCacheMaxSize;                                       //缓存大小
//    private String mBaseUrl;                                          //全局BaseUrl
//    private int mRetryCount = DEFAULT_RETRY_COUNT;                    //重试次数默认3次
//    private int mRetryDelay = DEFAULT_RETRY_DELAY;                    //延迟xxms重试
//    private int mRetryIncreaseDelay = DEFAULT_RETRY_INCREASEDELAY;    //叠加延迟
//    private HttpHeaders mCommonHeaders;                               //全局公共请求头
//    private HttpParams mCommonParams;                                 //全局公共请求参数
//    private OkHttpClient.Builder okHttpClientBuilder;                 //okhttp请求的客户端
//    private Retrofit.Builder retrofitBuilder;                         //Retrofit请求Builder
//    private RxCache.Builder rxCacheBuilder;                           //RxCache请求的Builder
//    private CookieManger cookieJar;                                   //Cookie管理
//    private volatile static SoSoHttp singleton = null;
//
//
//    private SoSoHttp() {
//        okHttpClientBuilder = new OkHttpClient.Builder();
////        okHttpClientBuilder.hostnameVerifier(new DefaultHostnameVerifier());
//        okHttpClientBuilder.connectTimeout(DEFAULT_MILLISECONDS, TimeUnit.MILLISECONDS);
//        okHttpClientBuilder.readTimeout(DEFAULT_MILLISECONDS, TimeUnit.MILLISECONDS);
//        okHttpClientBuilder.writeTimeout(DEFAULT_MILLISECONDS, TimeUnit.MILLISECONDS);
//        retrofitBuilder = new Retrofit.Builder();
//        retrofitBuilder.addCallAdapterFactory(RxJava2CallAdapterFactory.create());//增加RxJava2CallAdapterFactory
////        rxCacheBuilder = new RxCache.Builder().init(sContext)
////                .diskConverter(new SerializableDiskConverter());      //目前只支持Serializable和Gson缓存其它可以自己扩展
//    }
//
//    public static SoSoHttp getInstance() {
//        testInitialize();
//        if (singleton == null) {
//            synchronized (SoSoHttp.class) {
//                if (singleton == null) {
//                    singleton = new SoSoHttp();
//                }
//            }
//        }
//        return singleton;
//    }
//
//
//
//    private static void testInitialize() {
//        if (sContext == null)
//            throw new ExceptionInInitializerError("请先在全局Application中调用 SoSoHttp.init() 初始化！");
//    }
//
//
//    /**
//     * 获取全局上下文
//     */
//    public static Context getContext() {
//        testInitialize();
//        return sContext;
//    }
//
//    /**
//     * 全局读取超时时间
//     */
//    public SoSoHttp setReadTimeOut(long readTimeOut) {
//        okHttpClientBuilder.readTimeout(readTimeOut, TimeUnit.MILLISECONDS);
//        return this;
//    }
//
//    /**
//     * 全局写入超时时间
//     */
//    public SoSoHttp setWriteTimeOut(long writeTimeout) {
//        okHttpClientBuilder.writeTimeout(writeTimeout, TimeUnit.MILLISECONDS);
//        return this;
//    }
//
//    /**
//     * 全局连接超时时间
//     */
//    public SoSoHttp setConnectTimeout(long connectTimeout) {
//        okHttpClientBuilder.connectTimeout(connectTimeout, TimeUnit.MILLISECONDS);
//        return this;
//    }
//
//    /**
//     * 超时重试次数
//     */
//    public SoSoHttp setRetryCount(int retryCount) {
//        if (retryCount < 0) throw new IllegalArgumentException("retryCount must > 0");
//        mRetryCount = retryCount;
//        return this;
//    }
//
//    /**
//     * 超时重试次数
//     */
//    public static int getRetryCount() {
//        return getInstance().mRetryCount;
//    }
//
//    /**
//     * 超时重试延迟时间
//     */
//    public SoSoHttp setRetryDelay(int retryDelay) {
//        if (retryDelay < 0) throw new IllegalArgumentException("retryDelay must > 0");
//        mRetryDelay = retryDelay;
//        return this;
//    }
//
//    /**
//     * 超时重试延迟时间
//     */
//    public static int getRetryDelay() {
//        return getInstance().mRetryDelay;
//    }
//
//    /**
//     * 超时重试延迟叠加时间
//     */
//    public SoSoHttp setRetryIncreaseDelay(int retryIncreaseDelay) {
//        if (retryIncreaseDelay < 0)
//            throw new IllegalArgumentException("retryIncreaseDelay must > 0");
//        mRetryIncreaseDelay = retryIncreaseDelay;
//        return this;
//    }
//
//    /**
//     * 超时重试延迟叠加时间
//     */
//    public static int getRetryIncreaseDelay() {
//        return getInstance().mRetryIncreaseDelay;
//    }
//
//    /**
//     * 全局的缓存模式
//     */
//    public SoSoHttp setCacheMode(CacheMode cacheMode) {
//        mCacheMode = cacheMode;
//        return this;
//    }
//
//    /**
//     * 获取全局的缓存模式
//     */
//    public static CacheMode getCacheMode() {
//        return getInstance().mCacheMode;
//    }
//
//    /**
//     * 全局的缓存过期时间
//     */
//    public SoSoHttp setCacheTime(long cacheTime) {
//        if (cacheTime <= -1) cacheTime = DEFAULT_CACHE_NEVER_EXPIRE;
//        mCacheTime = cacheTime;
//        return this;
//    }
//
//    /**
//     * 获取全局的缓存过期时间
//     */
//    public static long getCacheTime() {
//        return getInstance().mCacheTime;
//    }
//
//    /**
//     * 全局的缓存大小,默认50M
//     */
//    public SoSoHttp setCacheMaxSize(long maxSize) {
//        mCacheMaxSize = maxSize;
//        return this;
//    }
//
//    /**
//     * 获取全局的缓存大小
//     */
//    public static long getCacheMaxSize() {
//        return getInstance().mCacheMaxSize;
//    }
//
//
//    /**
//     * 全局设置缓存的版本，默认为1，缓存的版本号
//     */
//    public SoSoHttp setCacheVersion(int cacheersion) {
//        if (cacheersion < 0)
//            throw new IllegalArgumentException("cacheersion must > 0");
//        rxCacheBuilder.appVersion(cacheersion);
//        return this;
//    }
//
//    /**
//     * 全局设置缓存的路径，默认是应用包下面的缓存
//     */
//    public SoSoHttp setCacheDirectory(File directory) {
//        mCacheDirectory = Utils.checkNotNull(directory, "directory == null");
//        rxCacheBuilder.diskDir(directory);
//        return this;
//    }
//
//    /**
//     * 获取缓存的路劲
//     */
//    public static File getCacheDirectory() {
//        return getInstance().mCacheDirectory;
//    }
//
//    /**
//     * 全局设置缓存的转换器
//     */
//    public SoSoHttp setCacheDiskConverter(IDiskConverter converter) {
//        rxCacheBuilder.diskConverter(Utils.checkNotNull(converter, "converter == null"));
//        return this;
//    }
//
//    /**
//     * 全局设置OkHttp的缓存,默认是3天
//     */
//    public SoSoHttp setHttpCache(Cache cache) {
//        this.mCache = cache;
//        return this;
//    }
//
//    /**
//     * 获取OkHttp的缓存<br>
//     */
//    public static Cache getHttpCache() {
//        return getInstance().mCache;
//    }
//
//    /**
//     * 添加全局公共请求参数
//     */
//    public SoSoHttp addCommonParams(HttpParams commonParams) {
//        if (mCommonParams == null) mCommonParams = new HttpParams();
//        mCommonParams.put(commonParams);
//        return this;
//    }
//
//    /**
//     * 获取全局公共请求参数
//     */
//    public HttpParams getCommonParams() {
//        return mCommonParams;
//    }
//
//    /**
//     * 获取全局公共请求头
//     */
//    public HttpHeaders getCommonHeaders() {
//        return mCommonHeaders;
//    }
//
//    /**
//     * 添加全局公共请求参数
//     */
//    public SoSoHttp addCommonHeaders(HttpHeaders commonHeaders) {
//        if (mCommonHeaders == null) mCommonHeaders = new HttpHeaders();
//        mCommonHeaders.put(commonHeaders);
//        return this;
//    }
//
//    /**
//     * 添加全局拦截器
//     */
//    public SoSoHttp addInterceptor(Interceptor interceptor) {
//        okHttpClientBuilder.addInterceptor(Utils.checkNotNull(interceptor, "interceptor == null"));
//        return this;
//    }
//
//    /**
//     * 添加全局网络拦截器
//     */
//    public SoSoHttp addNetworkInterceptor(Interceptor interceptor) {
//        okHttpClientBuilder.addNetworkInterceptor(Utils.checkNotNull(interceptor, "interceptor == null"));
//        return this;
//    }
//
//    /**
//     * 全局设置代理
//     */
//    public SoSoHttp setOkproxy(Proxy proxy) {
//        okHttpClientBuilder.proxy(Utils.checkNotNull(proxy, "proxy == null"));
//        return this;
//    }
//
//    /**
//     * 全局设置请求的连接池
//     */
//    public SoSoHttp setOkconnectionPool(ConnectionPool connectionPool) {
//        okHttpClientBuilder.connectionPool(Utils.checkNotNull(connectionPool, "connectionPool == null"));
//        return this;
//    }
//
//    /**
//     * 全局为Retrofit设置自定义的OkHttpClient
//     */
//    public SoSoHttp setOkclient(OkHttpClient client) {
//        retrofitBuilder.client(Utils.checkNotNull(client, "client == null"));
//        return this;
//    }
//
//    /**
//     * 全局设置Converter.Factory,默认GsonConverterFactory.create()
//     */
//    public SoSoHttp addConverterFactory(Converter.Factory factory) {
//        retrofitBuilder.addConverterFactory(Utils.checkNotNull(factory, "factory == null"));
//        return this;
//    }
//
//    /**
//     * 全局设置CallAdapter.Factory,默认RxJavaCallAdapterFactory.create()
//     */
//    public SoSoHttp addCallAdapterFactory(CallAdapter.Factory factory) {
//        retrofitBuilder.addCallAdapterFactory(Utils.checkNotNull(factory, "factory == null"));
//        return this;
//    }
//
//    /**
//     * 全局设置Retrofit callbackExecutor
//     */
//    public SoSoHttp setCallbackExecutor(Executor executor) {
//        retrofitBuilder.callbackExecutor(Utils.checkNotNull(executor, "executor == null"));
//        return this;
//    }
//
//    /**
//     * 全局设置Retrofit对象Factory
//     */
//    public SoSoHttp setCallFactory(okhttp3.Call.Factory factory) {
//        retrofitBuilder.callFactory(Utils.checkNotNull(factory, "factory == null"));
//        return this;
//    }
//
//    /**
//     * 全局设置baseurl
//     */
//    public SoSoHttp setBaseUrl(String baseUrl) {
//        mBaseUrl = Utils.checkNotNull(baseUrl, "baseUrl == null");
//        return this;
//    }
//
//    /**
//     * 获取全局baseurl
//     */
//    public static String getBaseUrl() {
//        return getInstance().mBaseUrl;
//    }
//
//    /**
//     * get请求
//     */
//    public static GetRequest get(String url) {
//        return new GetRequest(url);
//    }
//
//    /**
//     * post请求
//     */
//    public static PostRequest post(String url) {
//        return new PostRequest(url);
//    }
//
//
////    /**
////     * delete请求
////     */
////    public static DeleteRequest delete(String url) {
////
////        return new DeleteRequest(url);
////    }
////
////    /**
////     * 自定义请求
////     */
////    public static CustomRequest custom() {
////        return new CustomRequest();
////    }
////
////    public static DownloadRequest downLoad(String url) {
////        return new DownloadRequest(url);
////    }
////
////    public static PutRequest put(String url) {
////        return new PutRequest(url);
////    }
//
//    /**
//     * 取消订阅
//     */
//    public static void cancelSubscription(Disposable disposable) {
//        if (disposable != null && !disposable.isDisposed()) {
//            disposable.dispose();
//        }
//    }
//
//    /**
//     * 清空缓存
//     */
//    public static void clearCache() {
//        getRxCache().clear().compose(RxUtil.<Boolean>io_main())
//                .subscribe(new Consumer<Boolean>() {
//                    @Override
//                    public void accept(@NonNull Boolean aBoolean) throws Exception {
//                        HttpLog.i("clearCache success!!!");
//                    }
//                }, new Consumer<Throwable>() {
//                    @Override
//                    public void accept(@NonNull Throwable throwable) throws Exception {
//                        HttpLog.i("clearCache err!!!");
//                    }
//                });
//    }
//
//    /**
//     * 移除缓存（key）
//     */
//    public static void removeCache(String key) {
//        getRxCache().remove(key).compose(RxUtil.<Boolean>io_main()).subscribe(new Consumer<Boolean>() {
//            @Override
//            public void accept(@NonNull Boolean aBoolean) throws Exception {
//                HttpLog.i("removeCache success!!!");
//            }
//        }, new Consumer<Throwable>() {
//            @Override
//            public void accept(@NonNull Throwable throwable) throws Exception {
//                HttpLog.i("removeCache err!!!");
//            }
//        });
//    }
//
//}
