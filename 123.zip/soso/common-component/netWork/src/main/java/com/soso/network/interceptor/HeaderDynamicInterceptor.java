package com.soso.network.interceptor;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.Map;
import java.util.Set;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by sumerlin on 2019/1/18 2019/1/18.
 * Version 1.0  HeaderDynamicInterceptor  动态拦截器
 * 每次ping 携带请求头 从OkHttp中拦截，Retrofit2只能使用注解方式添加headers
 * Describe:
 */
public class HeaderDynamicInterceptor implements Interceptor {

    private Map<String, String> headers;

    public HeaderDynamicInterceptor(Map<String, String> headers) {
        this.headers = headers;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {

        Response response = null;

        //同步 避免溢出
        synchronized (this) {
            Request.Builder builder = chain.request()
                    .newBuilder();

            if (headers != null && headers.size() > 0) {

                Set<String> keys = headers.keySet();

                for (String headerKey : keys) {

                    builder.addHeader(headerKey, headers.get(headerKey)).build();

                }

                try {

                    response = chain.proceed(builder.build());

                } catch (SocketTimeoutException e) {
                    e.getLocalizedMessage();
                }
            } else {

                response = chain.proceed(builder.build());

            }
        }
//            获取error code 暂时不用
//            Response responseError = chain.proceed(chain.request());
//            responseError.code();
        return response;
    }
}