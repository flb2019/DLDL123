package com.soso.network.core.interceptor;

import com.soso.sosolib.utils.NetworkUtils;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.CacheControl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by sumerlin on 2019/4/13 2019/4/13.
 * Describe:在没有网络的情况下，取读缓存数据
 */
public class OfflineCacheInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request originalRequest = chain.request();
//        String cacheStrategyModel = request.header("CacheStrategyModel");
//        CacheControl cacheControl = CacheStrategyModel.toCacheControl(cacheStrategyModel);

//        CacheControl cacheControl = new CacheControl
//                .Builder().maxStale(30, TimeUnit.SECONDS)
//                .onlyIfCached()
//                .build();
//
//        Request newRequest = originalRequest.newBuilder()
//                .cacheControl(cacheControl
//                )
//                .removeHeader("Cache-Control")
//                .header("Cache-Control", "public, only-if-cached, max-stale=" + 30)
//                .build();

//        return chain.proceed(newRequest);
        if (!NetworkUtils.isConnected()) {
            int offlineCacheTime = 30;//离线的时候的缓存的过期时间
            CacheControl cacheControl = new CacheControl
                    .Builder().maxStale(offlineCacheTime, TimeUnit.SECONDS)
                    .onlyIfCached()
                    .build();
            Request newRequest = originalRequest.newBuilder()
                        .cacheControl(cacheControl
                        )//.build();// 两种方式结果是一样的，写法不同
//                    .header("Cache-Control", "public, only-if-cached, max-stale=" + offlineCacheTime)
                    .removeHeader("Cache-Control")
                    .header("Cache-Control", "public, only-if-cached, max-stale=" + offlineCacheTime)
                    .build();
            return chain.proceed(newRequest);
        }
        return chain.proceed(originalRequest);


//        //如果没有网络，则启用 FORCE_CACHE
//        if (!NetworkUtils.isConnected()) {
//            request = request.newBuilder()
////                    .cacheControl(CacheControl.FORCE_CACHE)
//                    .removeHeader("Pragma")
//                    .header("Cache-Control", "public,max-age=" + 5000)
//                    .build();
//
//            Response response = chain.proceed(request);
//            return response.newBuilder()
//                    .header("Cache-Control", "public, only-if-cached, max-stale=3600")
//                    .removeHeader("Pragma")
//                    .build();
//        }
//        //有网络的时候，这个拦截器不做处理，直接返回
//        return chain.proceed(request);
    }
}
