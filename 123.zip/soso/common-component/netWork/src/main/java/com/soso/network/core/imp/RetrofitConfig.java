//package com.soso.network.core.imp;
//
//import android.content.Context;
//
//import com.soso.network.core.config.HttpConfig;
//
//import me.mvp.demo.app.utils.tool.JsonConverterFactory;
//import me.mvp.frame.di.module.HttpModule;
//import retrofit2.Retrofit;
//
///**
// * 扩展自定义配置 Retrofit 参数
// */
//public class RetrofitConfig implements HttpConfig.RetrofitConfiguration {
//
//    @Override
//    public void configRetrofit(Context context, Retrofit.Builder builder) {
//        builder
//                .addConverterFactory(JsonConverterFactory.create())// 支持 Json
//        ;
//    }
//}