package com.soso.network.core;

import android.text.TextUtils;

import com.google.gson.JsonElement;
import com.soso.network.bean.NetResultData;
import com.soso.network.bean.ResultFieldName;
import com.soso.network.cache.CacheModel;
import com.soso.network.cache.CacheStrategy;
import com.soso.network.cache.XCCacheManager;
import com.soso.network.callback.NetCallback;
import com.soso.network.config.ApiCodeEnum;
import com.soso.network.config.NetEnum;
import com.soso.network.exception.ApiRequestException;
import com.soso.network.exception.ErrorExceptionUtil;
import com.soso.network.exception.ErrorMessage;
import com.soso.network.tools.JsonParserUtil;
import com.soso.sosolib.BaseApplication;
import com.soso.sosolib.utils.JsonUtils;
import com.soso.sosolib.utils.TimeUtils;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Response;

/**
 * Created by sumerlin on 2019/2/28 2019/2/28.
 * Describe:
 */
public class NetWorkHandler<T> {
    private Observable<Response<JsonElement>> mObservable;
    private NetCallback<T> callback;
    private CacheStrategy cacheStrategy;

    public NetWorkHandler(Observable<Response<JsonElement>> observable, NetCallback<T> callback) {
        this.mObservable = observable;
        this.callback = callback;
    }

    public NetWorkHandler(Observable<Response<JsonElement>> observable, NetCallback<T> callback, CacheStrategy cacheStrategy) {
        this.mObservable = observable;
        this.callback = callback;
        this.cacheStrategy = cacheStrategy;
    }


    //执行流程 onStart(只执行一次)- defer - onBefore - http拦截器-  执行请求(成功失败)， 重试 defer - onBefore - http拦截器 -  请求(成功失败)
    public Observable<NetResultData<T>> doExecute() {
        Observable<NetResultData<T>> observable = mObservable
                .doOnSubscribe(new Consumer<Disposable>() {
                    @Override
                    public void accept(@NonNull Disposable disposable) throws Exception {
                        callback.onBefore(disposable);
                    }
                })
                .map(new Function<Response<JsonElement>, NetResultData<T>>() {
                    @Override
                    public NetResultData<T> apply(Response<JsonElement> response) throws Exception {

                        JsonElement body = response.body();
                        int code = response.code();
                        ApiRequestException currentException = null;
                        NetResultData<T> tResultNetData = new NetResultData<>();
                        try {
                            if (code == 200) {
                                String error = JsonParserUtil.getStringResult(body, ResultFieldName.RESULT_ERROR);
                                if (!TextUtils.isEmpty(error)) {
                                    //有错误信息
                                    currentException = new ApiRequestException(ApiCodeEnum.Success.getId(), error);
                                }
                                String dataJson = JsonParserUtil.getStringResult(body, ResultFieldName.RESULT_DATA);
                                if (dataJson != null) {
                                    Type type = callback.getClass().getGenericSuperclass();
                                    if (type instanceof ParameterizedType) {
                                        Type[] types = ((ParameterizedType) type).getActualTypeArguments();
                                        Type ty = types[0];
                                        T data = JsonUtils.fromJson(dataJson, ty);
                                        if (data != null) {
                                            tResultNetData.setData(data);
                                            // TODO: 2019/4/14 保存缓存
                                            try {
                                                CacheModel cacheModel = new CacheModel();
                                                cacheModel
                                                        .setKey(cacheStrategy.getKey())
                                                        .setValue(JsonUtils.formatJson(data))
                                                        .setTime(cacheStrategy.time)
                                                        .setCreateTime(TimeUtils.getNowTimeSecs());

                                                XCCacheManager.getInstance(BaseApplication.getAppContext())
                                                        .writeCache(cacheStrategy.getKey(), JsonUtils.toJson(cacheModel));
                                            } catch (Exception e) {

                                            }

                                        } else {
                                            //data == null, 当做 api 异常处理
                                            currentException = new ApiRequestException(ApiCodeEnum.No_Find_Data.getId(), ApiCodeEnum.No_Find_Data.getName());
                                        }
                                    }

                                } else {
                                    //dataJson == null
                                    currentException = new ApiRequestException(ApiCodeEnum.No_Find_Data.getId(), ApiCodeEnum.No_Find_Data.getName());
                                }

                            } else {
                                //非200请求失败，解析code, 判断是否是token异常
                                if (code == ApiCodeEnum.No_Authorized.getId() || TextUtils.equals(response.message(), "Unauthorized")) {
                                    currentException = new ApiRequestException(ApiCodeEnum.No_Authorized.getId(), ApiCodeEnum.No_Authorized.getName());
                                } else {
                                    currentException = new ApiRequestException(code, ApiCodeEnum.getApiErrorName(code));
                                }

                            }
                        } catch (Exception e) {
                            //运行时 ，异常
                            currentException = new ApiRequestException(ApiCodeEnum.No_Find_Data.getId(), ApiCodeEnum.No_Find_Data.getName());
                        } finally {
                            if (currentException != null) {
                                // TODO: 2019/1/20 判断是否 需要读取缓存
                                ErrorExceptionUtil.throwException(currentException);
                            }
                            return tResultNetData;

                        }
                    }
                })
                .subscribeOn(Schedulers.io());//指定上面没有指定所在线程的Observable在IO线程执行;

        Observer<NetResultData<T>> requestObserver = new Observer<NetResultData<T>>() {

            @Override
            public void onSubscribe(Disposable d) {
                callback.onStart(d);
            }

            @Override
            public void onNext(NetResultData<T> tNetResultData) {
                callback.onSuccess(tNetResultData);
            }

            @Override
            public void onError(Throwable e) {
                ApiRequestException error = ErrorExceptionUtil.parserException(e);
                // TODO: 2019/4/14 读取缓存
                if (error.getErrorCode() == NetEnum.TimeOutException.getId()) {
                    Observable.just(cacheStrategy)
                            .map(new Function<CacheStrategy, NetResultData<T>>() {
                                @Override
                                public NetResultData<T> apply(CacheStrategy cacheStrategy) throws Exception {
                                    NetResultData<T> tResultNetData = new NetResultData<>();
                                    try {
                                        //没有网络 链接超时
                                        // TODO: 2019/4/14 读取缓存
                                        String cacheJson = XCCacheManager
                                                .getInstance(BaseApplication.getAppContext())
                                                .readCache(cacheStrategy.getKey());
                                        CacheModel cacheModel = JsonUtils.fromJson(cacheJson, CacheModel.class);
                                        //判断是否过期
                                        if (cacheModel != null && TextUtils.equals(cacheModel.getKey(), cacheStrategy.getKey())) {
                                            int time = cacheModel.getTime();
                                            long createTime = cacheModel.getCreateTime();
                                            long nowTimeSecs = TimeUtils.getNowTimeSecs();
                                            boolean isEx = nowTimeSecs - (createTime + time) < 0;
                                            if (!isEx) {
                                                Type type = callback.getClass().getGenericSuperclass();
                                                Type[] types = ((ParameterizedType) type).getActualTypeArguments();
                                                Type ty = types[0];
                                                T data = JsonUtils.fromJson(cacheModel.getValue(), ty);
                                                if (data != null) {
                                                    tResultNetData.setStatusCode(200);
                                                    tResultNetData.setData(data);
                                                } else {
                                                    ErrorExceptionUtil.throwException(error);
                                                }
                                            } else {
                                                ErrorExceptionUtil.throwException(error);
                                            }
                                        }
                                    } catch (Exception e) {
                                        ErrorExceptionUtil.throwException(error);
                                    }
                                    return tResultNetData;
                                }
                            })
                            .subscribe(new Observer<NetResultData<T>>() {
                                @Override
                                public void onSubscribe(Disposable d) {
                                    callback.onStart(d);
                                }

                                @Override
                                public void onNext(NetResultData<T> tNetResultData) {
                                    callback.onSuccess(tNetResultData);
                                }

                                @Override
                                public void onError(Throwable e) {
                                    callback.onError(new ErrorMessage(error.getErrorCode(), error.getErrorMsg()));
                                }

                                @Override
                                public void onComplete() {
                                    if (callback != null) {
                                        callback.onFinish();
                                    }
                                }
                            });

                }

                callback.onError(new ErrorMessage(error.getErrorCode(), error.getErrorMsg()));
            }

            @Override
            public void onComplete() {
                if (callback != null) {
                    callback.onFinish();
                }
            }
        };

        observable
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(requestObserver);
        return observable;
    }

}
