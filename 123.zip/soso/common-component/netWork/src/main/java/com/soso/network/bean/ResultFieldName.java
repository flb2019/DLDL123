package com.soso.network.bean;

/**
 * Created by sumerlin on 2019/2/20 2019/2/20.
 * Describe:
 */
public class ResultFieldName {
    public final static String RESULT_ERROR = "error";
    public final static String RESULT_DATA = "data";
}
