package com.soso.network.core;

import com.google.gson.JsonElement;
import com.soso.network.ApiFactory;
import com.soso.network.NetRetrofitService;
import com.soso.network.cache.CacheStrategy;
import com.soso.network.cache.XCCacheManager;
import com.soso.network.callback.NetCallback;
import com.soso.network.core.cache.CacheStrategyModel;
import com.soso.sosolib.utils.MD5Util;

import java.util.HashMap;
import java.util.Map;

import io.reactivex.Observable;
import retrofit2.Response;

/**
 * Created by sumerlin on 2019/2/28 2019/2/28.
 * Describe:
 */
public class NetWorkMethods {

    public static volatile NetWorkMethods mInstance;
    private NetRetrofitService mRetrofitService;


    /**
     * 获取单例
     */
    public static NetWorkMethods getInstance() {
//        return ApiMethodsHolder.netModle;
        if (mInstance == null) {
            synchronized (NetWorkMethods.class) {
                if (mInstance == null) {
                    mInstance = new NetWorkMethods();
                }
            }
        }
        return mInstance;
    }


    public NetWorkMethods() {
        mRetrofitService = NetWorkManager.getInstance().getRetrofitService();

    }

    public NetRetrofitService getRetrofitService() {
        return mRetrofitService;
    }

    /************************** get方式 **************************************************************/
    /**
     * @param url      地址
     * @param callback 回调
     */
    public <T> void get(String url, NetCallback<T> callback) {
        get(url, null, callback);
    }


    /**
     * get方式
     *
     * @param url       地址
     * @param paramsMap 数据集合
     * @param callback  回调
     */
    public <T> void get(String url, Map<String, Object> paramsMap, NetCallback<T> callback) {
        Observable<Response<JsonElement>> responseObservable =
                mRetrofitService.getObservable(url, paramsMap != null ? paramsMap : new HashMap<>());
        NetWorkHandler<T> handler = new NetWorkHandler<T>(responseObservable, callback);
        handler.doExecute();
    }


    /**
     * post方式
     *
     * @param url      地址
     * @param callback 回调
     */
    public <T> void postBody(String url, NetCallback<T> callback) {
        postBody(url, new HashMap<>(), callback);
    }

    public <T> void postBody(String url, CacheStrategyModel cacheStrategyModel, NetCallback<T> callback) {
        postBody(url, cacheStrategyModel, new HashMap<>(), callback);
    }

    /**
     * post方式
     *
     * @param url       地址
     * @param paramsMap 数据集合
     * @param callback  回调
     */
    public <T> NetWorkHandler postBody(String url, Map<String, Object> paramsMap, NetCallback<T> callback) {
        Observable<Response<JsonElement>> responseObservable = mRetrofitService.postBodyObservable(url, paramsMap);
        NetWorkHandler<T> handler = new NetWorkHandler<T>(responseObservable, callback);
        handler.doExecute();
        return handler;
    }

    public <T> NetWorkHandler postBody(String url, CacheStrategyModel cacheStrategyModel, Map<String, Object> paramsMap, NetCallback<T> callback) {
        HashMap<String, String> headers = new HashMap<>();
//        headers.put("CacheStrategyModel", cacheStrategyModel.toString());
//        headers.put("CacheStrategyModel", "{cacheTime: 30 }");
        String keyMD5 = null;
        String s = null;
        if (paramsMap != null && !paramsMap.isEmpty()) {
            StringBuilder key = new StringBuilder();
            for (Map.Entry<String, Object> entry : paramsMap.entrySet()) {
                key.append(entry.getKey()).append(entry.getValue());
            }
            s = key.toString();
        }
        keyMD5 = MD5Util.md5Digest(url + s);

        CacheStrategy cacheStrategy = new CacheStrategy();
        cacheStrategy.setKey(keyMD5).setTime(100).setStrategy(XCCacheManager.Strategy.DISK_ONLY);

        Observable<Response<JsonElement>> responseObservable = mRetrofitService.postBodyObservable(url, headers, paramsMap);
        NetWorkHandler<T> handler = new NetWorkHandler<T>(responseObservable, callback, cacheStrategy);
        handler.doExecute();
        return handler;
    }


    /**
     * post方式
     *
     * @param url      地址
     * @param bodyBean
     * @param callback 回调
     * @param <T>
     */
    public <T> void postBody(String url, Object bodyBean, NetCallback<T> callback) {
        Observable<Response<JsonElement>> responseObservable = mRetrofitService
                .postBodyObservable(url, NetWorkTools.toJsonParser(bodyBean));
        NetWorkHandler<T> handler = new NetWorkHandler<T>(responseObservable, callback);
        handler.doExecute();

    }

    /*======20190118,sumer ,builder 方式调用=======================================================================================*/
    public static ApiFactory.CreateBuilder postBody() {
        return new ApiFactory.CreateBuilder();
    }

    public static class Builder {
        private String url;
        private Object paramBean;
        private Map<String, Object> paramsMap;
        private Map<String, Object> headersMap;

        public Builder setUrl(String url) {
            this.url = url;
            return this;
        }

        public Builder setParamBean(Object paramBean) {
            this.paramBean = paramBean;
            return this;
        }

        public <T> void doGetExecute(NetCallback<T> callback) {
            getInstance().get(url, paramsMap, callback);
        }

        public <T> void doPostExecute(NetCallback<T> callback) {
            if (paramBean != null) {
                getInstance().postBody(url, paramBean, callback);
            } else {
                getInstance().postBody(url, paramsMap, callback);
            }

        }

    }

}
