package com.soso.network.core.interceptor;

import com.soso.sosolib.BaseApplication;
import com.soso.sosolib.art.tools.AppComponentUtils;

import java.io.File;

/**
 * Created by sumerlin on 2019/4/13 2019/4/13.
 * Describe:
 */
public class CacheTools {

    private static volatile CacheTools mInstance = null;
    private final File mCacheDir;
    private final int mMaxSize = 1024 * 1024 * 50;

    private CacheTools() {
        File file = AppComponentUtils.getAppComponent().cacheFile();
        File cacheFile = BaseApplication.getInstance().getCacheDir();
        mCacheDir = new File(cacheFile + "/post2");
    }

    public static CacheTools getInstance() {
        if (mInstance == null) {
            synchronized (CacheTools.class) {
                if (mInstance == null) {
                    mInstance = new CacheTools();
                }
            }
        }
        return mInstance;
    }

    public File getCacheDir() {
        return mCacheDir;
    }

    public int getMaxSize() {
        return mMaxSize;
    }
}
