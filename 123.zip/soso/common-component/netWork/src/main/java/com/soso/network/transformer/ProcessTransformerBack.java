//package com.soso.network.transformer;
//
//import android.annotation.TargetApi;
//import android.os.Build;
//import android.support.annotation.RequiresApi;
//import android.text.TextUtils;
//import android.util.ArrayMap;
//
//import com.google.gson.JsonElement;
//import com.soso.network.bean.NetResultData;
//import com.soso.network.bean.ParameterizedTypeImpl;
//import com.soso.network.callback.NetCallback;
//import com.soso.network.config.ApiCodeEnum;
//import com.soso.network.config.NetEnum;
//import com.soso.network.exception.ApiCodeException;
//import com.soso.network.exception.ErrorException;
//import com.soso.network.exception.ErrorExceptionUtil;
//import com.soso.network.exception.ErrorMessage;
//import com.soso.network.tools.JsonParserUtil;
//import com.soso.network.tools.LogUtil;
//import com.soso.network.tools.ParseUtils;
//import com.soso.sosolib.art.tools.AppComponentUtils;
//import com.soso.sosolib.todo.AppInfoModule;
//import com.soso.sosolib.utils.JsonUtils;
//
//import java.lang.reflect.ParameterizedType;
//import java.lang.reflect.Type;
//import java.util.concurrent.Callable;
//
//import io.reactivex.Observable;
//import io.reactivex.ObservableSource;
//import io.reactivex.ObservableTransformer;
//import io.reactivex.Observer;
//import io.reactivex.android.schedulers.AndroidSchedulers;
//import io.reactivex.annotations.NonNull;
//import io.reactivex.disposables.Disposable;
//import io.reactivex.functions.Consumer;
//import io.reactivex.functions.Function;
//import io.reactivex.schedulers.Schedulers;
//import retrofit2.Response;
//
///**
// * Created by sumerlin on 2019/1/13 0:50.
// * Describe: 转换器。 网络请求 RxJava  转换过程抽取类
// */
//public class ProcessTransformerBack<T> {
//    private Observable<Response<JsonElement>> mObservable;
//    private NetCallback<T> callback;
//    private static AppInfoModule appInfoConfig;
//
//    static {
//        appInfoConfig = AppComponentUtils.getAppComponent().getAppInfoModule();
//    }
//
//    public ProcessTransformerBack(Observable<Response<JsonElement>> observable, NetCallback<T> callback) {
//        this.mObservable = observable;
//        this.callback = callback;
//    }
//
//    //执行流程 onStart(只执行一次)- defer - onBefore - http拦截器-  执行请求(成功失败)， 重试 defer - onBefore - http拦截器 -  请求(成功失败)
//    public Observable<NetResultData<T>> doExecute() {
//        //执行流程 onStart(只执行一次)- defer - onBefore - http拦截器-  执行请求(成功失败)， 重试 defer - onBefore - http拦截器 -  请求(成功失败)
//        Observable<NetResultData<T>> observable = Observable
//                .defer(new Callable<ObservableSource<ArrayMap<String, Object>>>() {
//                    @TargetApi(Build.VERSION_CODES.KITKAT)
//                    @Override
//                    public ObservableSource<ArrayMap<String, Object>> call() throws Exception {
//                        LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//                        String name = Thread.currentThread().getName();
//                        long id = Thread.currentThread().getId();
//                        // TODO: 2019/1/12 检查网络
//                        //定义
//                        ArrayMap<String, Object> signMap = new ArrayMap<>();
//                        callback.onBefore(signMap);
//                        return Observable.just(signMap);
//                    }
//                })
//                .flatMap(new Function<ArrayMap<String, Object>, ObservableSource<Response<JsonElement>>>() {
//                    @Override
//                    public ObservableSource<Response<JsonElement>> apply(@NonNull ArrayMap<String, Object> paramsMap) {
//                        //执行网络请求
//                        return mObservable;
//                    }
//                })
//
//                .doOnSubscribe(new Consumer<Disposable>() {
//                    @Override
//                    public void accept(@NonNull Disposable disposable) throws Exception {
//                        callback.onBefore(disposable);
//                    }
//                })
//                .map(new Function<Response<JsonElement>, NetResultData<T>>() {
//                    @Override
//                    public NetResultData<T> apply(Response<JsonElement> response) throws Exception {
//                        LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//                        String name = Thread.currentThread().getName();
//                        long id = Thread.currentThread().getId();
//                        // TODO: 2019/1/12  非手机网络 和 服务器问题的都会走该方法，所以这里是业务上异常的处理，要重试就抛出异常走retryWhen
//                        // TODO: 2019/1/12  手机网络 和 服务器异常问题重试是交给okHttp 的重试机制处理，所以不走retryWhen。
//                        // TODO: 2019/1/12  Response.body() == null 的话认为是链接失败，要求走缓存的话就读缓存
//                        // TODO: 2019/1/14  状态码401 会走这里
//
//                        JsonElement body = response.body();
//                        Exception currentException = null;
//                        NetResultData<T> tResultNetData = new NetResultData<>();
//                        try {
//                            int code = response.code();
//                            if (code == 200) {
//                                //请求成功
//                                if ((body != null)) {
//                                    String error = JsonParserUtil.getStringResult(body, "error");
//                                    if (!TextUtils.isEmpty(error)) {
//                                        //有错误信息
//                                        currentException = new ErrorException(NetEnum.ApiException.getId(), error, NetEnum.ApiException);
//
//                                    }
//                                    String dataJson = JsonParserUtil.getStringResult(body, "data");
////                                String statusCode = JsonParserUtil.getStringResult(body, "statusCode");
//                                    //获取泛型 解析数据
////                                Class<T> tClass = (Class<T>) ((ParameterizedType) tResultNetData.getClass().getGenericSuperclass()).getActualTypeArguments()[0]; // 根据当前类获取泛型的Type
////                                Type ty = new ParameterizedTypeImpl(tResultNetData.getClass(), new Class[]{tClass}); // 传泛型的Type和我们想要的外层类的Type来组装我们想要的类型
//
////                                Type type = getClass().getGenericSuperclass();
////                                Type[] types = ((ParameterizedType)type).getActualTypeArguments();
////                                Type ty = new ParameterizedTypeImpl(NetResultData.class, new Type[]{types[0]});
////                                T data = JsonUtils.fromJson(dataJson, ty);
////                                tResultNetData.setOutsideData(data);
////                                tResultNetData.setStatusCode(Integer.valueOf(statusCode));
////                                tResultNetData.setStatusMgs(statusError);
//
//                                    Type type = callback.getClass().getGenericSuperclass();
//                                    if (type instanceof ParameterizedType) {
//                                        Type[] types = ((ParameterizedType) type).getActualTypeArguments();
////                                    Type ty = new ParameterizedTypeImpl(NetCallback.class, new Type[]{types[0]});
//                                        Type ty = types[0];
//                                        T data = JsonUtils.fromJson(dataJson, ty);
//                                        if (data != null) {
//                                            tResultNetData.setOutsideData(data);
//                                        } else {
//                                            //当做 api 异常处理
//                                            currentException = new ErrorException(NetEnum.ApiException.getId(), NetEnum.ApiException.getMessage(), NetEnum.ApiException);
//                                        }
//                                    }
//                                } else {
//                                    //非200请求失败，解析code
//                                    ApiCodeEnum.getErrorName(code);
//                                    currentException = new ApiCodeException(code, ApiCodeEnum.getErrorName(code), ApiCodeEnum.getApiCodeEnum(code));
//
//                                }
//
//                            } else {
//                                //当做 api 异常处理
//                                currentException = new ErrorException(NetEnum.ApiException.getId(), NetEnum.ApiException.getMessage(), NetEnum.ApiException);
//                            }
//
//                        } catch (Exception e) {
//                            currentException = new ErrorException(NetEnum.ParseException.getId(), NetEnum.ParseException.getMessage(), NetEnum.ParseException);
//
//                        } finally {
//                            if (currentException != null) {
//                                ErrorExceptionUtil.throwException(currentException);
//                            }
//                            return tResultNetData;
//
//                        }
//
//                    }
//                })
//                .retryWhen(new Function<Observable<Throwable>, ObservableSource<?>>() {
//                    //请求异常包括token失效， 重试，统一处理入口
//                    private int mTokenRetryDoing = 0;
//
//                    @Override
//                    public ObservableSource<?> apply(Observable<Throwable> throwableObservable) throws Exception {
//                        return throwableObservable.flatMap(new Function<Throwable, ObservableSource<?>>() {
//                            @Override
//                            public ObservableSource<?> apply(Throwable throwable) throws Exception {
////                                if (throwable instanceof ApiCodeException) {
////                                    ApiCodeException bizException = (ApiCodeException) throwable;
////                                    if (mRetryCount > 0) {
////                                        return Observable.error(new Throwable(ERROR_RETRY));
////                                    } else if (bizException.getErrorCode() == ErrorCode.error_code_session_over_time
////                                            || bizException.getErrorCode() == ErrorCode.error_code_session_unable
////                                            || bizException.getErrorCode() == ErrorCode.error_code_sign_fail) {
////                                        mRetryCount++;
////                                        return SessionLoader.getInstance().getNetSessionLocked();
////                                    } else if (bizException.getErrorCode() == ErrorCode.error_code_session_renew) {
////                                        mRetryCount++;
////                                        return SessionRenewLoader.getInstance().getNetSessionLocked();
////                                    } else if (bizException.getErrorCode() == ErrorCode.error_code_token_need) {
////                                        mRetryCount++;
////                                        return TokenLoader.getInstance().getNetTokenLocked();
////                                    } else if (ErrorCode.isTokenOverTime(bizException.getErrorCode())) {
////                                        ContextModule.getInstance().gotoLogin();
////                                        return Observable.error(throwable);
////                                    } else {
////                                        return Observable.error(throwable);
////                                    }
////
////                                } else {
////                                    return Observable.error(throwable);
////                                }
//                                // TODO: 2019/1/12 定义一个异常引擎， 对异常进行判断 分别处理。 网络异常 包括没有网络 和  服务器链接不上
//
//                                if (throwable instanceof Throwable) {
//                                    if (mTokenRetryDoing > 0) {
//                                        return Observable.error(new Throwable(TOKEN_RETRY_DOING));
//                                    } else {
//                                        //模拟token异常， 重新处理
//                                        mTokenRetryDoing++;
//                                        return appInfoConfig.getTokenChainLoader().getNetTokenLocked();
//                                    }
//                                }
//                                return Observable.error(throwable);
//
//                            }
//                        });
//
//                    }
//                })
//                .subscribeOn(Schedulers.io());//指定上面没有指定所在线程的Observable在IO线程执行;
//
//        Observer<NetResultData<T>> observer1 = new Observer<NetResultData<T>>() {
//
//            @Override
//            public void onSubscribe(Disposable d) {
//                LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//                String name = Thread.currentThread().getName();
//                long id = Thread.currentThread().getId();
//                if (callback != null) {
//                    callback.onStart(d);
//                }
//
//
//            }
//
//            @Override
//            public void onNext(NetResultData<T> netResult) {
//                LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//                String name = Thread.currentThread().getName();
//                long id = Thread.currentThread().getId();
//                try {
//                    //请求 服务端有响应， 但需要对其结果进行处理过滤， 有可能服务器告诉 此次请求异常， 统一以异常的形成 抛出
//                    //开始解析
//                    if (callback != null) {
//                        callback.onSuccess(netResult);
//                    }
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                    //加载数据的过程中出现了问题,例如 nullpointexception/指针超出的问题,会进行捕获
////                    callback.onError("出了点小问题，请稍后重试", String.valueOf(ErrorCode.error_code_LoadDataException));
//                    if (callback != null) {
//                        callback.onError(new ErrorMessage());
//                    }
//
//                } finally {
//                    if (callback != null) {
//                        callback.onFinish();
//                    }
//
//                }
//            }
//
//            @Override
//            public void onError(Throwable e) {
//                LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//                String name = Thread.currentThread().getName();
//                long id = Thread.currentThread().getId();
//                try {
//                    e.printStackTrace();
//                    //获取异常信息,  失效并发异常 ERROR_RETRY 会走这里
//                    //避免走两次
//                    if (!TextUtils.equals(e.getMessage(), TOKEN_RETRY_DOING)) {
//                        if (callback != null) {
//                            callback.onError(new ErrorMessage());
//                        }
//
//
//                    }
//
//                } finally {
//                    if (!TextUtils.equals(e.getMessage(), TOKEN_RETRY_DOING)) {
//                        if (callback != null) {
//                            callback.onFinish();
//                        }
//
//
//                    }
//
//                }
//            }
//
//            @Override
//            public void onComplete() {
//                LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//                String name = Thread.currentThread().getName();
//                long id = Thread.currentThread().getId();
//                if (callback != null) {
//                    callback.onFinish();
//                }
//
//
//            }
//        };
//
//
//        observable
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(observer1);
//        return observable;
//
//
//    }
//
//    /**
//     * 数据解析， 异常处理， 重试机制
//     *
//     * @param <Upstream>
//     * @param <T>
//     */
//    public static class NetDataTransformer<Upstream extends Response<JsonElement>, T> implements ObservableTransformer<Upstream, NetResultData<T>> {
//        private NetCallback<T> callback;
//        private Observable<T> observable;
//
//        //执行流程 onStart(只执行一次)- defer - onBefore - http拦截器-  执行请求(成功失败)， 重试 defer - onBefore - http拦截器 -  请求(成功失败)
//        public NetDataTransformer(NetCallback<T> callback) {
//            this.callback = callback;
//        }
//
//        public NetDataTransformer(Observable<T> observable, NetCallback<T> callback) {
//            this.callback = callback;
//            this.observable = observable;
//        }
//
//        public Observable<T> getObservable() {
//            return observable;
//        }
//
//        @Override
//        public ObservableSource<NetResultData<T>> apply(Observable<Upstream> upstreamObservable) {
//            observable = Observable.defer(new Callable<ObservableSource<ArrayMap<String, Object>>>() {
//                @RequiresApi(api = Build.VERSION_CODES.KITKAT)
//                @Override
//                public ObservableSource<ArrayMap<String, Object>> call() throws Exception {
//                    LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//                    String name = Thread.currentThread().getName();
//                    long id = Thread.currentThread().getId();
//                    // TODO: 2019/1/12 检查网络
//                    //定义
//                    ArrayMap<String, Object> signMap = new ArrayMap<>();
//                    NetDataTransformer.this.callback.onBefore(signMap);
//                    return Observable.just(signMap);
//                }
//            }).flatMap(new Function<ArrayMap<String, Object>, ObservableSource<T>>() {
//                @Override
//                public ObservableSource<T> apply(@NonNull ArrayMap<String, Object> paramsMap) {
//                    //执行网络请求
////                        Observable<JsonElement> observable1 = RxUtils.requestMap(httpMethod, url, null, callback.getClazz(), paramsMap, null, cacheMode);
////                        Observable<Response<JsonElement>> observable1 = observableCall;
//                    return observable;
//                }
//            });
//            return upstreamObservable
//                    .doOnSubscribe(new Consumer<Disposable>() {
//                        @Override
//                        public void accept(@NonNull Disposable disposable) throws Exception {
//                            NetDataTransformer.this.callback.onBefore(disposable);
//                        }
//                    })
//
//                    .map(new Function<Upstream, NetResultData<T>>() {
//                        @Override
//                        public NetResultData<T> apply(Upstream upstream) throws Exception {
//                            LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//                            String name = Thread.currentThread().getName();
//                            long id = Thread.currentThread().getId();
//                            // TODO: 2019/1/12  非手机网络 和 服务器问题的都会走该方法，所以这里是业务上异常的处理，要重试就抛出异常走retryWhen
//                            // TODO: 2019/1/12  手机网络 和 服务器异常问题重试是交给okHttp 的重试机制处理，所以不走retryWhen。
//                            // TODO: 2019/1/12  Response.body() == null 的话认为是链接失败，要求走缓存的话就读缓存
//
//                            JsonElement body = upstream.body();
//                            Exception currentException = null;
//                            NetResultData<T> tResultNetData = new NetResultData<>();
//                            try {
//                                if ((body != null)) {
//                                    String dataJson = ParseUtils.getStringResult(body, "data");
//                                    String statusCode = ParseUtils.getStringResult(body, "statusCode");
//                                    String statusError = ParseUtils.getStringResult(body, "statusError");
//                                    //获取泛型 解析数据
//                                    Class<T> tClass = (Class<T>) ((ParameterizedType) tResultNetData.getClass().getGenericSuperclass()).getActualTypeArguments()[0]; // 根据当前类获取泛型的Type
//                                    Type ty = new ParameterizedTypeImpl(tResultNetData.getClass(), new Class[]{tClass}); // 传泛型的Type和我们想要的外层类的Type来组装我们想要的类型
//                                    T data = JsonUtils.fromJson(dataJson, ty);
//                                    tResultNetData.setOutsideData(data);
//                                    tResultNetData.setStatusCode(Integer.valueOf(statusCode));
//                                    tResultNetData.setStatusMgs(statusError);
//                                } else {
//                                    //当做 api 异常处理
//                                    currentException = new ErrorException(NetEnum.ApiException.getId(), NetEnum.ApiException.getMessage(), NetEnum.ApiException);
//                                }
//
//                            } catch (Exception e) {
//                                currentException = new ErrorException(NetEnum.ParseException.getId(), NetEnum.ParseException.getMessage(), NetEnum.ParseException);
//
//                            } finally {
//                                if (currentException != null) {
//                                    ErrorExceptionUtil.throwException(currentException);
//                                }
//                                return tResultNetData;
//
//                            }
//
//
//                        }
//                    })
//                    .retryWhen(new Function<Observable<Throwable>, ObservableSource<?>>() {
//                        //请求异常包括token失效， 重试，统一处理入口
//                        private int mTokenRetryDoing = 0;
//
//                        @Override
//                        public ObservableSource<?> apply(Observable<Throwable> throwableObservable) throws Exception {
//                            return throwableObservable.flatMap(new Function<Throwable, ObservableSource<?>>() {
//                                @Override
//                                public ObservableSource<?> apply(Throwable throwable) throws Exception {
////                                if (throwable instanceof ApiCodeException) {
////                                    ApiCodeException bizException = (ApiCodeException) throwable;
////                                    if (mRetryCount > 0) {
////                                        return Observable.error(new Throwable(ERROR_RETRY));
////                                    } else if (bizException.getErrorCode() == ErrorCode.error_code_session_over_time
////                                            || bizException.getErrorCode() == ErrorCode.error_code_session_unable
////                                            || bizException.getErrorCode() == ErrorCode.error_code_sign_fail) {
////                                        mRetryCount++;
////                                        return SessionLoader.getInstance().getNetSessionLocked();
////                                    } else if (bizException.getErrorCode() == ErrorCode.error_code_session_renew) {
////                                        mRetryCount++;
////                                        return SessionRenewLoader.getInstance().getNetSessionLocked();
////                                    } else if (bizException.getErrorCode() == ErrorCode.error_code_token_need) {
////                                        mRetryCount++;
////                                        return TokenLoader.getInstance().getNetTokenLocked();
////                                    } else if (ErrorCode.isTokenOverTime(bizException.getErrorCode())) {
////                                        ContextModule.getInstance().gotoLogin();
////                                        return Observable.error(throwable);
////                                    } else {
////                                        return Observable.error(throwable);
////                                    }
////
////                                } else {
////                                    return Observable.error(throwable);
////                                }
//                                    // TODO: 2019/1/12 定义一个异常引擎， 对异常进行判断 分别处理。 网络异常 包括没有网络 和  服务器链接不上
//
//                                    if (throwable instanceof Throwable) {
//                                        if (mTokenRetryDoing > 0) {
//                                            return Observable.error(new Throwable(TOKEN_RETRY_DOING));
//                                        } else {
//                                            //模拟token异常， 重新处理
//                                            mTokenRetryDoing++;
//                                            return appInfoConfig.getTokenChainLoader().getNetTokenLocked();
//                                        }
//                                    }
//                                    return Observable.error(throwable);
//
//                                }
//                            });
//
//                        }
//                    })
//                    .subscribeOn(Schedulers.io())
//                    .observeOn(AndroidSchedulers.mainThread());
//        }
//    }
//
//
//    /*====sumer 改造start =============================================================================================*/
//    // TODO: 2019/1/11 网络层逻辑改造
//    private Observable<Response<JsonElement>> mObservableCall;
//    private static final String TOKEN_RETRY_DOING = "token_retry_doing";
//
//    /**
//     * 数据订阅 回调处理
//     *
//     * @param <T>
//     */
//    public static class NetCallbackObserver<T> implements Observer<NetResultData<T>> {
//        private NetCallback<T> callback;
//        private Observable<T> observable;
//
//
//        public NetCallbackObserver(NetCallback<T> callback) {
//            this.callback = callback;
//        }
//
//        public NetCallbackObserver(NetCallback<T> callback, Observable<T> observable) {
//            this.callback = callback;
//            this.observable = observable;
//        }
//
//
//        @Override
//        public void onSubscribe(Disposable d) {
//            LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//            String name = Thread.currentThread().getName();
//            long id = Thread.currentThread().getId();
//            callback.onStart(d);
//
//        }
//
//        @Override
//        public void onNext(NetResultData<T> value) {
//            LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//            String name = Thread.currentThread().getName();
//            long id = Thread.currentThread().getId();
//            try {
//                //请求 服务端有响应， 但需要对其结果进行处理过滤， 有可能服务器告诉 此次请求异常， 统一以异常的形成 抛出
//                //开始解析
//                callback.onSuccess(value);
//            } catch (Exception e) {
//                e.printStackTrace();
//                //加载数据的过程中出现了问题,例如 nullpointexception/指针超出的问题,会进行捕获
////                    callback.onError("出了点小问题，请稍后重试", String.valueOf(ErrorCode.error_code_LoadDataException));
//                ErrorMessage errorMessage = new ErrorMessage();
//                errorMessage.setErrorMsg("出了点小问题，请稍后重试");
//                callback.onError(errorMessage);
//            } finally {
//                callback.onFinish();
//            }
//        }
//
//        @Override
//        public void onError(Throwable e) {
//            LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//            String name = Thread.currentThread().getName();
//            long id = Thread.currentThread().getId();
//            ErrorMessage errorMessage = new ErrorMessage();
//            try {
//                e.printStackTrace();
//                //获取异常信息,  失效并发异常 ERROR_RETRY 会走这里
////                    NetExceptionEngineOld netException = NetExceptionEngineOld.handleException(e);
////                    if (TextUtils.equals(ERROR_RETRY, netException.getErrorMsg())) {
////                        return;
////                    }
////                    if (netException.isShowToast()) {
////                        ToastManager.getInstance(BaseApplication.getInstance()).showText(netException.getErrorMsg());
////                    }
////                    callback.onError(netException.getErrorMsg(), String.valueOf(netException.getErrorCode()));
//
//                //避免走两次
//                if (!TextUtils.equals(e.getMessage(), TOKEN_RETRY_DOING)) {
//                    callback.onError(errorMessage);
//                }
//
//            } finally {
//                if (!TextUtils.equals(e.getMessage(), TOKEN_RETRY_DOING)) {
//                    callback.onFinish();
//
//                }
//
//            }
//        }
//
//        @Override
//        public void onComplete() {
//            LogUtil.d("callback", Thread.currentThread().getName() + Thread.currentThread().getId());
//            String name = Thread.currentThread().getName();
//            long id = Thread.currentThread().getId();
//            callback.onFinish();
//
//        }
//    }
//
//}
