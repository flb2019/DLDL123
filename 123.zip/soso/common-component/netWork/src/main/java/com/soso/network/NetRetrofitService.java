package com.soso.network;

import com.google.gson.JsonElement;

import java.util.HashMap;
import java.util.Map;

import io.reactivex.Observable;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.HeaderMap;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.QueryMap;
import retrofit2.http.Streaming;
import retrofit2.http.Url;

/**
 * Created by sumerlin on 2019/1/13 16:22.
 * Describe:
 */
public interface NetRetrofitService {

    /*====原有接口2019.01.13==========================================================================================*/

    /**
     * fetch data by rule id
     * 是否必填     说明
     *
     * @param grantType    否          认证模式
     * @param clientId     否          客户端id
     * @param clientSecret 否          客户端秘钥
     * @param refreshToken 否          刷新令牌
     * @return 返回  Observable
     */
    @FormUrlEncoded
    @POST("oauth/authorizationServer/accessToken")
    Observable<Response<JsonElement>> getToken(@Field("grant_type") String grantType,
                                               @Field("client_id") String clientId,
                                               @Field("client_secret") String clientSecret,
                                               @Field("refresh_token") String refreshToken);

    /**
     * 默认帐号模式,进行登录
     */
    @FormUrlEncoded
    @POST("oauth/authorizationServer/accessToken")
    Observable<Response<JsonElement>> login(@Field("grant_type") String grantType,
                                            @Field("client_id") String clientId,
                                            @Field("client_secret") String clientSecret,
                                            @Field("username") String username,
                                            @Field("password") String password,
                                            @Field("refresh_token") String refreshToken);

    /**
     * 使用QQ进行登录
     */
    @FormUrlEncoded
    @POST("oauth/authorizationServer/accessToken")
    Observable<Response<JsonElement>> qqLogin(@Field("grant_type") String grantType,
                                              @Field("client_id") String clientId,
                                              @Field("client_secret") String clientSecret,
                                              @Field("access_token") String access_token);

    /**
     * 使用微信进行登录
     */
    @FormUrlEncoded
    @POST("oauth/authorizationServer/accessToken")
    Observable<Response<JsonElement>> wxLogin(@Field("grant_type") String grantType,
                                              @Field("client_id") String clientId,
                                              @Field("client_secret") String clientSecret,
                                              @Field("code") String code);

    /**
     * 使用手机号码进行登录
     */
    @FormUrlEncoded
    @POST("oauth/authorizationServer/accessToken")
    Observable<Response<JsonElement>> phoneLogin(@Field("grant_type") String grantType,
                                                 @Field("client_id") String clientId,
                                                 @Field("client_secret") String clientSecret,
                                                 @Field("username") String username,
                                                 @Field("code") String code);

    /**
     * 使用手机号码进行登录
     */
    @FormUrlEncoded
    @POST("oauth/authorizationServer/accessToken")
    Observable<Response<JsonElement>> register(@Field("grant_type") String grantType,
                                               @Field("client_id") String clientId,
                                               @Field("client_secret") String clientSecret,
                                               @Field("username") String username,
                                               @Field("code") String code);


    /**
     * fetch data by rule id
     *
     * @param path     拼接地址
     * @param dataJson 传参 是以json格式
     * @return 返回  Observable
     */
    @POST()
    Call<JsonElement> post(@Url String path, @Body Object dataJson);

    @POST()
    Call<JsonElement> post(@Url String path);

    @POST
    Call<JsonElement> postUrl(@Url String baseUrl, @Body Object dataJson);

    @GET
    Call<JsonElement> getUrl(@Url String baseUrl);

    //旧接口get方法
    @GET
    Call<JsonElement> get(@Url String baseUrl, @HeaderMap HashMap<String, String> mHeaders);

    @GET
    Call<JsonElement> get(@Url String baseUrl);

    //旧接口post方法
    @POST
    @FormUrlEncoded
    Call<JsonElement> post(@Url String baseUrl, @HeaderMap HashMap<String, String> mHeaders, @FieldMap HashMap<String, String> mParams);





    /*====新增接口接口2019.01.13==========================================================================================*/
    //@QueryMap注解会把参数拼接到url后面，所以它适用于GET请求；@Body会把参数放到请求体中，所以适用于POST请求。

    /**
     * 以get方式的网络请求接口
     *
     * @param url      可传全路径或者只传baseUrl之后的路径
     * @param queryMap 键值对参数
     */
    @GET("")
    Observable<Response<JsonElement>> getObservable(@Url String url, @QueryMap Map<String, Object> queryMap);

    @GET("")
    Observable<Response<JsonElement>> getObservable(@Url String url);

    /**
     * Created by sumerlin on 2019/1/15 2019/1/15.
     * 以post方式的网络请求接口, post实体
     *
     * @param url      可传全路径或者只传baseUrl之后的路径
     * @param queryMap 键值对参数
     */
    @POST("")
    Observable<Response<JsonElement>> postBodyObservable(@Url String url, @Body Map<String, String> queryMap);

    /**
     * @param url
     * @param bodyBean 传递一个实体类bean
     * @return
     */
    @POST("")
    Observable<Response<JsonElement>> postBodyObservable(@Url String url, @Body Object bodyBean);

    //    @POST("")
//    Observable<Response<JsonElement>> postBodyObservable(@Url String url, @Body String bodyJson);
    @POST("")
    Observable<Response<JsonElement>> postBodyObservable(@Url String url,@HeaderMap  Map<String, String> headers, @Body Object bodyBean);

    @POST("")
    Observable<Response<JsonElement>> postBodyObservable(@Url String url);


    /**
     * post表单
     */
    @FormUrlEncoded
    @POST("")
    Observable<Response<JsonElement>> postField(@Url String url, @FieldMap Map<String, String> map);

    /**
     * 单图上传
     */
    @Multipart
    @POST("")
    Observable<Response<JsonElement>> upLoadFile(
            @Url String url,
            @Part MultipartBody.Part file
    );

    /**
     * 测试中 多图上传
     */
    @Multipart
    @POST("")
    Observable<Response<JsonElement>> uploadFiles(
            @Url String url,
            @Part("filename") String description,
            @PartMap() Map<String, RequestBody> maps);


    /**
     * 测试中 下载
     */
    @Streaming
    @GET
    Observable<Response<JsonElement>> downloadFile(@Url String fileUrl);
}
