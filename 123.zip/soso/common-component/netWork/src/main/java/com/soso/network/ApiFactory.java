package com.soso.network;

import com.google.gson.JsonElement;
import com.soso.network.callback.NetCallback;
import com.soso.network.interceptor.HeaderInterceptor;
import com.soso.network.tools.GsonConvertUtils;
import com.soso.network.transformer.ProcessTransformerImpl;
import com.soso.sosolib.art.tools.AppComponentUtils;
import com.soso.sosolib.todo.AppInfoModule;

import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import io.reactivex.Observable;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Response;

/**
 * Created by sumerlin on 2019/1/13
 * Version 1.0
 * Net 自定义封装,会可在外部直接使用
 * 请求头参数 在{@link HeaderInterceptor} 进行统一配置， 在这里就不配置了。
 * 直接调用get、 post等方法，会{@link ProcessTransformerImpl#doExecute()}  }和 {@link com.soso.sosolib.todo.TokenRefreshChainLoader}, 会检查是否有异常 token 异常， 并重试失败请求
 * 调用 {@link ApiFactory#getInstance()#getSingletonRetrofitFactory()} 只是简单的请求， 没有异常（token 失效等逻辑判断），所以要自处理
 */
public class ApiFactory {

    private static volatile ApiFactory mApiFactory;


    /**
     * 单例对象初始化，必须使用private修饰
     */
    private ApiFactory() {
        AppInfoModule appInfoConfig = AppComponentUtils.getAppComponent().getAppInfoModule();
    }

    /**
     * 全局handers
     */
    private Map<String, String> HeadersMap = new HashMap<>();
    private Map<String, String> dmap = new HashMap<>();

    /**
     * Builder模式的初始化，保留
     */
    private ApiFactory(Builder builder) {
        this.HeadersMap = builder.HeadersMap;
    }

    /**
     * 获取单例
     */
    public static ApiFactory getInstance() {
//        return ApiMethodsHolder.netModle;
        if (mApiFactory == null) {
            synchronized (ApiFactory.class) {
                if (mApiFactory == null) {
                    mApiFactory = new ApiFactory();
                }
            }
        }

        return mApiFactory;
    }

    public static void initWhenAppStart() {
        getInstance();
    }

    /**
     * 静态内部类，实现线程安全、延迟加载、高效的单例模式。
     */
    private static class ApiMethodsHolder {
        private static ApiFactory netModle = new ApiFactory();
    }

    /*=====================================================================*/

    /**
     * @param url       地址
     * @param paramsMap 数据集合
     * @param callback  回调
     */
    public <T> void get(String url, Map<String, Object> paramsMap, NetCallback<T> callback) {
        get(url, paramsMap, null, callback);
    }

    /**
     * get方式
     *
     * @param url        地址
     * @param paramsMap  数据集合
     * @param HeadersMap 自定义的header集合
     * @param callback   回调
     */
    public <T> void get(String url, Map<String, Object> paramsMap, Map<String, String> HeadersMap, NetCallback<T> callback) {
//        paramsMap = addParams(paramsMap);
//        getSingletonRetrofitFactory(paramsMap)
//                .getRetrofitService()
//                .getObservable(url, HeadersMap)
//                .compose(new ProcessTransformer.NetDataTransformer<Response<JsonElement>, T>(callback))
//                .subscribe(new ProcessTransformer.NetCallbackObserver<>(callback));

        Observable<Response<JsonElement>> responseObservable = getSingletonRetrofitFactory(HeadersMap)
                .getRetrofitService()
                .getObservable(url, paramsMap!= null ? paramsMap : new HashMap<String, Object>());
        ProcessTransformerImpl<T> tProcessTransformer = new ProcessTransformerImpl<T>(responseObservable, callback);
        tProcessTransformer.doExecute();
    }


    /*==== 主要方法===========================================================================================*/

    /**
     * post方式
     *
     * @param url      地址
     * @param bodyBean 数据集合
     * @param callback 回调
     */
    public <T> void postBody(String url, Object bodyBean, NetCallback<T> callback) {
        Observable<Response<JsonElement>> responseObservable = getSingletonRetrofitFactory(HeadersMap)
                .getRetrofitService()
                .postBodyObservable(url, toJsonParser(bodyBean));
        ProcessTransformerImpl<T> tProcessTransformer = new ProcessTransformerImpl<T>(responseObservable, callback);
        tProcessTransformer.doExecute();

    }

    /**
     * post方式
     *
     * @param url       地址
     * @param paramsMap 数据集合
     * @param callback  回调
     */
    public <T> void postBody(String url, Map<String, String> paramsMap, NetCallback<T> callback) {
        postBody(url, paramsMap, null, callback);
    }

    /**
     * post方式
     *
     * @param url        地址
     * @param bodyBean
     * @param HeadersMap
     * @param callback   回调
     * @param <T>
     */
    public <T> void postBody(String url, Object bodyBean, Map<String, String> HeadersMap, NetCallback<T> callback) {
//paramsMap = addParams(paramsMap);
        Observable<Response<JsonElement>> responseObservable = getSingletonRetrofitFactory(HeadersMap)
                .getRetrofitService()
                .postBodyObservable(url, toJsonParser(bodyBean));
        ProcessTransformerImpl<T> tProcessTransformer = new ProcessTransformerImpl<T>(responseObservable, callback);
        tProcessTransformer.doExecute();

    }

    /**
     * post方式
     *
     * @param url        地址
     * @param paramsMap  数据集合
     * @param HeadersMap 自定义的header集合,不传的话使用默认的header
     * @param callback   回调
     */
    public <T> void postBody(String url, Map<String, String> paramsMap, Map<String, String> HeadersMap, NetCallback<T> callback) {
        //paramsMap = addParams(paramsMap);
//        getSingletonRetrofitFactory(HeadersMap)
//                .getRetrofitService()
//                .postBodyObservable(url, paramsMap)
//                .compose(new ProcessTransformer.NetDataTransformer<Response<JsonElement>, T>(callback))
//                .subscribe(new ProcessTransformer.NetCallbackObserver<>(callback));
        Observable<Response<JsonElement>> responseObservable = getSingletonRetrofitFactory(HeadersMap)
                .getRetrofitService()
                .postBodyObservable(url, paramsMap);
        ProcessTransformerImpl<T> tProcessTransformer = new ProcessTransformerImpl<T>(responseObservable, callback);
        tProcessTransformer.doExecute();
    }


    /**
     * post传表单FieldMap
     */
    public <T> void postField(String url, Map<String, String> parme, Map<String, String> HeadersMap, NetCallback<T> callback) {
        getSingletonRetrofitFactory(HeadersMap)
                .getRetrofitService()
                .postField(url, parme)
                .compose(new ProcessTransformerImpl.NetDataTransformer<Response<JsonElement>, T>(callback))
                .subscribe(new ProcessTransformerImpl.NetCallbackObserver<>(callback));

    }

    /**
     * 图片上传post方式
     *
     * @param url      地址
     * @param path     图片地址
     * @param callback 回调
     */
    public <T> void upload(String url, String path, NetCallback<T> callback) {
        upload(url, path, null, callback);
    }

    /**
     * 图片上传post方式
     *
     * @param url        地址
     * @param path       图片地址
     * @param HeadersMap 自定义的header集合,不传的话使用默认的header
     * @param callback   回调
     */
    public <T> void upload(String url, String path, Map<String, String> HeadersMap, NetCallback<T> callback) {
        //Subscription d =
        getSingletonRetrofitFactory(HeadersMap)
                .getRetrofitService()
                .upLoadFile(url, getMultipartBodyPart(path))
                .compose(new ProcessTransformerImpl.NetDataTransformer<Response<JsonElement>, T>(callback))
                .subscribe(new ProcessTransformerImpl.NetCallbackObserver<>(callback));
    }

    /**
     * 图片上传post方式
     *
     * @param url        地址
     * @param file       图片文件
     * @param HeadersMap 自定义的header集合,不传的话使用默认的header
     * @param callback   回调
     */
    public <T> void upload(String url, File file, Map<String, String> HeadersMap, NetCallback<T> callback) {
        //Subscription d =
        getSingletonRetrofitFactory(HeadersMap)
                .getRetrofitService()
                .upLoadFile(url, getMultipartBodyPart(file))
                .compose(new ProcessTransformerImpl.NetDataTransformer<Response<JsonElement>, T>(callback))
                .subscribe(new ProcessTransformerImpl.NetCallbackObserver<>(callback));
    }

    /**
     * 文件上传
     */
    private MultipartBody.Part getMultipartBodyPart(String mPath) {
        File file = new File(mPath);
        //multipart/form-data 格式
        RequestBody requestFile =
                RequestBody.create(MediaType.parse("multipart/form-data"), file);
        //file - 为上传参数的 键名
        MultipartBody.Part body =
                MultipartBody.Part.createFormData("file", file.getName(), requestFile);
        return body;
    }

    /**
     * 文件上传
     */
    private MultipartBody.Part getMultipartBodyPart(File file) {
        //multipart/form-data 格式
        RequestBody requestFile =
                RequestBody.create(MediaType.parse("multipart/form-data"), file);
        //file - 为上传参数的 键名
        MultipartBody.Part body =
                MultipartBody.Part.createFormData("file", file.getName(), requestFile);
        return body;
    }

    /**
     * new 一个 获取RetrofitFactory对象
     */
    private NetRetrofitFactory getNewRetrofitFactory(Map<String, String> HeadersMap) {

        NetRetrofitFactory baseRetrofitFactory = null;

        if (HeadersMap != null) {
            baseRetrofitFactory = new NetRetrofitFactory.Builder()
                    .setHeaders(HeadersMap)
                    .build();
        } else {
            /* 在这里添加默认的 handers */
            dmap = NetRetrofitConfig.getHanderCommonParameter();
            //LogUtil.d("getHanderCommonParameter="+dmap.size()+" moren");
            baseRetrofitFactory = new NetRetrofitFactory.Builder()
                    .setHeaders(dmap)
                    .build();
        }
        return baseRetrofitFactory;
    }


    /**
     * 获取 当前维护的一个获取RetrofitFactory对象
     *
     * @param HeadersMap
     * @return
     */
    private volatile static NetRetrofitFactory mSingletonRetrofitFactory = null;

    public NetRetrofitFactory getSingletonRetrofitFactory() {
        return getSingletonRetrofitFactory(null);
    }

    private NetRetrofitFactory getSingletonRetrofitFactory(Map<String, String> HeadersMap) {
        NetRetrofitFactory baseRetrofitFactory = null;
        if (mSingletonRetrofitFactory == null) {
            synchronized (this) {
                if (mSingletonRetrofitFactory == null) {
                    if (HeadersMap != null) {
                        baseRetrofitFactory = new NetRetrofitFactory.Builder()
                                .setHeaders(HeadersMap)
                                .build();
                    } else {
                        /* 在这里添加默认的 handers */
                        dmap = NetRetrofitConfig.getHanderCommonParameter();
                        //LogUtil.d("getHanderCommonParameter="+dmap.size()+" moren");
                        baseRetrofitFactory = new NetRetrofitFactory.Builder()
                                .setHeaders(dmap)
                                .build();
                    }
                }
            }
        }
        return baseRetrofitFactory;
    }


    /**
     * 追加params数据
     * 可不用此方法，已摒弃
     */
    @Deprecated
    private Map addParams(Map parame) {
        Map<String, String> p = null;
        p = NetRetrofitConfig.getCommonParameter();
        if (p != null) {
            parame.putAll(p);
        }
        return parame;
    }

    /**
     * Builder，留用 暂时未用 ，当前是以静态方法方式实现的
     */
    public class Builder {

        Map<String, String> HeadersMap;

        Map<String, String> paramsMap;

        public Builder setHander(Map<String, String> HeadersMap) {
            this.HeadersMap = HeadersMap;
            return this;
        }

        public Builder setMap(Map<String, String> paramsMap) {
            this.paramsMap = paramsMap;
            return this;
        }

        public ApiFactory build() {
            return new ApiFactory(this);
        }
    }


    /**
     * 设置请求参数 转换
     */
    public static Object toJsonParser(Object objectBean) {
        Object objectJson = null;
        if (objectBean != null) {
            try {
                objectJson = objectBean;
                if (objectJson instanceof String) {
                    objectJson = GsonConvertUtils.getJsonParser().parse((String) objectBean);
                } else if (objectJson instanceof JSONObject) {
                    objectJson = GsonConvertUtils.getJsonParser().parse(objectJson.toString());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return objectJson;
    }

    /*======20190118,sumer ,builder 方式调用=======================================================================================*/
    public static CreateBuilder postBody() {
        return new CreateBuilder();
    }

    public static class CreateBuilder {
        private String url;
        private Object paramBean;
        private NetCallback mNetCallback;

        public CreateBuilder setUrl(String url) {
            this.url = url;
            return this;
        }

        public CreateBuilder setParamBean(Object paramBean) {
            this.paramBean = paramBean;
            return this;
        }

        public <T> void doExecute(NetCallback<T> callback) {
            getInstance().postBody(url, paramBean, callback);
        }

    }

}
