package com.soso.network.core.cache;

import com.soso.sosolib.utils.JsonUtils;

import java.util.concurrent.TimeUnit;

import okhttp3.CacheControl;

/**
 * Created by sumerlin on 2019/4/13 2019/4/13.
 * Describe:
 */
public class CacheStrategyModel {
    public int cacheTime = 60;

    public CacheStrategyModel builder() {
        return new CacheStrategyModel();

    }

    public CacheStrategyModel cacheTime(int cacheTime) {
        this.cacheTime = cacheTime;
        return this;

    }

    public String toString() {
        return JsonUtils.formatJson(this);
    }

    public static CacheStrategyModel toObject(String json) {
        return JsonUtils.fromJson(json, CacheStrategyModel.class);

    }

    public static CacheControl toCacheControl(String json) {
        CacheStrategyModel cacheStrategyModel = toObject(json);
        return new CacheControl
                .Builder().maxStale(cacheStrategyModel.cacheTime, TimeUnit.SECONDS)
                .onlyIfCached()
                .build();

    }

}
