package com.soso.network.bean;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * Created by sumerlin on 2019/1/13 3:21.
 * Describe: 解析泛型 内嵌类
 */
public class ParameterizedTypeImpl implements ParameterizedType {
    private final Class raw;
    private final Type[] args;

    public ParameterizedTypeImpl(Class raw, Type[] args) {
        this.raw = raw;
        this.args = args != null ? args : new Type[0];
    }

    @Override
    public Type[] getActualTypeArguments() {
        return args;
    }

    @Override
    public Type getRawType() {
        return raw;
    }

    @Override
    public Type getOwnerType() {
        return null;
    }

}
