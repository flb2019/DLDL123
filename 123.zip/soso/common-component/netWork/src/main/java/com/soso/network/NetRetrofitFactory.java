package com.soso.network;

import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import com.soso.network.interceptor.HeaderDynamicInterceptor;
import com.soso.network.interceptor.HeaderInterceptor;
import com.soso.network.interceptor.LoggerImpl;
import com.soso.network.interceptor.LoggingInterceptor;
import com.soso.network.tools.Switch;
import com.soso.sosolib.art.tools.AppComponentUtils;

import java.lang.reflect.Field;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by sumerlin on 2019/1/13
 * Version 1.0
 * 初始化Retrofit 2.+
 * 1.配置OkHttpClient、添加拦截器
 * 2.添加HttpLoggingInterceptorM 日志拦截
 * 3.配置Retrofit
 */
public class NetRetrofitFactory {

    /**
     * 添加header响应头的集合,用于存放追加的header头的数据
     * */
    private Map<String,String> map = new HashMap<>();

    /**
     * 自定义Interceptor对象，用于在网络请求发出之前将header拦截添加进响应头
     * */
    private HeaderDynamicInterceptor mHeaderDynamicInterceptor = null;


    /**
     * okhttp的日志拦截，可在正式发布时关闭
     * */
//    private HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY);
    /**
     * 自定义okhttp的日志拦截，可在正式发布时关闭
     * */
    private LoggingInterceptor mLoggingInterceptor = new LoggingInterceptor(new LoggerImpl()).setLevel(LoggingInterceptor.Level.BODY);


    /**
     * 构造器，通过builder方式传入header响应头并初始化自定义拦截器Interceptor
     * */
    private NetRetrofitFactory(Builder builder){
        map.clear();
        this.map = builder.map;
        mHeaderDynamicInterceptor = new HeaderDynamicInterceptor(map);
    }

    /**
     * 创建自定义OkHttpClient对象，初始化日志拦截、错误重连、超时、响应头等信息
     * */
    private OkHttpClient getClient(){
        OkHttpClient client = null;
//        File httpCacheDirectory = new File(ApiConfig.getInstant().getContext().getExternalCacheDir(), "responses");
//        String net = BaseNetConfig.getNetEnvironment(ApiConfig.getInstant().getContext());
        if(Switch.isDebug){
            client = new OkHttpClient.Builder()
//                    .cache(new Cache(httpCacheDirectory, 10 * 1024 * 1024))     //设置缓存
//                    .cookieJar(new CookieManger(BaseApplication.getAppContext()))                   //缓存cookie
                    .retryOnConnectionFailure(true)                                         //错误重连
                    .connectTimeout(NetRetrofitConfig.OKHTTP_OVERTIME, TimeUnit.SECONDS)   //超时时间
                    .readTimeout(NetRetrofitConfig.OKHTTP_OVERTIME, TimeUnit.SECONDS)
                    .addInterceptor(mLoggingInterceptor)                                           //日志拦截
                    .addNetworkInterceptor(new HeaderInterceptor())                                   //拦截添加响应头
                    .hostnameVerifier(new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    })
                    .build();
        }else{
            client = new OkHttpClient.Builder()
//                    .cookieJar(new CookieManger(BaseCommonApplication.getAppContext()))                   //缓存cookie
//                    .cache(new Cache(httpCacheDirectory, 10 * 1024 * 1024))     //设置缓存
                    .retryOnConnectionFailure(true)                                         //错误重连
                    .connectTimeout(NetRetrofitConfig.OKHTTP_OVERTIME, TimeUnit.SECONDS)   //超时时间
                    .readTimeout(NetRetrofitConfig.OKHTTP_OVERTIME, TimeUnit.SECONDS)
//                    .addNetworkInterceptor(mHeaderDynamicInterceptor)                                   //拦截添加响应头
                    .addNetworkInterceptor(new HeaderInterceptor())                                   //拦截添加响应头
                    .hostnameVerifier(new HostnameVerifier() {
                        @Override
                        public boolean verify(String hostname, SSLSession session) {
                            return true;
                        }
                    })
                    .build();
        }
        onShieldingCertification(client);
        return client;
    }


    /**
     * 屏蔽掉ssl认证
     */
    private void onShieldingCertification(OkHttpClient client) {
        //本地屏蔽SSL认证
        SSLContext sslContext = null;
        try {
            sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, new TrustManager[]{new X509TrustManager() {
                @Override
                public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {


                }

                @Override
                public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {

                }

                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            }}, new SecureRandom());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }

        HostnameVerifier eellyVerifier = new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        String workerClassName = "okhttp3.OkHttpClient";
        try {
            Class workerClass = Class.forName(workerClassName);
            Field hostnameVerifier = workerClass.getDeclaredField("hostnameVerifier");
            hostnameVerifier.setAccessible(true);
            hostnameVerifier.set(client, eellyVerifier);

            Field sslSocketFactory = workerClass.getDeclaredField("sslSocketFactory");
            sslSocketFactory.setAccessible(true);
            sslSocketFactory.set(client, sslContext.getSocketFactory());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }


    /**
     * 初始化Retrofit对象，包括baseUrl、使用Gson解析、是用RxJava等。
     * */
    private Retrofit getRetrofit(){
        Retrofit retrofit = new Retrofit.Builder()
                .client(getClient())                                                    //添加自定义OkHttpClient
                .baseUrl(getApiHost())                                    //base地址
//                .addConverterFactory(ScalarsConverterFactory.create())                  //添加解析方式为String
                .addConverterFactory(GsonConverterFactory.create())                     //添加解析方式为Gson
//                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())               //添加网络RxJava
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())               //添加网络RxJava

                .build();
        return retrofit;
    }

    /**
     * 创建一个 CommonRetrofitService 服务实例
     * */
    public NetRetrofitService getRetrofitService(){
        NetRetrofitService service = getRetrofit().create(NetRetrofitService.class);
        return service;
    }

    /**
     * Builder
     * */
    public static class Builder{

        Map<String,String> map = new HashMap<>();

        public Builder setHeaders(Map<String,String> map){
            this.map = map;
            return this;
        }

        public NetRetrofitFactory build(){
            return new NetRetrofitFactory(this);
        }
    }


    private static String getApiHost() {
        return AppComponentUtils.getAppComponent().getAppInfoModule().getApiHost();
    }
}
