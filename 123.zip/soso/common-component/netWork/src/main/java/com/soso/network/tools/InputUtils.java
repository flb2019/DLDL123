package com.soso.network.tools;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.EditText;

import com.soso.sosolib.utils.ToastManager;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by 黄艳武 on 2016/3/23.;
 * 对于用户输入的判断
 */
public class InputUtils {
    /***
     * @return 获取一段字符中, 中文字符串的长度和其他字符串的长度
     */

    private static Pattern pattern = Pattern.compile("[\u4E00-\u9FA5]+");

    public static int[] getChinesLetterCountAndOther(String input) {
        if (TextUtils.isEmpty(input)) {
            return new int[]{0, 0};
        }
        String temp = null;

        Matcher m = pattern.matcher(input);
        int count = 0;
        while (m.find()) {
            temp = m.group(0);
            count += temp.length();
        }
        return new int[]{count, input.length() - count};
    }

    public interface SimpleTextWatcher {
        public void onTextChanged(CharSequence s, int start, int before, int count);
    }

    /**
     * 汉字为两个字符,英语为一个字符
     */
    public static int getLetterCount(String input) {
        int[] counts = getChinesLetterCountAndOther(input);
        return counts[0] * 2 + counts[1];
    }

    /****
     * @return 添加一个建议的监听事件
     */
    public static void addSimpleTextWatcher(EditText editText, @NonNull final SimpleTextWatcher simpleListener) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (simpleListener != null) {
                    simpleListener.onTextChanged(s, start, before, count);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    /****
     * @param maxSize 输入汉字的个数
     * @return 添加一个建议的监听事件
     */
    public static void addSimpleTextWatcher(EditText editText, final Context context, final int maxSize) {
        addSimpleTextWatcher(editText, context, maxSize, "不能超过" + maxSize + "个汉字哦...", "输入的字符超过限制...");
    }

    /****
     * @param maxSize 输入汉字的个数
     * @return 添加一个建议的监听事件
     */
    public static void addSimpleTextWatcher(EditText editText, final Context context, final int maxSize, final String tip1, final String tips2) {
        addSimpleTextWatcher(editText, new InputUtils.SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > maxSize) {
                    int[] counts = InputUtils.getChinesLetterCountAndOther(s.toString().trim());
                    int totalCount = counts[0] * 2 + counts[1];
                    if (counts[0] > maxSize && counts[0] == s.length()) {
                        ToastManager.getInstance(context).showText(tip1);
                    } else if (totalCount > maxSize * 2) {
                        ToastManager.getInstance(context).showText(tips2);
                    }
                }
            }
        });
    }

    /***
     * @return 输入小数点的时候，自动0.并且输入小数的时候只能输入两位
     */
    public static void addWatcher(final EditText ev_input_weight, final onTextListener onTextListener) {
        ev_input_weight.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                setDecimalLastTwo(ev_input_weight);
                if (onTextListener != null) {
                    onTextListener.onFinishDeal(ev_input_weight.getText().toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    /***
     * @return 限制输入只能输入到小数点后两位
     */
    public static void setDecimalLastTwo(EditText decimalLastTwo) {
        String text = decimalLastTwo.getText().toString();
        if (decimalLastTwo.hasFocus() && text.contains(".") && !text.endsWith(".")) {
            int position = text.lastIndexOf(".");
            if (text.length() - position > 3) {
                decimalLastTwo.setText(text.substring(0, position + 3));
            }
        }
    }

    /***
     * 输入是否超出了限制
     *
     * @return 最大字符, 汉字算两个, 英文算一个
     */
    public static boolean isSurpassLismit(String s, int maxCount) {
        if (!TextUtils.isEmpty(s)) {
            int[] counts = InputUtils.getChinesLetterCountAndOther(s.toString().trim());
            if (counts == null || counts.length <= 0) {
                return false;
            }
            int totalCount = counts[0] * 2 + counts[1];//这里表示的是汉字*2+其他*1=总字符的长度
            if (totalCount > maxCount) {//18表示的是字符的长度
                return true;
            }
        }
        return false;
    }

    /**
     * @return 超出了多少个字符, 返回的是字符, 汉子算两个字符
     */
    public static int surpassLitmitCount(String s, int maxCount) {
        int[] counts = InputUtils.getChinesLetterCountAndOther(s);
        if (counts == null || counts.length <= 0) {
            return 0;
        }
        int totalCount = counts[0] * 2 + counts[1];//这里表示的是汉字*2+其他*1=总字符的长度
        return totalCount - maxCount;
    }

    /**
     * 返回的是字符, 汉子算两个字符
     */
    public static int surpassCount(String s) {
        int[] counts = InputUtils.getChinesLetterCountAndOther(s);
        if (counts == null || counts.length <= 0) {
            return 0;
        }
        int totalCount = counts[0] * 2 + counts[1];//这里表示的是汉字*2+其他*1=总字符的长度
        return totalCount;
    }

    /**
     * 汉字算两个, 英文算一个
     *
     * @return 返回限定的文本数量:汉字和英文数量加起来为maxCount
     */
    public static String getMaxString(String s, int maxCount) {
        if (TextUtils.isEmpty(s) || !InputUtils.isSurpassLismit(s, maxCount)) {
            return s;//为空或者没超出限定都直接返回
        }

        int count = 0;

        char[] characters = s.toCharArray();
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < characters.length; i++) {
            if (pattern.matcher(String.valueOf(characters[i])).matches()) {//是汉字
                count += 2;
            } else {
                count += 1;
            }
            if (count > maxCount) {
                break;
            }
            stringBuilder.append(characters[i]);
        }
        return stringBuilder.toString();
    }

    /**
     * @param nickName
     */
    public static boolean isInputEmoj(String nickName) {
        for (int i = 0; i < nickName.length(); i++) {
            if (EmojFilters.isEmojiCharacter(nickName.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    public interface onTextListener {
        public void onFinishDeal(String price);
    }

    public static String replaceCharacterWitch(String text, String replaceChar) {
        if (TextUtils.isEmpty(text)) {
            return text;
        }
        String string = "";
        for (int i = 0; i < text.length(); i++) {
            string += replaceChar;
        }
        return string;
    }

}
