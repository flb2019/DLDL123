package com.soso.network.tools;

import android.text.TextUtils;

import com.google.gson.JsonElement;

/**
 * Created by sumerlin on 2019/1/14 2019/1/14.
 * Describe:
 */
public class JsonParserUtil {

    public static String getStringResult(JsonElement je, String fieldName) {
        String result = null;
        if (TextUtils.isEmpty(fieldName)) {
            return null;
        }
        if (je == null || !je.isJsonObject()) {
            return null;
        }

        try {
            JsonElement je2 = je.getAsJsonObject().get(fieldName);
            if (je2 != null) {
                result =  je2.toString();
            }
        } catch (Exception e) {
        }
        return result;
    }
}
