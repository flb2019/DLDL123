//package com.soso.network.core.config;
//
//
//
//import android.content.Context;
//
//import okhttp3.OkHttpClient;
//
///**
// * Created by sumerlin on 2019/2/26 2019/2/26.
// * Describe:提供一个 OkHttp 配置接口，用于对 OkHttp 进行格外的参数配置
// */
//public interface OkHttpConfiguration {
//
//    void configOkHttp(Context context, OkHttpClient.Builder builder);
//
//    OkHttpConfiguration EMPTY = new OkHttpConfiguration() {
//
//        @Override
//        public void configOkHttp(Context context, OkHttpClient.Builder builder) {
//
//        }
//    };
//}