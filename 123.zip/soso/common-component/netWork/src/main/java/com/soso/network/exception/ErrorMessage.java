package com.soso.network.exception;

/**
 * Created by sumerlin on 2019/1/13 4:49.
 * Describe: 统一定义回调异常类， 回调给上层的异常信息 封装类
 */
public class ErrorMessage {
    private String errorMsg;
    private int errorCode;

    public ErrorMessage() {
    }

    public ErrorMessage(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public ErrorMessage(Integer errorCode, String errorMsg) {
        this.errorMsg = errorMsg;
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }
}
