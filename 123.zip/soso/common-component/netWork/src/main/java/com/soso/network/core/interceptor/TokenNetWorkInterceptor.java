package com.soso.network.core.interceptor;

import com.soso.network.NetWorkTestEvent;
import com.soso.sosolib.art.integration.manager.EventBusManager;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by sumerlin on 2019/2/27 2019/2/27.
 * Describe:
 */
public abstract class TokenNetWorkInterceptor implements Interceptor {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    @Override
    public Response intercept(Chain chain) throws IOException {

//        Request request = chain.request()
//                .newBuilder()
//                .header("access_token", "123456")
//                .header("account_type", "CUSTOMER")
//                .build();
//        Request.Builder builder = chain.request().newBuilder();
//        Request request = builder.build();
        // 【步骤一】try the request
        EventBusManager.getInstance().post(new NetWorkTestEvent(chain.request().url().uri().getPath()));
        Request originalRequest = requestAddHeaderAndBodyParams(chain, getHeaderParamMap(), getBodyParamMap());
        Response originalResponse = chain.proceed(originalRequest);

//        chain.request().newBuilder().cacheControl(CacheControl.FORCE_CACHE)

        /**
         * 【写法一】通过如下方法提前获取到请求完成的数据
         */

//        MediaType mediaType = originalResponse.body().contentType();
//        String bodyString = originalResponse.body().string();//尽量不使用
                String bodyString = "";

/*        *//**
         * 【写法二】通过如下方法提前获取到请求完成的数据
         *//*
        ResponseBody responseBody = originalResponse.body();
        BufferedSource source = responseBody.source();
        source.request(Long.MAX_VALUE); // Buffer the entire body.
        Buffer buffer = source.buffer();
        Charset charset = UTF8;
        MediaType contentType = responseBody.contentType();
        if (contentType != null) {
            charset = contentType.charset(UTF8);
        }
        String bodyString = buffer.clone().readString(charset);*/

        // 【步骤二：】检出是否失效
        boolean needRetry = isNeedRetry(originalRequest, originalResponse, bodyString);
        if (needRetry) {
            //同步请求方式，获取最新的Token
            boolean b = onNeedRetryAfter();
            //使用新的Token，创建新的请求
//            if (b) {
            Request newRequest = requestAddHeaderAndBodyParams(chain, getHeaderParamMap(), getBodyParamMap());
            //【步骤三：】重新请求上次的接口
            EventBusManager.getInstance().post(new NetWorkTestEvent("重新请求："+newRequest.url().uri().getPath()));
            return chain.proceed(newRequest);
//            }
        }
        //【步骤三：】如果token正常返回结果
//        return originalResponse.newBuilder().body(ResponseBody.create(mediaType, bodyString)).build();//
        // otherwise just pass the original response on
        return originalResponse;
    }


    /**
     * 判断是否需要重试
     *
     * @param request
     * @param response
     * @param resultStr
     * @return
     */
    public abstract boolean isNeedRetry(Request request, Response response, String resultStr);

    /**
     * 需要重试时调用， 同步处理锁住。
     *
     * @return true 重新retry url,  false: 失败了， 直接返回， 放弃掉retry  url
     */
    public abstract boolean onNeedRetryAfter();

    public abstract HashMap<String, Object> getHeaderParamMap();

    public abstract HashMap<String, Object> getBodyParamMap();


    private Request requestAddHeaderAndBodyParams(Chain chain, HashMap<String, Object> paramMap, HashMap<String, Object> parameters) {
        Request newRequest = chain.request();
        Request.Builder builder = newRequest.newBuilder();
        if (paramMap.size() != 0) {
            for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
                builder.header(entry.getKey(), entry.getValue() != null ? entry.getValue().toString() : "");
            }
        }
        requestAddBodyParams(newRequest, builder, parameters);
        return builder.build();
    }

    private Request.Builder requestAddBodyParams(Request request, Request.Builder builder, HashMap<String, Object> parameters) {
//        HashMap<String, Object> parameters = getBodyParamMap();
        if (parameters != null && parameters.size() != 0) {
            if (request.method().equals("GET")) {// 为GET方式统一添加请求参数
                HttpUrl.Builder modifiedUrl = request.url().newBuilder()
                        .scheme(request.url().scheme())
                        .host(request.url().host());

                if (parameters.size() != 0) {
                    for (Map.Entry<String, Object> entry : parameters.entrySet()) {
                        modifiedUrl.addQueryParameter(entry.getKey(), entry.getValue() != null ? entry.getValue().toString() : "");
                    }
                }

//                request = request.newBuilder()
//                        .method(request.method(), request.body())
//                        .url(modifiedUrl.build())
//                        .build();
                builder.method(request.method(), request.body())
                        .url(modifiedUrl.build());

            } else if (request.method().equals("POST")) {// 为POST方式统一添加请求参数
                if (request.body() instanceof FormBody) {
                    FormBody.Builder body = new FormBody.Builder();
                    if (parameters.size() != 0) {
                        for (Map.Entry<String, Object> entry : parameters.entrySet()) {
                            body.addEncoded(entry.getKey(), entry.getValue() != null ? entry.getValue().toString() : "");
                        }
                    }
                    body.build();

                    FormBody oldBody = (FormBody) request.body();
                    if (oldBody != null && oldBody.size() != 0) {
                        for (int i = 0; i < oldBody.size(); i++) {
                            body.addEncoded(oldBody.encodedName(i), oldBody.encodedValue(i));
                        }
                    }

//                    request = request.newBuilder()
//                            .post(body.build())
//                            .build();

                    builder.post(body.build());
                }
            }

        }

        return builder;
    }


}
