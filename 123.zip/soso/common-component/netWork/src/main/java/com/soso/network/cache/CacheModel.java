package com.soso.network.cache;

import java.io.Serializable;

/**
 * Created by sumerlin on 2019/4/14 2019/4/14.
 * Describe:
 */
public class CacheModel implements Serializable{
    private String key;
    private String value;
    private int time;
    private long createTime;

    public String getKey() {
        return key;
    }

    public CacheModel setKey(String key) {
        this.key = key;
        return this;
    }

    public String getValue() {
        return value;
    }

    public CacheModel setValue(String value) {
        this.value = value;
        return this;
    }

    public int getTime() {
        return time;
    }

    public CacheModel setTime(int time) {
        this.time = time;
        return this;
    }

    public long getCreateTime() {
        return createTime;
    }

    public CacheModel setCreateTime(long createTime) {
        this.createTime = createTime;
        return this;
    }
}
