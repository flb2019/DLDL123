package com.soso.network.interceptor;

import android.os.Build;

import com.soso.network.tools.StringUtil;
import com.soso.sosolib.BaseApplication;
import com.soso.sosolib.art.di.component.AppComponent;
import com.soso.sosolib.art.tools.ArtUtils;
import com.soso.sosolib.bean.AppToken;
import com.soso.sosolib.todo.AppInfoModule;
import com.soso.sosolib.todo.AppTokenModule;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by sumerlin on 2019/1/13 15:30.
 * Describe: 头部拦截器, 新的网络层框架 和 旧的网络层框架 各自独立使用
 */
public class HeaderInterceptor implements Interceptor {
    private static final String KEY_TOKEN = "Authorization";
    private static final String CLIENT_NAME = "Client-Name";
    private static final String CLIENT_VERSION = "Client-Version";
    private static final String CLIENT_USER_TYPE = "Client-User-Type";
    private static final String DEVICE_NUMBER = "Device-Number";
    private static final String DEVICE_BRAND = "Device-Brand";
    private static final String DEVICE_TYPE = "Device-Type";
    private static final String KEY_JSON = "content-type";
    private static final String KEY_JVALUE = "application/json";
    private AppComponent mAppComponent;

    public HeaderInterceptor() {
        //可以在任何可以拿到 Context 的地方,拿到 AppComponent,从而得到用 Dagger 管理的单例对象
        mAppComponent = ArtUtils.obtainAppComponentFromContext(BaseApplication.getAppContext());
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request originalRequest = chain.request();
        // TODO: 2019/1/15 读取内存即可， 没有通过接口返回 HTTP 的code 抛出错误， 统一处理
//        AccessToken accessToken = ApiConfig.getInstant().getAccessToken();
//        AccessToken accessToken = AccessTokenHelper.getAccessTokenMemory();
        AppInfoModule appInfoModule = mAppComponent.getAppInfoModule();
        AppTokenModule appTokenModule = mAppComponent.getAppTokenModule();
        AppToken accessTokenMemory = appTokenModule.getAppTokenMemory();
        //OkHttp header 不支持中文
        Request authorised = originalRequest.newBuilder()
                .addHeader(KEY_JSON, KEY_JVALUE)
                .addHeader(DEVICE_BRAND, StringUtil.isContainChinese(Build.BRAND) ? "0" : Build.BRAND)
                .addHeader(DEVICE_TYPE, StringUtil.isContainChinese(Build.MODEL) ? "0" : Build.MODEL)
                .addHeader(CLIENT_NAME, "Android")
                .addHeader(CLIENT_VERSION, StringUtil.isContainChinese(appInfoModule.getAppVersion()) ? "0" : appInfoModule.getAppVersion())
                .addHeader(CLIENT_USER_TYPE, StringUtil.isContainChinese(appInfoModule.getClient()) ? "0" : appInfoModule.getClient())
                .addHeader(DEVICE_NUMBER, StringUtil.isContainChinese(appInfoModule.getIMEI()) ? "0" : appInfoModule.getIMEI())
                .addHeader(KEY_TOKEN, accessTokenMemory == null ? "" : accessTokenMemory.getAccessToken())
                .build();
        return chain.proceed(authorised);
    }
}
