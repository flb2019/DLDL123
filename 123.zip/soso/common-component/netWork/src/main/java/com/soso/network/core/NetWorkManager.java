package com.soso.network.core;

import android.app.Application;
import android.support.annotation.Nullable;

import com.google.gson.Gson;
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import com.soso.network.NetRetrofitService;
import com.soso.network.core.config.HttpConfigModule;
import com.soso.sosolib.BaseApplication;
import com.soso.sosolib.art.tools.AppComponentUtils;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by sumerlin on 2019/2/26 2019/2/26.
 * Describe:
 */
public class NetWorkManager {

    // 连接、读取、写入超时时间
    private static final int TIME_OUT = 60;
    // 缓存文件最大值100MB
    private static final int CACHE_MAX_SIZE = 1024 * 1024 * 10 * 100;
    private Retrofit mRetrofit;
    private static volatile NetWorkManager mInstance;

    private static LinkedBlockingQueue<NetWorkHandler> mLinkedBlockingQueue = new LinkedBlockingQueue<NetWorkHandler>();
    private OkHttpClient mHttpClient;

    public static void put(NetWorkHandler handler) {

        try {
            mLinkedBlockingQueue.put(handler);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void remove(NetWorkHandler handler) {
        mLinkedBlockingQueue.remove(handler);
    }

    public static void retryCallAll(){
        Iterator<NetWorkHandler> iterator = mLinkedBlockingQueue.iterator();
        while (iterator.hasNext()){
            NetWorkHandler next = iterator.next();
            next.doExecute();
        }

    }


    private NetWorkManager(Application application, HttpConfigModule configModule) {
        initNetWorkManager(application, configModule);
    }

    public static void init(Application application, HttpConfigModule configModule) {
        if (mInstance == null) {
            synchronized (NetWorkManager.class) {
                if (mInstance == null) {
                    mInstance = new NetWorkManager(application, configModule);
                }
            }
        }
    }

    public static NetWorkManager getInstance() {
        return mInstance;
    }

    private void initNetWorkManager(Application application, HttpConfigModule configModule) {
        OkHttpClient.Builder client = new OkHttpClient.Builder();
        mHttpClient = createHttpClient(application, client, configModule);
        Retrofit.Builder builder = new Retrofit.Builder();
        mRetrofit = createRetrofit(application, builder, mHttpClient, new Gson(), configModule);
    }

    public OkHttpClient getHttpClient(){
        return this.mHttpClient;
    }

    public Retrofit getRetrofit() {
        return mRetrofit;
    }

    /**
     * 创建一个 CommonRetrofitService 服务实例
     */
    public NetRetrofitService getRetrofitService() {
        NetRetrofitService service = getRetrofit().create(NetRetrofitService.class);
        return service;
    }

    private OkHttpClient createHttpClient(@Nullable Application application, @Nullable OkHttpClient.Builder okHttpBuilder, HttpConfigModule configModule) {
        // 缓存目录
        File file0 = AppComponentUtils.getAppComponent().cacheFile();
        File file = new File(file0, "a_soso_cache");
        File okhttpcache = new File(BaseApplication.getInstance().getExternalCacheDir(), "okhttpcache2");
        OkHttpClient.Builder builder = okHttpBuilder
                .connectTimeout(TIME_OUT, TimeUnit.SECONDS)
                .readTimeout(TIME_OUT, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)// 设置出现错误进行重新连接
                //设置设置cache（）， 下面的才有效， 缓存策略这 通过 设置request  和  response 的cacheControl来设置缓存时间
//                .addInterceptor(new CacheInterceptor(new InternalCache() {
//                    @Override
//                    public Response get(Request request) throws IOException {
//                        return null;
//                    }
//
//                    @Override
//                    public CacheRequest put(Response response) throws IOException {
//                        return null;
//                    }
//
//                    @Override
//                    public void remove(Request request) throws IOException {
//
//                    }
//
//                    @Override
//                    public void update(Response cached, Response network) {
//
//                    }
//
//                    @Override
//                    public void trackConditionalCacheHit() {
//
//                    }
//
//                    @Override
//                    public void trackResponse(CacheStrategy cacheStrategy) {
//
//                    }
//                }))
                .addInterceptor(configModule.getHeadersWorkInterceptor() );
//                .addInterceptor(new OfflineCacheInterceptor())
//                .addInterceptor(new PostCacheInterceptor())
//                .addInterceptor(configModule.getTokenNetWorkInterceptor())//;// 网络拦截器
//                .addNetworkInterceptor(new OnlineCacheInterceptor())
//                .addNetworkInterceptor(new NetCacheInterceptor())
                //                .cache(new Cache(application.getCacheDir(), CACHE_MAX_SIZE))// 设置缓存路径和大小
//                .cache(new Cache(CacheTools.getInstance().getCacheDir(), CacheTools.getInstance().getMaxSize()));// 设置缓存路径和大小;



        if (configModule.getNetworkInterceptorHandler() != null) {
            okHttpBuilder.addNetworkInterceptor(new Interceptor() {
                @Override
                public Response intercept(Chain chain) throws IOException {
                    return chain.proceed(configModule.getNetworkInterceptorHandler().onHttpRequest(chain, chain.request()));
                }
            });
        }

        if (configModule.getCookie() != null) {
            builder.cookieJar(configModule.getCookie());// Cookie
        }

        if (configModule.getInterceptors() != null && configModule.getInterceptors().size() > 0) {// Interceptors，只在Response被调用一次
            for (Interceptor item : configModule.getInterceptors()) {
                builder.addInterceptor(item);
            }
        }

        if (configModule.getOkHttpConfiguration() != null) {
            configModule.getOkHttpConfiguration().configOkHttp(application, builder);
        }

        return builder.build();
    }

    private Retrofit createRetrofit(Application application, Retrofit.Builder builder, OkHttpClient client,
                                    Gson gson, HttpConfigModule configModule) {
        builder
                .baseUrl(configModule.getHttpUrl())// 域名
                .client(client);// 设置OkHttpClient

        builder
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())// 支持 RxJava
                .addConverterFactory(GsonConverterFactory.create(gson));// 支持 Gson

        if (configModule.getRetrofitConfiguration() != null) {
            configModule.getRetrofitConfiguration().configRetrofit(application, builder);
        }

        return builder.build();
    }
}
