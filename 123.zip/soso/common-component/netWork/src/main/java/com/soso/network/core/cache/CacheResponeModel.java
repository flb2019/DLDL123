package com.soso.network.core.cache;

/**
 * Created by sumerlin on 2019/4/14 2019/4/14.
 * Describe:
 */
public class CacheResponeModel {
    public String key;
    public String value;
    public int time;

}
