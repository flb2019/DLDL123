package com.soso.network.exception;


import com.soso.network.config.ApiCodeEnum;

/**
 * Created by sumerlin on 2019/1/11 16:48.
 * Describe: 网络请求 业务上的 异常
 */
public class ApiCodeException extends Exception {

    private int errorCode;
    private String errorMsg;
    private ApiCodeEnum errorEnum;

    public ApiCodeException() {
    }

    public ApiCodeException(int errorCode, String errorMessage, ApiCodeEnum errorEnum) {
        this.errorCode = errorCode;
        this.errorMsg = errorMessage;
        this.errorEnum = errorEnum;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public ApiCodeEnum getErrorEnum() {
        return errorEnum;
    }

    public void setErrorEnum(ApiCodeEnum errorEnum) {
        this.errorEnum = errorEnum;
    }
}
