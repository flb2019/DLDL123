package com.soso.network.config;

/**
 * Created by Vurtne on 1-Sept-17.
 */
//   状态码       描述                     名称

/**
 * 200         成功                     Success
 * 400         请求参数错误              Request_Parameter_Error
 * 403         无权限                   No_Permission
 * 404         未找到(无此种请求）        No_Request
 * 407         服务请求参数错误          Error_Server_Parameter
 * 408         请求超时                 Request_TimeOut
 * 409         重复请求                 Request_Repeated
 * 500         服务器未知错误            Server_Unknown
 * 511         数据库服务器未知错误       DateBase_Unknown
 * 512         服务帐号不存在            Server_Access_Exist
 * 513         服务器解码错误            Error_Decode
 * 700         未知错误                 Error_Unknown
 * 701         方法参数错误              Error_Parameter
 * 702         数据未找到                No_Find_Data
 * 703         重复的事件                Request_Repeat
 * 704         溢出(过大)               Capacity_Out
 * 705         溢出(过小)               Capacity_In
 * 706         不为空                   No_Null
 * 707         access_token失效         Failure_Token
 * 708         user_access_token用户失效 	        Failure_Access_Token
 * 709         账户被冻结                Frozen_Account
 * 710         资金被冻结                Frozen_Funds
 * 711         功能受限                  Limited_Functionality
 * 200013      app版本需要强制跟新        Update_Force
 * 200016      app版本提示跟新           Update
 */

public enum ApiCodeEnum {

    Success {
        @Override
        public int getId() {
            return 200;
        }

        @Override
        public String getName() {
            return "成功";
        }
    },
    Request_Parameter_Error {
        @Override
        public int getId() {
            return 400;
        }

        @Override
        public String getName() {
            return "请求参数错误";
        }
    },
    No_Authorized {
        @Override
        public int getId() {
            return 401;
        }

        @Override
        public String getName() {
            return "Unauthorized";
        }
    },
    No_Permission {
        @Override
        public int getId() {
            return 403;
        }

        @Override
        public String getName() {
            return "无权限";
        }
    },
    No_Request {
        @Override
        public int getId() {
            return 404;
        }

        @Override
        public String getName() {
            return "未找到(无此种请求)";
        }
    },
    Error_Server_Parameter {
        @Override
        public int getId() {
            return 407;
        }

        @Override
        public String getName() {
            return "服务请求参数错误";
        }
    },
    Request_TimeOut {
        @Override
        public int getId() {
            return 408;
        }

        @Override
        public String getName() {
            return "请求超时";
        }
    },
    Request_Repeated {
        @Override
        public int getId() {
            return 409;
        }

        @Override
        public String getName() {
            return "重复请求";
        }
    },
    Server_Unknown {
        @Override
        public int getId() {
            return 500;
        }

        @Override
        public String getName() {
            return "服务器未知错误";
        }
    },
    DateBase_Unknown {
        @Override
        public int getId() {
            return 511;
        }

        @Override
        public String getName() {
            return "数据库服务器未知错误";
        }
    },
    Server_Access_Exist {
        @Override
        public int getId() {
            return 512;
        }

        @Override
        public String getName() {
            return "服务账号不存在";
        }
    },
    Error_Decode {
        @Override
        public int getId() {
            return 513;
        }

        @Override
        public String getName() {
            return "服务器解码错误";
        }
    },
    Error_Unknown {
        @Override
        public int getId() {
            return 700;
        }

        @Override
        public String getName() {
            return "未知错误";
        }
    },
    Error_Parameter {
        @Override
        public int getId() {
            return 701;
        }

        @Override
        public String getName() {
            return "方法参数错误";
        }
    },
    Request_Repeat {
        @Override
        public int getId() {
            return 703;
        }

        @Override
        public String getName() {
            return "重复的事件";
        }
    },
    No_Find_Data {
        @Override
        public int getId() {
            return 702;
        }

        @Override
        public String getName() {
            return "数据未找到";
        }
    },
    Capacity_Out {
        @Override
        public int getId() {
            return 704;
        }

        @Override
        public String getName() {
            return "溢出(过大)";
        }
    },
    Capacity_In {
        @Override
        public int getId() {
            return 705;
        }

        @Override
        public String getName() {
            return "溢出(过小)";
        }
    },
    No_Null {
        @Override
        public int getId() {
            return 706;
        }

        @Override
        public String getName() {
            return "不为空";
        }
    },
    Failure_Token {
        @Override
        public int getId() {
            return 707;
        }

        @Override
        public String getName() {
            return "access_token失效";
        }
    },
    Failure_User_Access_Token {
        @Override
        public int getId() {
            return 708;
        }

        @Override
        public String getName() {
            return "user_access_token 用户失效 \t";
        }
    },
    Frozen_Account {
        @Override
        public int getId() {
            return 709;
        }

        @Override
        public String getName() {
            return "账户被冻结";
        }
    },
    Frozen_Funds {
        @Override
        public int getId() {
            return 710;
        }

        @Override
        public String getName() {
            return "资金被冻结";
        }
    },
    Limited_Functionality {
        @Override
        public int getId() {
            return 711;
        }

        @Override
        public String getName() {
            return "功能受限";
        }
    },
    Update_Force {
        @Override
        public int getId() {
            return 200013;
        }

        @Override
        public String getName() {
            return "app版本需要强制跟新";
        }
    },
    Update {
        @Override
        public int getId() {
            return 200016;
        }

        @Override
        public String getName() {
            return "app版本提示更新";
        }
    },

    NOTLOGINOLD {
        @Override
        public int getId() {
            return 210003;
        }

        @Override
        public String getName() {
            return "用户未登录,请重新登录";
        }
    }, NOTLOGIN {
        @Override
        public int getId() {
            return 708;
        }

        @Override
        public String getName() {
            return "用户未登录,请重新登录";
        }
    }, TimeOutException {
        @Override
        public int getId() {
            return 1;
        }

        @Override
        public String getName() {
            return "请求超时";
        }
    };

    public abstract int getId();

    public abstract String getName();

    public static String getErrorName(int id) {
        for (NetEnum netEnum : NetEnum.values()) {
            if (id == netEnum.getId()) {
                return netEnum.getName();
            }
        }
        return TimeOutException.getName();
    }


    public static ApiCodeEnum getApiCodeEnum  (int id) {
        for (ApiCodeEnum apiCodeEnum : ApiCodeEnum.values()) {
            if (id == apiCodeEnum.getId()) {
                return apiCodeEnum;
            }
        }
        return TimeOutException;

    }

    // TODO: 2019/1/17 sumer，新增
    /*=================start=========================================================================*/

    /**
     * 服务端过来 异常就显示 什么
     * @param id
     * @return 服务端异常 信息
     */
    public static String getApiErrorName(int id) {
        for (ApiCodeEnum apiEnum : ApiCodeEnum.values()) {
            if (id == apiEnum.getId()) {
                return apiEnum.getName();
            }
        }
        return TimeOutException.getName();
    }

}
