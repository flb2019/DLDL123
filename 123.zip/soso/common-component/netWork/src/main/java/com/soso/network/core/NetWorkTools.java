package com.soso.network.core;

import com.soso.network.tools.GsonConvertUtils;

import org.json.JSONObject;

/**
 * Created by sumerlin on 2019/2/28 2019/2/28.
 * Describe:
 */
public class NetWorkTools {
    /**
     * 设置请求参数 转换
     */
    public static Object toJsonParser(Object objectBean) {
        Object objectJson = null;
        if (objectBean != null) {
            try {
                objectJson = objectBean;
                if (objectJson instanceof String) {
                    objectJson = GsonConvertUtils.getJsonParser().parse((String) objectBean);
                } else if (objectJson instanceof JSONObject) {
                    objectJson = GsonConvertUtils.getJsonParser().parse(objectJson.toString());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return objectJson;
    }
}
