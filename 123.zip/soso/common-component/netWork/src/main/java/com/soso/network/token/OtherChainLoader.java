package com.soso.network.token;

import com.soso.sosolib.art.tools.AppComponentUtils;
import com.soso.sosolib.bean.AppToken;
import com.soso.sosolib.todo.AppLoginModule;
import com.soso.sosolib.todo.AppTokenModule;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.ObservableSource;
import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.PublishSubject;


/**
 * Created by sumerlin on 2019/1/11 10:25.
 * Describe: 其他异常之后重新插件
 */
public class OtherChainLoader {

    private static final String TAG = OtherChainLoader.class.getSimpleName();

    private AtomicBoolean mRefreshing = new AtomicBoolean(false); //进行线程同步
    private PublishSubject<Object> mPublishSubject;
    private Observable<AppToken> mTokenObservable; //整个流程Observable
    private Observer<AppToken> observer;

    private CompositeDisposable mCompositeDisposable = new CompositeDisposable();
    private final AppTokenModule mAppTokenModule;
    private final AppLoginModule mAppLoginModule;

    private OtherChainLoader() {
        mAppTokenModule = AppComponentUtils.getAppComponent().getAppTokenModule();
        mAppLoginModule = AppComponentUtils.getAppComponent().getAppLoginModule();
    }

    public void dispose() {
        if (mCompositeDisposable != null) mCompositeDisposable.dispose();

    }


    /*=============================================================================================*/

    public static OtherChainLoader getInstance() {
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static final OtherChainLoader INSTANCE = new OtherChainLoader();
    }

    /**
     * 执行token 或者重试 链条
     *
     * @return
     */
    public Observable<Object> getNetTokenLocked() {
        //并发，锁住请求  1. 比较AtomicBoolean和expect的值，如果一致，执行方法内的语句。 mRefreshing 初始值 跟boolean expect 比较， 相同的话就把mRefreshing值改为 boolean update
        if (mRefreshing.compareAndSet(false, true)) {
//            LogUtils.d("没有请求，发起一次新的Token请求");
/*
            if (ApiConfig.getInstant().isTokenInValid()) {
            }else{
                startTokenRequest();
            }
*/
            startTokenRequest();
        } else {
//            LogUtils.d("已经有请求，直接返回等待");
        }
        return mPublishSubject;
    }

    private void startTokenRequest() {
        createAndPublishSubject();
    }

    /**
     * 创建 和 开始订阅
     */
    private void createAndPublishSubject() {
        mPublishSubject = PublishSubject.create();
        mTokenObservable = Observable.create(new ObservableOnSubscribe<AppToken>() {

            //            private Observable<Response<JsonElement>> mTokenObservable;
            private Observable<AppToken> mTokenRequestObservable;//请求的Observable

            @Override
            public void subscribe(final ObservableEmitter<AppToken> observableEmitter) throws Exception {
                //定义,//直接跳转登录， 发射一个参数为空的 mTokenRequestObservable ,  需要登录的Observable
                HashMap<String, String> signMap = new HashMap<>();
                //执行请求
//                TokenRequestDto requestToken = AccessTokenHelper.getUnauthorizedTokenGrantType();
//                if (requestToken != null && (TextUtils.equals(requestToken.getGrantType(), AccessTokenModule.LOGIN_TYPE_CLIENT)
//                        || TextUtils.equals(requestToken.getGrantType(), AccessTokenModule.LOGIN_TYPE_REFRESH))) {
                if(mAppLoginModule.isNeedReLoginCall()){
                    //token异常， 刷新处理
//                    AccessToken accessToken = AccessTokenHelper.getAccessToken();
                    AppToken appToken = mAppTokenModule.getAppToken();
                    mTokenRequestObservable = Observable.just(appToken);
                    observer = new Observer<AppToken>() {
                        @Override
                        public void onSubscribe(@NonNull Disposable d) {
                            //mCompositeDisposable.add(d);

                        }

                        @Override
                        public void onNext(@NonNull AppToken accessToken) {
                            //接受到新的token, 内存 和 sp保存一份
                            //解析 和 保存
                            // TODO: 2019/1/12 为空发出异常出来
                            //先解锁， 再调起， 登录组件。 否则会所没解开 会导致， 下次不会走重试检查流程
                                mRefreshing.compareAndSet(true, false);
                                observableEmitter.onNext(accessToken);

                            mAppLoginModule.reLoginCall(new AppLoginModule.OnReLoginListen() {
                                @Override
                                public void onReLoginSuccess() {
                                    mRefreshing.compareAndSet(true, false);
                                    observableEmitter.onError(new Throwable("data == null or data is no cotain accessToken or userinfo is null"));
                                }

                                @Override
                                public void onReLoginError(String errorMsg) {
                                    mRefreshing.compareAndSet(true, false);
                                    observableEmitter.onError(new Throwable("data == null or data is no cotain accessToken or userinfo is null"));
                                }
                            });

                        }

                        @Override
                        public void onError(@NonNull Throwable e) {
                            //接受到新的token 异常
                            //mRefreshing.set(false);
                            mRefreshing.compareAndSet(true, false);
                            observableEmitter.onError(new Throwable("data == null or data is no cotain accessToken or userinfo is null"));
                        }

                        @Override
                        public void onComplete() {
                            dispose();
                        }
                    };
                    mTokenRequestObservable = mTokenRequestObservable.retryWhen(new RetryWithDelay(1, 2000));
                    mTokenRequestObservable.subscribe(observer);
                } else {
                    //直接跳转登录， 发射一个参数为空的 mTokenRequestObservable ,  需要登录的Observable

                }
            }
        }).doOnNext(new Consumer<AppToken>() {
            @Override
            public void accept(AppToken token) throws Exception {
                dispose();
                //mRefreshing.set(false);
                mRefreshing.compareAndSet(true, false);
            }

        }).doOnError(new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                //mRefreshing.set(false);
                mRefreshing.compareAndSet(true, false);
                dispose();
            }
        }).subscribeOn(Schedulers.io());
        mTokenObservable.subscribeOn(Schedulers.io()).serialize();
        mTokenObservable.subscribe(mPublishSubject);

    }


    private static class RetryWithDelay implements Function<Observable<Throwable>, ObservableSource<?>> {

        private final int maxRetries;
        private final int retryDelayMillis;
        private int retryCount;

        public RetryWithDelay(int maxRetries, int retryDelayMillis) {
            this.maxRetries = maxRetries;
            this.retryDelayMillis = retryDelayMillis;
        }

        @Override
        public ObservableSource<?> apply(Observable<Throwable> throwableObservable) throws Exception {
            return throwableObservable
                    .flatMap(new Function<Throwable, ObservableSource<?>>() {
                        @Override
                        public ObservableSource<?> apply(Throwable throwable) throws Exception {
                            if (++retryCount <= maxRetries) {
                                // When this Observable calls onNext, the original Observable will be retried (i.e. re-subscribed).
//                                printLog(tvLogs, "", "get error, it will try after " + retryDelayMillis
//                                        + " millisecond, retry count " + retryCount);
                                return Observable.timer(retryDelayMillis,
                                        TimeUnit.MILLISECONDS);
                            }
                            // Max retries hit. Just pass the error along.
                            return Observable.error(throwable);
                        }
                    });
        }
    }

}
