package com.soso.network.exception;


import com.soso.network.config.NetEnum;

/**
 * Created by sumerlin on 2019/1/11 16:58.
 * Describe:网络请求 服务打断链接异常
 */
public class ErrorException extends  Exception{

    private int errorCode;
    private String errorMsg;
    private NetEnum errorEnum;

    public ErrorException() {
    }

    public ErrorException(int errorCode, String errorMessage, NetEnum errorEnum) {
        this.errorCode = errorCode;
        this.errorMsg = errorMessage;
        this.errorEnum = errorEnum;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public NetEnum getErrorEnum() {
        return errorEnum;
    }

    public void setErrorEnum(NetEnum errorEnum) {
        this.errorEnum = errorEnum;
    }
}
