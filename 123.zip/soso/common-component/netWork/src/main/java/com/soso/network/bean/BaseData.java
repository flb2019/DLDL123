package com.soso.network.bean;

import com.soso.sosolib.bean.NonProguard;

/**
 * Created by sumerlin on 2019/1/12 23:59.
 * Describe:
 */
public class BaseData implements NonProguard {
    private Integer statusCode;
    private String statusMgs;
    private String error;

    public BaseData() {
    }

    public BaseData(Integer statusCode, String statusMgs) {
        this.statusCode = statusCode;
        this.statusMgs = statusMgs;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMgs() {
        return statusMgs;
    }

    public void setStatusMgs(String statusMgs) {
        this.statusMgs = statusMgs;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

//    public BaseData newBaseData() {
//        BaseData baseData = new BaseData();
//        baseData.statusCode = statusCode;
//        baseData.statusMgs = statusMgs;
//        return baseData;
//    }
}
