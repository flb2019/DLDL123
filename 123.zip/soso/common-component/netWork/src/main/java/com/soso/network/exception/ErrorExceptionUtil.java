package com.soso.network.exception;

import android.net.ParseException;

import com.google.gson.JsonParseException;
import com.google.gson.JsonSerializer;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.MalformedJsonException;
import com.soso.network.config.ApiCodeEnum;
import com.soso.network.config.NetEnum;
import com.soso.sosolib.utils.NetworkUtils;

import org.apache.http.conn.ConnectTimeoutException;
import org.json.JSONException;

import java.io.NotSerializableException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import retrofit2.HttpException;

/**
 * Created by sumerlin on 2017/9/12.
 * 请求网络异常, 引擎解析器
 */

public class ErrorExceptionUtil {

    /**
     * 抛出异常
     * @param e
     * @throws Exception
     */
    public static void throwException(/*@NonNull*/ Exception e) throws Exception {
        // values here derived from https://github.com/ReactiveX/RxJava/issues/748#issuecomment-32471495
//        if (t instanceof VirtualMachineError) {
//            throw (VirtualMachineError) t;
//        } else if (t instanceof ThreadDeath) {
//            throw (ThreadDeath) t;
//        } else if (t instanceof LinkageError) {
//            throw (LinkageError) t;
//        }
        throw e;
    }

    /**
     * 解析 异常
     *
     * @param e
     * @return
     */
    public static ApiRequestException parserException(Throwable e) {
        ApiRequestException ex;

        if (e instanceof HttpException) {
            /*网络异常*/
            ex = new ApiRequestException(NetEnum.NetException.getId(), NetEnum.NetException.getMessage());
        } else if (e instanceof SocketTimeoutException) {
            ex = new ApiRequestException(NetEnum.TimeOutException.getId(), NetEnum.TimeOutException.getMessage());
        } else if (e instanceof JSONException || e instanceof java.text.ParseException || e instanceof MalformedJsonException) {
            ex = new ApiRequestException(NetEnum.ParseException.getId(), NetEnum.ParseException.getMessage());
        } else if (e instanceof UnknownHostException) {
            if (!NetworkUtils.isConnected()) {
                ex = new ApiRequestException(NetEnum.DisconnectException.getId(), NetEnum.DisconnectException.getMessage());
            } else {
                ex = new ApiRequestException(NetEnum.UnKnowHostException.getId(), NetEnum.UnKnowHostException.getMessage());
            }
        } else if (e instanceof ConnectException) {
            ex = new ApiRequestException(NetEnum.CONNECTException.getId(), NetEnum.CONNECTException.getMessage());

        } else if (e instanceof ApiRequestException) {
            ex = (ApiRequestException) e;
        } else {
            ex = new ApiRequestException(NetEnum.ApiException.getId(), NetEnum.ApiException.getMessage());
        }
        return ex;
    }


    @Deprecated
    public static ApiRequestException handleException(Throwable e) {

        ApiRequestException ex;
        if (e == null) {
            ex = new ApiRequestException(ApiCodeEnum.Success.getId(), "");
            return ex;
        }
        if (e instanceof ApiCodeException) {
            ApiCodeException bizException = (ApiCodeException) e;
            ex = new ApiRequestException(bizException.getErrorCode(), bizException.getErrorMsg());
            return ex;
        } else if (e instanceof JsonParseException
                || e instanceof JSONException
                || e instanceof JsonSyntaxException
                || e instanceof JsonSerializer
                || e instanceof NotSerializableException
                || e instanceof ParseException
                || e instanceof MalformedJsonException) {
            ex = new ApiRequestException(NetEnum.ParseException.getId(), NetEnum.ParseException.getMessage());
            return ex;
        } else if (e instanceof ClassCastException) {
            ex = new ApiRequestException(NetEnum.ApiException.getId(), "类型转换错误");
            return ex;
        } else if (e instanceof ConnectException) {
            ex = new ApiRequestException(NetEnum.CONNECTException.getId(), NetEnum.CONNECTException.getMessage());
            return ex;
        } else if (e instanceof javax.net.ssl.SSLHandshakeException) {
            ex = new ApiRequestException(NetEnum.ApiException.getId(), "证书验证失败");
            return ex;
        } else if (e instanceof ConnectTimeoutException) {
            ex = new ApiRequestException(NetEnum.TimeOutException.getId(), NetEnum.TimeOutException.getMessage());
            return ex;
        } else if (e instanceof SocketTimeoutException) {
            ex = new ApiRequestException(NetEnum.TimeOutException.getId(), NetEnum.TimeOutException.getMessage());
            return ex;
        } else if (e instanceof UnknownHostException) {
            ex = new ApiRequestException(NetEnum.UnKnowHostException.getId(), NetEnum.UnKnowHostException.getMessage());
            return ex;
        } else if (e instanceof NullPointerException) {
            ex = new ApiRequestException(NetEnum.ApiException.getId(), "NullPointerException");
            return ex;
        } else if (e instanceof HttpException) {
            ex = new ApiRequestException(NetEnum.NetException.getId(), NetEnum.NetException.getMessage());
            return ex;
        } else {
            ex = new ApiRequestException(NetEnum.ApiException.getId(), e.getMessage());
            return ex;
        }
    }
}
