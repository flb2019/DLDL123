package com.soso.network.core.interceptor;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by sumerlin on 2019/4/13 2019/4/13.
 * Describe:
 */
public abstract class HeadersInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        Headers headers = request.headers();
        Request.Builder builder = request.newBuilder();
        if (headers != null) {
            for (int i = 0; i < headers.size(); i++) {
                builder.header(headers.name(i), headers.value(i));
            }
        }
        HashMap<String, Object> paramMap = getHeaderParamMap();
        if (paramMap != null && paramMap.size() != 0) {
            for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
                builder.header(entry.getKey(), entry.getValue() != null ? entry.getValue().toString() : "");
//                request.header((entry.getKey(), entry.getValue() != null ? entry.getValue().toString() : "");
            }
        }
        Request newRequest = builder.build();
        return chain.proceed(newRequest);
    }


    public abstract HashMap<String, Object> getHeaderParamMap();

    public abstract HashMap<String, Object> getBodyParamMap();
}
