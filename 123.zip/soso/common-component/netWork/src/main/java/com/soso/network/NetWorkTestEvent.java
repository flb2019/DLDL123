package com.soso.network;

/**
 * Created by sumerlin on 2019/3/2 2019/3/2.
 * Describe:
 */
public class NetWorkTestEvent {
    public String message;

    public NetWorkTestEvent(String message) {
        this.message = message;
    }
}
