package com.soso.network.token;

import com.soso.sosolib.art.tools.AppComponentUtils;
import com.soso.sosolib.bean.AppToken;
import com.soso.sosolib.todo.AppTokenModule;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.ObservableSource;
import io.reactivex.Observer;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.PublishSubject;


/**
 * Created by sumerlin on 2019/1/11 10:25.
 * Describe:sToken过期刷新Token之后重新请求
 */
public class EmptyChainLoader {

    private static final String TAG = EmptyChainLoader.class.getSimpleName();

    private AtomicBoolean mRefreshing = new AtomicBoolean(false); //进行线程同步
    private PublishSubject<AppToken> mPublishSubject;
    private Observable<AppToken> mTokenObservable; //整个流程Observable
    private Observer<String> observer;

    private CompositeDisposable mCompositeDisposable = new CompositeDisposable();
    private final AppTokenModule mAppTokenModule;

    private EmptyChainLoader() {
        mAppTokenModule = AppComponentUtils.getAppComponent().getAppTokenModule();
    }

    public void dispose() {
        if (mCompositeDisposable != null) mCompositeDisposable.dispose();

    }


    /*=============================================================================================*/

    public static EmptyChainLoader getInstance() {
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static final EmptyChainLoader INSTANCE = new EmptyChainLoader();
    }

    /**
     * 执行token 或者重试 链条
     * @return
     */
    public Observable<AppToken> getNetTokenLocked() {
        //并发，锁住请求  1. 比较AtomicBoolean和expect的值，如果一致，执行方法内的语句。 mRefreshing 初始值 跟boolean expect 比较， 相同的话就把mRefreshing值改为 boolean update
        if (mRefreshing.compareAndSet(false, true)) {
//            LogUtils.d("没有请求，发起一次新的Token请求");
            if (mAppTokenModule.getAppToken().isTokenAdvanceExpireTime()) {
//                RxBus.get().post(TokenEvent.onCreate());
//                return;
            }else{
                startTokenRequest();
            }

        } else {
//            LogUtils.d("已经有请求，直接返回等待");
        }
        return mPublishSubject;
    }

    private void startTokenRequest() {
        createAndPublishSubject();
    }

    /**
     * 创建 和 开始订阅
     */
    private void createAndPublishSubject() {
        mPublishSubject = PublishSubject.create();
        mTokenObservable = Observable.create(new ObservableOnSubscribe<AppToken>() {
            private Observable<String> mTokenRequestObservable;//请求的Observable

            @Override
            public void subscribe(final ObservableEmitter<AppToken> observableEmitter) throws Exception {
//                LogUtils.d("发送Token");
                //定义
                HashMap<String, String> signMap = new HashMap<>();
                mTokenRequestObservable  =   Observable.just("测试")
                        .flatMap(new Function<String, ObservableSource<String>>() {
                            @Override
                            public ObservableSource<String> apply(String stringStringHashMap) throws Exception {
                                return null;
                            }
                        });
                observer = new Observer<String>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(String stringStringHashMap) {
                        mRefreshing.compareAndSet(true, false);
                        observableEmitter.onNext(new AppToken());
                    }

                    @Override
                    public void onError(Throwable e) {
                        mRefreshing.compareAndSet(true, false);
                        observableEmitter.onError(new Throwable("data == null or data is no cotain accessToken or userinfo is null"));
                    }

                    @Override
                    public void onComplete() {
                        mRefreshing.compareAndSet(true, false);

                    }
                };
//                mTokenRequestObservable = mTokenRequestObservable.retryWhen(new RetryWithDelay(1, 2000));
                mTokenRequestObservable.subscribe(observer);

            }
        }).doOnNext(new Consumer<AppToken>() {
            @Override
            public void accept(AppToken token) throws Exception {
                dispose();
//                mRefreshing.set(false);
                mRefreshing.compareAndSet(true, false);
            }

        }).doOnError(new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
//                mRefreshing.set(false);
                mRefreshing.compareAndSet(true, false);
                dispose();
            }
        }).subscribeOn(Schedulers.io());
        mTokenObservable.subscribeOn(Schedulers.io()).serialize();
        mTokenObservable.subscribe(mPublishSubject);

    }


    public static class RetryWithDelay implements Function<Observable<Throwable>, ObservableSource<?>> {

        private final int maxRetries;
        private final int retryDelayMillis;
        private int retryCount;

        public RetryWithDelay(int maxRetries, int retryDelayMillis) {
            this.maxRetries = maxRetries;
            this.retryDelayMillis = retryDelayMillis;
        }

        @Override
        public ObservableSource<?> apply(Observable<Throwable> throwableObservable) throws Exception {
            return throwableObservable
                    .flatMap(new Function<Throwable, ObservableSource<?>>() {
                        @Override
                        public ObservableSource<?> apply(Throwable throwable) throws Exception {
                            if (++retryCount <= maxRetries) {
                                // When this Observable calls onNext, the original Observable will be retried (i.e. re-subscribed).
//                                printLog(tvLogs, "", "get error, it will try after " + retryDelayMillis
//                                        + " millisecond, retry count " + retryCount);
                                return Observable.timer(retryDelayMillis,
                                        TimeUnit.MILLISECONDS);
                            }
                            // Max retries hit. Just pass the error along.
                            return Observable.error(throwable);
                        }
                    });
        }

//
//        @Override
//        public Observable<?> call(Observable<? extends Throwable> attempts) {
//            return attempts
//                    .flatMap(new Function<Throwable, Observable<?>>() {
//                        @Override
//                        public Observable<?> call(Throwable throwable) {
//                            if (++retryCount <= maxRetries) {
//                                // When this Observable calls onNext, the original Observable will be retried (i.e. re-subscribed).
////                                printLog(tvLogs, "", "get error, it will try after " + retryDelayMillis
////                                        + " millisecond, retry count " + retryCount);
//                                return Observable.timer(retryDelayMillis,
//                                        TimeUnit.MILLISECONDS);
//                            }
//                            // Max retries hit. Just pass the error along.
//                            return Observable.error(throwable);
//                        }
//                    });
//        }
    }

}
