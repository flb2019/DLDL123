package com.soso.network.interceptor;


import com.soso.network.tools.LogUtil;

/**
 * Created by sumerlin on 2019/1/13
 * description:
 */
public class LoggerImpl implements LoggingInterceptor.Logger {

    public static String INTERCEPTOR_TAG_STR = "OkHttp";

    public LoggerImpl() {
    }

    public LoggerImpl(String tag) {
        INTERCEPTOR_TAG_STR = tag;
    }

    @Override
    public void log(String message, @LogUtil.LogType int type) {
        LogUtil.printLog(false, type, INTERCEPTOR_TAG_STR, message);
    }
}
