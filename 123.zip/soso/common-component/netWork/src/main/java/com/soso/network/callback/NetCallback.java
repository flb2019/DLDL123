package com.soso.network.callback;

import android.util.ArrayMap;

import com.soso.network.bean.NetResultData;
import com.soso.network.exception.ErrorMessage;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import io.reactivex.disposables.Disposable;

/**
 * Created by sumerlin on 2019/1/9 11:49.
 * Describe: 网络层回调给 上层的接口
 */
public abstract class NetCallback<T> {

    public NetCallback() {
        init();
    }

    private void init() {
        Type type = getClass().getGenericSuperclass();
        Type[] types = ((ParameterizedType) type).getActualTypeArguments();
    }


    /**
     * 执行网络前调用， 用于数据请求， 修改 or 添加额外数据的传递
     *
     * @param paramsMap
     */
    public ArrayMap<String, Object> onBefore(ArrayMap<String, Object> paramsMap) {
        return null;

    }

    /**
     * 执行网络前调用， 用于做做一些ui 操作， 在main ui 线程中执行
     *
     * @param disposable
     */
    public void onBefore(Disposable disposable) {

    }


    /**
     * 开始请求网络是， 用于把 请求添加到 组件容器中进行统一管理， 避免 内存泄漏
     *
     * @param disposable
     */
    abstract  public  void onStart(Disposable disposable);

    /**
     * 请求成功， 以及解析数据成功返回 data 里面的数据结构
     *
     * @param netResult
     */
    abstract public void onSuccess(NetResultData<T> netResult);

    /**
     * 请求失败
     *
     * @param error
     */
    abstract public void onError(ErrorMessage error);

    /**
     * 请求结束， 不管是请求成功 还是 请求失败 都会走该方法
     */
    public void onFinish() {
    }
}
