package com.soso.network.bean;


import com.soso.sosolib.bean.NonProguard;

import java.io.Serializable;

/**
 * Created by sumerlin on 2019/1/12 23:59.
 * Describe:
 */
public class NetResultData<T> extends BaseData implements NonProguard, Serializable {
    private T data;

    public NetResultData() {
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "NetData{\n" +//
                "\tcode=" + getStatusCode() + "\n" +//
                "\tmsg='" + getStatusMgs() + "\'\n" +//
                "\tdata=" + data + "\n" +//
                '}';
    }

}
