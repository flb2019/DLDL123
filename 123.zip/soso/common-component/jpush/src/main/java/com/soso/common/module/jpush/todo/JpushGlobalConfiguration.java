package com.soso.common.module.jpush.todo;

import android.app.Application;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;

import com.soso.sosolib.art.base.delegate.AppLifecycles;
import com.soso.sosolib.art.di.module.GlobalConfigModule;
import com.soso.sosolib.art.integration.ConfigModule;

import java.util.List;

import cn.jpush.android.api.JPushInterface;

/**
 * Created by sumerlin on 2019/3/3 2019/3/3.
 * Describe:
 */
public class JpushGlobalConfiguration implements ConfigModule {

    @Override
    public void applyOptions(Context context, GlobalConfigModule.Builder builder) {

    }

    @Override
    public void injectAppLifecycle(Context context, List<AppLifecycles> lifecycles) {
        lifecycles.add(new AppLifecycles() {
            @Override
            public void attachBaseContext(@NonNull Context base) {

            }

            @Override
            public void onCreate(@NonNull Application application) {
                //极光推送
                JPushInterface.setDebugMode(true); 	// 设置开启日志,发布时请关闭日志
                JPushInterface.init(application);     		// 初始化 JPush

            }

            @Override
            public void onTerminate(@NonNull Application application) {

            }
        });

    }

    @Override
    public void injectActivityLifecycle(Context context, List<Application.ActivityLifecycleCallbacks> lifecycles) {

    }

    @Override
    public void injectFragmentLifecycle(Context context, List<FragmentManager.FragmentLifecycleCallbacks> lifecycles) {


    }
}
