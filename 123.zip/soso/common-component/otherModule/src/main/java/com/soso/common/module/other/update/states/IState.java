package com.soso.common.module.other.update.states;


import com.soso.common.module.other.update.UpdateModule;

/**
 * Created by haipeng.L on 2017/11/6.
 */

public interface IState {
    void handleEvent(UpdateModule update, EventArg eventArg);
}
