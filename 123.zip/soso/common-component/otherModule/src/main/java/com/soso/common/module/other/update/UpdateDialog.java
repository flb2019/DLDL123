package com.soso.common.module.other.update;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.soso.common.module.other.R;
import com.soso.common.module.other.update.model.VersionDto;
import com.soso.sosolib.utils.ToastManager;
import com.soso.uiwidget.widgets.dialog.GCenterDialog;


/**
 */
public class UpdateDialog extends GCenterDialog implements OnClickListener {

    private TextView mVersion;
    private TextView mContent;
    private boolean mUserCancel = true;
    private VersionDto versionDto;
    private boolean isForce;

    private static UpdateDialog instance;
    private static int contextHashCode;

    /**
     *
     * @comments  这里并不是单例模式 只是为了让dialog能全局引用
     * @param context
     * @return
     * @version 1.0
     */
    public static synchronized UpdateDialog getInstance(Context context, boolean isForce, VersionDto versionDto){
        if(instance != null && context.hashCode() != contextHashCode){
            instance.onActivityDestroy();
        }
        if (instance == null){

            instance = new UpdateDialog(context,isForce,versionDto);
        }
        return instance;
    }

    DialogInterface.OnKeyListener keylistener = new DialogInterface.OnKeyListener(){
        public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
            if (keyCode== KeyEvent.KEYCODE_BACK&&event.getRepeatCount()==0){
                return true;
            }else{
                return false;
            }
        }
    };

    private UpdateDialog(Context context, boolean isForce, VersionDto versionDto) {
        super(context);
        contextHashCode = context.hashCode();
        this.isForce = isForce;
        this.versionDto = versionDto;
        init();
    }

    private void init() {
        setContentView(R.layout.other_dialog_update);
        mVersion = (TextView) findViewById(R.id.dlg_update_ver);
        mContent = (TextView) findViewById(R.id.dlg_update_content);
        findViewById(R.id.dlg_update_left_btn).setOnClickListener(this);
        findViewById(R.id.dlg_update_right_btn).setOnClickListener(this);

        mVersion.setText(String.format(getContext().getString(R.string.update_version),
                versionDto.getVersionName()));
        mContent.setText(versionDto.getUpgradeInfo());
        if (isForce){
            findViewById(R.id.dlg_update_left_btn).setVisibility(View.GONE);
            setCanceledOnTouchOutside(false);
            setCancelable(false);
            setOnKeyListener(keylistener);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.dlg_update_left_btn){
            dismiss();
        }else if (v.getId() == R.id.dlg_update_right_btn){
            mUserCancel = false;
            if (versionDto != null){

                goWeb(mContext,versionDto.getUrl());
            }
//                DModule.ModuleUpdate.cast(UpdateInterface.class).downloadPatch();
            if (!isForce){

                dismiss();
            }
        }
    }

    @Override
    public void dismiss() {
        super.dismiss();
        if (mUserCancel) {
        }
    }

    public void onActivityDestroy(){
        mContext = null;
        instance = null;
    }
    private void goWeb(Context context, String url){
        if (TextUtils.isEmpty(url)){
            return;
        }
        if (!url.contains("http")){
            ToastManager.getInstance(mContext).showText("地址错误，请重试~");
            return;
        }
        Intent intent= new Intent();
        intent.setAction("android.intent.action.VIEW");
        Uri content_url = Uri.parse(url.trim());
        intent.setData(content_url);
        context.startActivity(intent);
    }

}
