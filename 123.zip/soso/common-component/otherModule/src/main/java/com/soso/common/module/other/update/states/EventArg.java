package com.soso.common.module.other.update.states;

import android.text.TextUtils;

/**
 * Created by haipeng.L on 2017/11/6.
 */

public class EventArg {

    public enum Event {
        check_update,
        download,
        apply,
        install,
        full_download,
    }

    public Event getUpdateType() {
        return updateType;
    }

    public void setUpdateType(Event updateType) {
        this.updateType = updateType;
    }

    private Event updateType;

    private boolean isAutoCheck;

    public String getChannel() {
        if (TextUtils.isEmpty(channel)){
            return "";
        }
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    private String channel;

    public boolean isAutoCheck() {
        return isAutoCheck;
    }

    public void setAutoCheck(boolean autoCheck) {
        isAutoCheck = autoCheck;
    }

}
