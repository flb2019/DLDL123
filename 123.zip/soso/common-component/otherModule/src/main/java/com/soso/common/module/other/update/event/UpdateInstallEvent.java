package com.soso.common.module.other.update.event;

/**
 * Created by haipeng.L on 2017/11/6.
 */

public class UpdateInstallEvent {

    public static final int Install_Failed = 1;

    private int InstallState;

    public int getInstallState() {
        return InstallState;
    }

    public void setInstallState(int installState) {
        InstallState = installState;
    }
}
