package com.soso.common.module.other.update.event;


import com.soso.common.module.other.update.model.VersionDto;

/**
 * Created by haipeng.L on 2017/11/6.
 */

public class CheckupdateEvent {

    public static final int CheckUpdate_Started = 1;
    public static final int CheckUpdate_Failed = 2;
    public static final int CheckUpdate_Latest = 3;
    public static final int CheckUpdate_Newer = 4;

    private boolean isAutoCheck;
    private int CheckUpdateState;
    private VersionDto versionDto;

    public boolean isAutoCheck() {
        return isAutoCheck;
    }

    public void setAutoCheck(boolean autoCheck) {
        isAutoCheck = autoCheck;
    }

    public int getCheckUpdateState() {
        return CheckUpdateState;
    }

    public void setCheckUpdateState(int checkUpdateState) {
        CheckUpdateState = checkUpdateState;
    }

    public VersionDto getVersionDto() {
        return versionDto;
    }

    public void setVersionDto(VersionDto versionDto) {
        this.versionDto = versionDto;
    }
}
