package com.soso.common.module.other.update.states;


import com.soso.common.module.other.update.UpdateModule;

class StateInstall implements IState {

    private static final class Holder {
        private static final StateInstall sInstance = new StateInstall();
    }

    static StateInstall instance() {
        return Holder.sInstance;
    }

    @Override
    public void handleEvent(UpdateModule update, EventArg eventArg) {
    }
}
