package com.soso.common.module.other.update.event;

/**
 * Created by haipeng.L on 2018/2/5.
 */

public class UpdateSpotEvent {

    public UpdateSpotEvent(boolean showSpot){
        isShowSpot = showSpot;
    }


    private boolean isShowSpot;//是否显示小红点

    public boolean isShowSpot() {
        return isShowSpot;
    }

    public void setShowSpot(boolean showSpot) {
        isShowSpot = showSpot;
    }
}
