package com.soso.common.module.other.update.states;

public enum States {
    idle,
    check,
    download,
    apply,
    install;

    public static IState state(States state) {
        switch (state) {
            case idle:
                return StateIdle.instance();
            case check:
                return StateCheck.instance();
//            case download:
//                return StateDownload.instance();
//            case apply:
//                return StateApply.instance();
//            case install:
//                return StateInstall.instance();
            default:
                return null;
        }
    }
}
