package com.soso.common.module.other.update.states;


import com.soso.common.module.other.update.UpdateModule;

class StateCheck implements IState {

    private static final class Holder {
        private static final StateCheck sInstance = new StateCheck();
    }

    static StateCheck instance() {
        return Holder.sInstance;
    }

    @Override
    public void handleEvent(UpdateModule update, EventArg eventArg) {
        if (eventArg == null){
            return;
        }
        switch (eventArg.getUpdateType()) {
            case download:
                update.download();
                break;
            default:
                break;
        }
    }

}
