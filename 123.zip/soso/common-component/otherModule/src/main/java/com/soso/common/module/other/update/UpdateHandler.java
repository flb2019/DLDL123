package com.soso.common.module.other.update;

import android.app.Activity;
import android.content.Context;

import com.soso.common.module.other.R;
import com.soso.common.module.other.update.event.CheckupdateEvent;
import com.soso.common.module.other.update.event.UpdateInstallEvent;
import com.soso.common.module.other.update.event.UpdateSpotEvent;
import com.soso.common.module.other.update.model.VersionDto;
import com.soso.sosolib.art.integration.manager.EventBusManager;
import com.soso.sosolib.art.tools.AppComponentUtils;
import com.soso.sosolib.utils.AppUtils;
import com.soso.sosolib.utils.ToastManager;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.ref.WeakReference;


/**
 * Created by haipeng.L on 2017/11/6.
 */

public class UpdateHandler {
    public static boolean IS_SHOW_UPDATE_SPOT = false;

    private WeakReference<Context> mContext;

    public UpdateHandler(Context context) {
        mContext = new WeakReference<Context>(context);
    }

    public void addUpdateEvent() {
        EventBusManager.getInstance().register(this);
    }

    public void removeUpdateEvent() {
        EventBusManager.getInstance().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onCheckUpdateEvent(CheckupdateEvent checkupdateEvent) {
        if (checkupdateEvent == null) {
            return;
        }
        boolean isAutoCheck = checkupdateEvent.isAutoCheck();
        switch (checkupdateEvent.getCheckUpdateState()) {
            case CheckupdateEvent.CheckUpdate_Started:
                if (!isAutoCheck) {

                    ToastManager.getInstance(mContext.get()).showText(R.string.update_checking);
//                    FloatManager.getInstance().showFloatView(R.string.update_checking);
                }
                break;
            case CheckupdateEvent.CheckUpdate_Failed:
                if (!isAutoCheck) {
                    ToastManager.getInstance(mContext.get()).showText(R.string.update_error);
//                    FloatManager.getInstance().showFloatView(R.string.update_error);
                }
                break;
            case CheckupdateEvent.CheckUpdate_Latest:
                if (!isAutoCheck) {
                    String curr = AppUtils.getAppVersionName(mContext.get());
                    String showContent = String.format("%s(%s)", mContext.get().getString(R.string.update_latest), curr.toString());
                    ToastManager.getInstance(mContext.get()).showText(showContent);
                }
                break;
            case CheckupdateEvent.CheckUpdate_Newer:
                VersionDto versionDto = checkupdateEvent.getVersionDto();
                if (versionDto == null) {
                    return;
                }
                if (isAutoCheck) {//自动检查更新
                    checkUpdateRedSpot(versionDto.getVersionNumber());
                    switch (versionDto.getNotifyType()) {
                        case 2:
                            showUpdateDialog(false, versionDto);
                            break;
                        case 3:
                            showUpdateDialog(true, versionDto);
                            break;
                        default:
                            break;
                    }
                } else {//手动检查更新，显示更新对话框
                    ToastManager.getInstance(mContext.get()).cancelToast();
                    showUpdateDialog(false, versionDto);
                }

                break;
            default:
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onInstallEvent(UpdateInstallEvent updateInstallEvent) {
        if (updateInstallEvent == null) {
            return;
        }
        switch (updateInstallEvent.getInstallState()) {
            case UpdateInstallEvent.Install_Failed:
                ToastManager.getInstance(mContext.get()).showText(R.string.update_install_failed);
//                FloatManager.getInstance().showFloatView(R.string.update_install_failed);
                break;
            default:
                break;
        }
    }

    private void checkUpdateRedSpot(int newVersionNum) {
        if (newVersionNum > AppUtils.getAppVersionCode(mContext.get())) {
            if (!IS_SHOW_UPDATE_SPOT) {//需要弹小红点，检测之后，只需弹一次
                EventBusManager.getInstance().post(new UpdateSpotEvent(true));
                IS_SHOW_UPDATE_SPOT = true;
            }
        }
    }

    private UpdateDialog dialog;

    private void showUpdateDialog(boolean isForce, VersionDto versionDto) {
        //用这个才会在当前activity弹窗
        Activity activity = AppComponentUtils.getAppComponent().appManager().getTopActivity();
//        Activity activity = BaseApplication.getInstance().getCurrentActivity().get();
        dialog = UpdateDialog.getInstance(activity, isForce, versionDto);
        dialog.show();
        if (!IS_SHOW_UPDATE_SPOT) {//需要弹小红点，检测之后，只需弹一次
            EventBusManager.getInstance().post(new UpdateSpotEvent(true));
            IS_SHOW_UPDATE_SPOT = true;
        }
    }


    public void clearReference() {
        if (dialog != null) {
            dialog.onActivityDestroy();
        }
        if (mContext != null) {
            if (mContext.get() != null) {
                mContext.clear();
            }
            mContext = null;
        }
    }

    public void onDestroy() {
        removeUpdateEvent();
        clearReference();
    }

}
