package com.soso.common.module.other.component;

import android.app.Activity;

import com.billy.cc.core.component.CC;
import com.billy.cc.core.component.IComponent;
import com.soso.common.module.other.qrCode.CustomCaptureActivity;
import com.soso.common.module.other.qrCode.QRCoderHelper;

/**
 * Created by sumerlin on 2019/3/3 2019/3/3.
 * Describe:
 */
public class OtherComponent implements IComponent {
    @Override
    public String getName() {
        return "OtherComponent";
    }

    @Override
    public boolean onCall(CC cc) {
        switch (cc.getActionName()) {
            case "openQRCoderView":
                //扫一扫不需要登录
                QRCoderHelper.getIntentIntegrator((Activity) cc.getContext())
                        .setCaptureActivity(CustomCaptureActivity.class)
                        .initiateScan();
                break;
            default:
                break;
        }
        return false;
    }
}
