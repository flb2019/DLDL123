package com.soso.common.module.other.update;

import android.content.Context;

import com.soso.common.module.other.update.event.CheckupdateEvent;
import com.soso.common.module.other.update.model.VersionDto;
import com.soso.common.module.other.update.states.EventArg;
import com.soso.common.module.other.update.states.IState;
import com.soso.common.module.other.update.states.States;
import com.soso.network.bean.NetResultData;
import com.soso.network.callback.NetCallback;
import com.soso.network.core.NetWorkMethods;
import com.soso.network.exception.ErrorMessage;
import com.soso.sosolib.art.integration.manager.EventBusManager;
import com.soso.sosolib.utils.AppUtils;

import java.lang.ref.WeakReference;
import java.util.HashMap;

import io.reactivex.disposables.Disposable;

/**
 * Created by haipeng.L on 2017/11/6.
 */

public class UpdateModule implements UpdateInterface {

    private IState mCurrentState;
    private WeakReference<Context> mContext;
    private String checkUpdateUrl;
    private String appName;
    private String channel;

    public UpdateModule(Context context, String name, String url, String channel) {
        mContext = new WeakReference<Context>(context);
        appName = name;
        checkUpdateUrl = url;
        this.channel = channel;
        idle();
    }

    private void setCurrentState(IState state) {
        mCurrentState = state;
    }

    @Override
    public void updateVersionData(boolean autoCheck) {
        EventArg eventArg = new EventArg();
        eventArg.setAutoCheck(autoCheck);
        eventArg.setUpdateType(EventArg.Event.check_update);
        eventArg.setChannel(channel);
        mCurrentState.handleEvent(UpdateModule.this, eventArg);
    }

    @Override
    public void fullDownload() {

    }

    @Override
    public void downloadPatch() {

    }

    @Override
    public void ignore() {

    }

    @Override
    public String getPatchNote() {
        return null;
    }

    @Override
    public String getVersion() {
        return null;
    }

    public void download() {

    }

    /// package
    public void checkUpdate(final boolean autoCheck, String channel) {

        setCurrentState(States.state(States.check));
        CheckupdateEvent checkupdateEvent = new CheckupdateEvent();
        checkupdateEvent.setAutoCheck(autoCheck);
        checkupdateEvent.setCheckUpdateState(CheckupdateEvent.CheckUpdate_Started);
        EventBusManager.getInstance().post(checkupdateEvent);

        HashMap<String, Object> map = new HashMap<>();
        map.put("os", "android");
        map.put("versionNumber", AppUtils.getAppVersionCode(mContext.get()));
        map.put("appName", appName);
        map.put("channelNumber", channel);
//        map.put("versionDate","android");
        NetWorkMethods.getInstance().postBody(checkUpdateUrl, map, new NetCallback<VersionDto>() {
            @Override
            public void onStart(Disposable disposable) {

            }

            @Override
            public void onSuccess(NetResultData<VersionDto> netResult) {
                onGetUpdateData(autoCheck, netResult.getData());
            }

            @Override
            public void onError(ErrorMessage error) {
                idle();
                CheckupdateEvent checkupdateEvent = new CheckupdateEvent();
                checkupdateEvent.setAutoCheck(autoCheck);
                checkupdateEvent.setCheckUpdateState(CheckupdateEvent.CheckUpdate_Failed);
                EventBusManager.getInstance().post(checkupdateEvent);
            }
        });
//        ApiMethods.post(new ParamsModel(Urls.Api_Default_Url, "1.0", checkUpdateUrl, map)
//                , new NetCallback<VersionDto>(VersionDto.class) {
//                    @Override
//                    public void onStart(Disposable d) {
////                LSPostUtil.postLoading(mLoadService);
//                    }
//
//                    @Override
//                    public void onSuccess(VersionDto model) {
//                        onGetUpdateData(autoCheck, model);
//                    }
//
//                    @Override
//                    public void onError(String errorMsg, String errorCode) {
//                        super.onError(errorMsg, errorCode);
//                        idle();
//                        CheckupdateEvent checkupdateEvent = new CheckupdateEvent();
//                        checkupdateEvent.setAutoCheck(autoCheck);
//                        checkupdateEvent.setCheckUpdateState(CheckupdateEvent.CheckUpdate_Failed);
//                        EventBusManager.getInstance().post(checkupdateEvent);
//                    }
//
//                    @Override
//                    public void onFinish() {
//                        super.onFinish();
//                    }
//                });
    }

    /// private
    private void onGetUpdateData(boolean autoCheck, VersionDto data) {
        CheckupdateEvent checkupdateEvent = new CheckupdateEvent();
        if (null == data) {
            idle();
            checkupdateEvent.setAutoCheck(autoCheck);
            checkupdateEvent.setCheckUpdateState(CheckupdateEvent.CheckUpdate_Failed);
            EventBusManager.getInstance().post(checkupdateEvent);
            return;
        }

        if (versionVerify(data)) {
            checkupdateEvent.setAutoCheck(autoCheck);
            checkupdateEvent.setCheckUpdateState(CheckupdateEvent.CheckUpdate_Newer);
            checkupdateEvent.setVersionDto(data);
            EventBusManager.getInstance().post(checkupdateEvent);
        } else {
            checkupdateEvent.setAutoCheck(autoCheck);
            checkupdateEvent.setCheckUpdateState(CheckupdateEvent.CheckUpdate_Latest);
            checkupdateEvent.setVersionDto(data);
            EventBusManager.getInstance().post(checkupdateEvent);
            idle();
        }
    }


    private boolean versionVerify(VersionDto data) {
        if (data == null) {
            return false;
        }
        if (mContext.get() != null) {
            int curCode = AppUtils.getAppVersionCode(mContext.get());
            if (data.getVersionNumber() > curCode) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }

    }

    private void idle() {
        setCurrentState(States.state(States.idle));
    }
}
