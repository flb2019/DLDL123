package com.soso.common.module.other.update.model;


import android.text.TextUtils;

import java.io.Serializable;

public class VersionDto implements Serializable {
    private static final long serialVersionUID=871238749032L;
    //id
    private long id;

    //1 - 不提醒，2 - 通知更新，3 - 强制更新
    private int notifyType;

    //app名称
    private String appName;

    //版本号
    private int versionNumber;

    //版本名称
    private String versionName;

    //版本发布时间
    private long versionDate;

    //ios/android
    private String os;

    //通知更新版本号
    private int notifyUpdate;

    //强制更新版本号
    private int forceUpdate;

    //命令编码
    private String cmd;

    //URL
    private String url;

    //参数
    private String params;

    //升级信息
    private String upgradeInfo;

    //创建时间
    private long createTime;

    //更新时间
    private long updateTime;

    //创建者
    private String creator;

    //更新人
    private String updator;

    //状态。0 - 未启用，1 - 启用，-1 - 删除
    private int status;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id ;
    }

    public int getNotifyType() {
        return notifyType;
    }

    public void setNotifyType(int notifyType) {
        this.notifyType = notifyType;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName == null ? null : appName.trim();
    }

    public int getVersionNumber() {
        return versionNumber;
    }

    public void setVersionNumber(int versionNumber) {
        this.versionNumber = versionNumber;
    }

    public String getVersionName() {
        if (TextUtils.isEmpty(versionName))
            return "";
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName == null ? null : versionName.trim();
    }

    public long getVersionDate() {
        return versionDate;
    }

    public void setVersionDate(long versionDate) {
        this.versionDate = versionDate;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os == null ? null : os.trim();
    }

    public int getNotifyUpdate() {
        return notifyUpdate;
    }

    public void setNotifyUpdate(int notifyUpdate) {
        this.notifyUpdate = notifyUpdate;
    }

    public int getForceUpdate() {
        return forceUpdate;
    }

    public void setForceUpdate(int forceUpdate) {
        this.forceUpdate = forceUpdate;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd == null ? null : cmd.trim();
    }

    public String getUrl() {
        if (TextUtils.isEmpty(url)){
            return "";
        }
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params == null ? null : params.trim();
    }

    public String getUpgradeInfo() {
        if (TextUtils.isEmpty(upgradeInfo)){
            return "";
        }
        return upgradeInfo.replace("\\n", "\n");
    }

    public void setUpgradeInfo(String upgradeInfo) {
        this.upgradeInfo = upgradeInfo == null ? null : upgradeInfo.trim();
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator == null ? null : creator.trim();
    }

    public String getUpdator() {
        return updator;
    }

    public void setUpdator(String updator) {
        this.updator = updator == null ? null : updator.trim();
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}