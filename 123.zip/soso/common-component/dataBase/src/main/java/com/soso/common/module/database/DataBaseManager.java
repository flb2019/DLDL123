package com.soso.common.module.database;

import android.database.sqlite.SQLiteDatabase;

import com.soso.app.database.greendao.DaoMaster;
import com.soso.app.database.greendao.DaoSession;
import com.soso.sosolib.BaseApplication;

/**
 * Created by sumerlin on 2019/3/11 2019/3/11.
 * Describe: 数据库管理器
 */
public class DataBaseManager {
    /** 数据库是否加密的标识 */
    public static final boolean ENCRYPTED = true;
    private  DaoSession mDaoSession;
    private DataBaseManager() {
        createDao();
    }

    private void createDao() {
//        //创建数据库
//        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(Utils.getContext(), ENCRYPTED ? "notes-db-encrypted" : "notes-db");
//        //获取数据库读写的权限，如果进行加密调用helper.getEncryptedWritableDb("super-secret")，参数为设置的密码
//        Database db = ENCRYPTED ? helper.getEncryptedWritableDb("super-secret") : helper.getWritableDb();
//        mDaoSession = new DaoMaster(db).newSession();

        // 通过 DaoMaster 的内部类 DevOpenHelper，你可以得到一个便利的 SQLiteOpenHelper 对象。
        // 可能你已经注意到了，你并不需要去编写「CREATE TABLE」这样的 SQL 语句，因为 greenDAO 已经帮你做了。
        // 注意：默认的 DaoMaster.DevOpenHelper 会在数据库升级时，删除所有的表，意味着这将导致数据的丢失。
        // 所以，在正式的项目中，你还应该做一层封装，来实现数据库的安全升级。
        //创建数据库mydb.db
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(BaseApplication.getAppContext(),"mydb.db");
        //获取可写数据库
        SQLiteDatabase database = helper.getWritableDatabase();
        //获取数据库对象  // 注意：该数据库连接属于 DaoMaster，所以多个 Session 指的是相同的数据库连接。
        DaoMaster daoMaster = new DaoMaster(database);
        //获取Dao对象管理者
        mDaoSession = daoMaster.newSession();
    }

    private static class SingletonHolder {
        private static final DataBaseManager INSTANCE = new DataBaseManager();
    }

    //获取单例
    public static DataBaseManager getInstance() {
        return DataBaseManager.SingletonHolder.INSTANCE;
    }


    private void initGreenDao() {
        // 通过 DaoMaster 的内部类 DevOpenHelper，你可以得到一个便利的 SQLiteOpenHelper 对象。
        // 可能你已经注意到了，你并不需要去编写「CREATE TABLE」这样的 SQL 语句，因为 greenDAO 已经帮你做了。
        // 注意：默认的 DaoMaster.DevOpenHelper 会在数据库升级时，删除所有的表，意味着这将导致数据的丢失。
        // 所以，在正式的项目中，你还应该做一层封装，来实现数据库的安全升级。
        //创建数据库mydb.db
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(BaseApplication.getAppContext(),"mydb.db");
        //获取可写数据库
        SQLiteDatabase database = helper.getWritableDatabase();
        //获取数据库对象  // 注意：该数据库连接属于 DaoMaster，所以多个 Session 指的是相同的数据库连接。
        DaoMaster daoMaster = new DaoMaster(database);
        //获取Dao对象管理者
        mDaoSession = daoMaster.newSession();
    }

    public  DaoSession getDaoSession(){
        return mDaoSession;
    }
}
