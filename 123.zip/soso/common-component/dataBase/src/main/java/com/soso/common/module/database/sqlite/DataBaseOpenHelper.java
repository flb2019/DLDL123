//package com.soso.common.module.database.sqlite;
//
//import android.content.ContentValues;
//import android.content.Context;
//import android.database.Cursor;
//import android.database.sqlite.SQLiteDatabase;
//import android.database.sqlite.SQLiteOpenHelper;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
///**
// * Created by sumerlin on 2019/4/14 2019/4/14.
// * Describe:
// */
//public class DataBaseOpenHelper extends SQLiteOpenHelper {
//    //数据库操作无外乎：“增删查改”。
//    // 对于“增删改”这类对表内容变换的操作，我们需先调用getWritableDatabase()，在执行的时候可以调用通用的execSQL(String sql)方法或对应的操作API：insert()、delete()、update()。
//    // 而对“查”，需要调用getReadableDatabase()，这时就不能使用execSQL方法了，得使用query()或rawQuery()方法
//    public static final String DB_NAME = "database.db";
//
//    public static final int DB_VERSION = 1;
//
//    public static final String TABLE_STUDENT = "students";
//
//    //创建 students 表的 sql 语句
//    private static final String STUDENTS_CREATE_TABLE_SQL = "create table" + TABLE_STUDENT + "("
//            + "id integer primary key autoincrement,"
//            + "name varchar(20) not null,"
//            + "tel_no varchar(11) not null,"
//            + "cls_id integer not null"
//            + ");";
//
//
//    public DataBaseOpenHelper(Context context) {
//        // 传递数据库名与版本号给父类
//        super(context, DB_NAME, null, DB_VERSION);
//    }
//
//
//    private static Map<String, DataBaseOpenHelper> dbMaps = new HashMap<String, DataBaseOpenHelper>();
//    private OnSqliteUpdateListener onSqliteUpdateListener;
//    /**
//     * 建表语句列表
//     */
//    private List<String> createTableList;
//    private String nowDbName;
//
//    private DataBaseOpenHelper(Context context, String dbName, int dbVersion, List<String> tableSqls) {
//        super(context, dbName, null, dbVersion);
//        nowDbName = dbName;
//        createTableList = new ArrayList<String>();
//        createTableList.addAll(tableSqls);
//    }
//
//    /**
//     *
//     * @Title: getInstance
//     * @Description: 获取数据库实例
//     * @param @param context
//     * @param @param userId
//     * @param @return
//     * @return DataBaseOpenHelper
//     * @author lihy
//     */
//    public static DataBaseOpenHelper getInstance(Context context, String dbName, int dbVersion, List<String> tableSqls) {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(dbName);
//        if (dataBaseOpenHelper == null) {
//            dataBaseOpenHelper = new DataBaseOpenHelper(context, dbName, dbVersion, tableSqls);
//        }
//        dbMaps.put(dbName, dataBaseOpenHelper);
//        return dataBaseOpenHelper;
//    };
//
//    //当数据不存在时，被调用。 当数据库存在时，则不会调用。 在这里可以顺便创建表，执行语句
//    @Override
//    public void onCreate(SQLiteDatabase db) {
//        // 在这里通过 db.execSQL 函数执行 SQL 语句创建所需要的表
//        // 创建 students 表
//        for (String sqlString : createTableList) {
//            db.execSQL(sqlString);
//        }
//    }
//
//
//    /**
//     * onUpgrade()方法在数据库版本每次发生变化时都会把用户手机上的数据库表删除，然后再重新创建。<br/>
//     * 一般在实际项目中是不能这样做的，正确的做法是在更新数据库表结构时，还要考虑用户存放于数据库中的数据不会丢失,从版本几更新到版本几。(非
//     * Javadoc)
//     *
//     * @see android.database.sqlite.SQLiteOpenHelper#onUpgrade(android.database.sqlite
//     *      .SQLiteDatabase, int, int)
//     */
//    @Override
//    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//        if (onSqliteUpdateListener != null) {
//            onSqliteUpdateListener.onSqliteUpdateListener(db, oldVersion, newVersion);
//        }
//    }
//
//    public void setOnSqliteUpdateListener(OnSqliteUpdateListener onSqliteUpdateListener) {
//        this.onSqliteUpdateListener = onSqliteUpdateListener;
//    }
//
//    /**
//     *
//     * @Title: execSQL
//     * @Description: Sql写入
//     * @param @param sql
//     * @param @param bindArgs
//     * @return void
//     * @author lihy
//     */
//    public void execSQL(String sql, Object[] bindArgs) {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(nowDbName);
//        synchronized (dataBaseOpenHelper) {
//            SQLiteDatabase database = dataBaseOpenHelper.getWritableDatabase();
//            database.execSQL(sql, bindArgs);
//        }
//    }
//
//    /**
//     *
//     * @Title: rawQuery
//     * @Description:
//     * @param @param sql查询
//     * @param @param bindArgs
//     * @param @return
//     * @return Cursor
//     * @author lihy
//     */
//    public Cursor rawQuery(String sql, String[] bindArgs) {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(nowDbName);
//        synchronized (dataBaseOpenHelper) {
//            SQLiteDatabase database = dataBaseOpenHelper.getReadableDatabase();
//            Cursor cursor = database.rawQuery(sql, bindArgs);
//            return cursor;
//        }
//    }
//
//    /**
//     *
//     * @Title: insert
//     * @Description: 插入数据
//     * @param @param table
//     * @param @param contentValues 设定文件
//     * @return void 返回类型
//     * @author lihy
//     * @throws
//     */
//    public void insert(String table, ContentValues contentValues) {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(nowDbName);
//        synchronized (dataBaseOpenHelper) {
//            SQLiteDatabase database = dataBaseOpenHelper.getWritableDatabase();
//            database.insert(table, null, contentValues);
//            database.close();
//        }
//    }
//
//    /**
//     *
//     * @Title: update
//     * @Description: 更新
//     * @param @param table
//     * @param @param values
//     * @param @param whereClause
//     * @param @param whereArgs 设定文件
//     * @return void 返回类型
//     * @throws
//     */
//    public void update(String table, ContentValues values, String whereClause, String[] whereArgs) {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(nowDbName);
//        synchronized (dataBaseOpenHelper) {
//            SQLiteDatabase database = dataBaseOpenHelper.getWritableDatabase();
//            database.update(table, values, whereClause, whereArgs);
//            database.close();
//        }
//    }
//    /**
//     *
//     * @Title: delete
//     * @Description:删除
//     * @param @param table
//     * @param @param whereClause
//     * @param @param whereArgs
//     * @return void
//     * @author lihy
//     */
//    public void delete(String table, String whereClause, String[] whereArgs) {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(nowDbName);
//        synchronized (dataBaseOpenHelper) {
//            SQLiteDatabase database = dataBaseOpenHelper.getWritableDatabase();
//            database.delete(table, whereClause, whereArgs);
//            database.close();
//        }
//    }
//
//    /**
//     *
//     * @Title: query
//     * @Description: 查
//     * @param @param table
//     * @param @param columns
//     * @param @param selection
//     * @param @param selectionArgs
//     * @param @param groupBy
//     * @param @param having
//     * @param @param orderBy
//     * @return void
//     * @author lihy
//     */
//    public Cursor query(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having,
//                        String orderBy) {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(nowDbName);
//        synchronized (dataBaseOpenHelper) {
//            SQLiteDatabase database = dataBaseOpenHelper.getReadableDatabase();
//            // Cursor cursor = database.rawQuery("select * from "
//            // + TableName.TABLE_NAME_USER + " where userId =" + userId, null);
//            Cursor cursor = database.query(table, columns, selection, selectionArgs, groupBy, having, orderBy);
//            return cursor;
//        }
//    }
//    /**
//     *
//     * @Description:查
//     * @param table
//     * @param columns
//     * @param selection
//     * @param selectionArgs
//     * @param groupBy
//     * @param having
//     * @param orderBy
//     * @param limit
//     * @return
//     * Cursor
//     * @exception:
//     * @author: lihy
//     * @time:2015-4-3 上午9:37:29
//     */
//    public Cursor query(String table, String[] columns, String selection, String[] selectionArgs, String groupBy, String having,
//                        String orderBy,String limit) {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(nowDbName);
//        synchronized (dataBaseOpenHelper) {
//            SQLiteDatabase database = dataBaseOpenHelper.getReadableDatabase();
//            // Cursor cursor = database.rawQuery("select * from "
//            // + TableName.TABLE_NAME_USER + " where userId =" + userId, null);
//            Cursor cursor = database.query(table, columns, selection, selectionArgs, groupBy, having, orderBy, limit);
//            return cursor;
//        }
//    }
//
//    /**
//     *
//     * @Description 查询，方法重载,table表名，sqlString条件
//     * @param @return
//     * @return Cursor
//     * @author lihy
//     */
//    public Cursor query(String tableName, String sqlString) {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(nowDbName);
//        synchronized (dataBaseOpenHelper) {
//            SQLiteDatabase database = dataBaseOpenHelper.getReadableDatabase();
//            Cursor cursor = database.rawQuery("select * from " + tableName + " " + sqlString, null);
//
//            return cursor;
//        }
//    }
//
//    /**
//     * @see android.database.sqlite.SQLiteOpenHelper#close()
//     */
//    public void clear() {
//        DataBaseOpenHelper dataBaseOpenHelper = dbMaps.get(nowDbName);
//        dataBaseOpenHelper.close();
//        dbMaps.remove(dataBaseOpenHelper);
//    }
//
//
//
////    //当数据不存在时，被调用。 当数据库存在时，则不会调用。 在这里可以顺便创建表，执行语句
////    @Override
////    public void onCreate(SQLiteDatabase sqLiteDatabase) {
////        // 在这里通过 db.execSQL 函数执行 SQL 语句创建所需要的表
////        // 创建 students 表
////        sqLiteDatabase.execSQL(STUDENTS_CREATE_TABLE_SQL);
////    }
////
////    @Override
////    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
////
////        // 数据库版本号变更会调用 onUpgrade 函数，在这根据版本号进行升级数据库
////        switch (oldVersion) {
////            case 1:
////                // do something
////                break;
////
////            default:
////                break;
////        }
////    }
//}
