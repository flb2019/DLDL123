package com.soso.common.module.database.sqlite;

import android.database.sqlite.SQLiteDatabase;

/**
 * Created by sumerlin on 2019/4/14 2019/4/14.
 * Describe:
 */
public interface OnSqliteUpdateListener {
     void onSqliteUpdateListener(SQLiteDatabase db, int oldVersion, int newVersion);

}
