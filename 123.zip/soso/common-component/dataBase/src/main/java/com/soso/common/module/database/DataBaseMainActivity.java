package com.soso.common.module.database;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.soso.app.database.greendao.DaoSession;
import com.soso.app.database.greendao.UserDao;
import com.soso.common.module.database.entity.User;
import com.soso.sosolib.utils.JsonUtils;
import com.soso.sosolib.utils.ToastManager;

import org.greenrobot.greendao.query.QueryBuilder;
import org.greenrobot.greendao.rx.RxDao;

import java.util.List;

public class DataBaseMainActivity extends AppCompatActivity {

    private UserDao mUserDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.database_activity_data_base_main);
        mUserDao = DataBaseManager.getInstance().getDaoSession().getUserDao();

        findViewById(R.id.btn_green_insert).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //在当前线程处理
                User user = new User();
                user.setName("lin song bin");
                user.setAge(28);
                mUserDao.insert(user);

                //greenDao 3.x 已经结合R小Java 可以一步处理
                DaoSession daoSession = DataBaseManager.getInstance().getDaoSession();
                RxDao<User, Long> rx = daoSession.getUserDao().rx();

            }
        });
        findViewById(R.id.btn_green_query).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                QueryBuilder<User> userQueryBuilder = mUserDao.queryBuilder();
                List<User> list = userQueryBuilder.build().list();
                ToastManager.getInstance(DataBaseMainActivity.this).showText(JsonUtils.formatJson(list));
            }
        });
    }
}
