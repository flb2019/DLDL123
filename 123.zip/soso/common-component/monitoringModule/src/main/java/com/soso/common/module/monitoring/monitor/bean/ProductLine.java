package com.soso.common.module.monitoring.monitor.bean;

/**
 * Created by haipeng.L on 2018/9/10.
 */

public class ProductLine {
    private String productVersion;//是	产品版本
    private String appKey	       ;//是	在后台注册的key,用于识别业务方
    private String channel;//	是	String	渠道号

    public String getProductVersion() {
        return productVersion;
    }

    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
}
