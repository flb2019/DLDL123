package com.soso.common.module.monitoring.monitor.core;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.soso.common.module.monitoring.monitor.bean.EventInfo;
import com.soso.common.module.monitoring.monitor.bean.EventInfos;
import com.soso.common.module.monitoring.monitor.config.EventConfig;
import com.soso.common.module.monitoring.monitor.db.DataConstruct;
import com.soso.common.module.monitoring.monitor.db.StaticsAgent;
import com.soso.network.bean.BaseData;
import com.soso.network.bean.NetResultData;
import com.soso.network.callback.NetCallback;
import com.soso.network.exception.ErrorMessage;
import com.soso.sosolib.utils.LogUtils;

import java.util.HashMap;
import java.util.List;

import io.reactivex.MaybeObserver;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

/**
 * Created by haipeng.L on 2018/9/13.
 */

public class GtStaticsManagerImpl implements GtStaticsManager, GtObserverPresenter.ScheduleListener {
    /**
     * context
     */
    private Context mContext;
    /**
     * sInstance
     */
    private static GtStaticsManager sInstance;

    private static GtObserverPresenter paObserverPresenter;

    private GtStatiPollMgr statiPollMgr;

    HashMap<String, String> pageIdMaps = new HashMap<String, String>();
    /**
     * Log TAG
     */
    private static final String LOG_TAG = GtStaticsManagerImpl.class.getSimpleName();

    public GtStaticsManagerImpl(Context mContext) {
        this.mContext = mContext;
    }

    @Override
    public void onInit(String appId, String channel) {

        // init  ObserverPresenter
        paObserverPresenter = new GtObserverPresenter(this);

        // init StaticsAgent
        StaticsAgent.init(mContext);

        // init CrashHandler
        GtCrashHandler.getInstance().init(mContext);
        // init  StatiPoll
        statiPollMgr = new GtStatiPollMgr(this);
        checkDbEventFiles();
    }

    //    @Override
    public void onSend() {
        DataConstruct.uploadBatchPolicy();
    }

    @Override
    public void onStore() {
//        DataConstruct.storeEvents();
//        DataConstruct.storePage();
        DataConstruct.finishCheckEvent();
    }

    @Override
    public void onRelease() {
        if (paObserverPresenter != null) {
            paObserverPresenter.destroy();
        }

        stopSchedule();

    }

    /**
     * 在初始化的时候已经检测过了数据库,上传了上次遗留的数据.所以这里不做检测了
     */
    @Override
    public void onRecordAppStart() {
        //send
        // onSend();
        // store appAction
        DataConstruct.storeAppAction("1");
    }

    @Override
    public void onRrecordPageEnd() {
//        DataConstruct.storeEvents();
//        DataConstruct.storePage();
        if (paObserverPresenter != null) {
            paObserverPresenter.onStop(mContext);
        }
        stopSchedule();
        DataConstruct.finishCheckEvent();
    }

    @Override
    public void onRecordPageStart(Context context) {

        if (context == null) {
            return;
        }

        //startSchedule
        startSchedule();

        String pageId = checkValidId(context.getClass().getSimpleName());
        if (pageId == null) {
            pageId = context.getClass().getSimpleName();
        }

        // init page
        onInitPage(pageId, null);

        if (paObserverPresenter != null) {
            paObserverPresenter.init(mContext);
        }

        if (paObserverPresenter != null) {
            paObserverPresenter.onStart(mContext);
        }
    }


    @Override
    public void onRrecordAppEnd() {
        LogUtils.e("app退出--------------------------------------------");
        //recard APP exit
        DataConstruct.storeAppAction("2");
        onStore();
        onRelease();
    }

    @Override
    public void onInitPage(String... strings) {
//        DataConstruct.initPage(mContext, eventInterface, strings[0], strings[1]);
    }

    @Override
    public void onPageParameter(String... strings) {
//        DataConstruct.initPageParameter(strings[0], strings[1]);
    }


    @Override
    public void onInitEvent(String eventName) {
//        DataConstruct.initEvent(eventName);
    }

    @Override
    public void onEventParameter(String... strings) {
//        DataConstruct.onEvent(strings[0], strings[1]);
    }

    @Override
    public void onEvent(String eventId, String eventName, String eventTopic, HashMap<String, Object> var2) {
        onEvent(eventId, eventName,eventTopic, "", "", 1, var2);
    }

    @Override
    public void onEvent(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params) {
        DataConstruct.onEvent(eventId, eventName,eventTopic,uid, cmd, eventType, params);
    }

    @Override
    public void onEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params) {
        DataConstruct.onEventUpload(eventId, eventName,eventTopic, uid, cmd, eventType, params);
    }

    @Override
    public void onCrashEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params) {
        DataConstruct.onCrashEventUpload(eventId, eventName,eventTopic, uid, cmd, eventType, params);
    }


    /**
     * onScheduleTimeOut
     */
    void onScheduleTimeOut() {

        Log.d(LOG_TAG, "onScheduleTimeOut  is sendData");
        if (GtStatInterface.getUploadPolicy() == GtStatInterface.UploadPolicy.UPLOAD_POLICY_INTERVA) {

        }
        onSend();
    }

    /**
     * 用于前后台切换,网络切换的时候调用,这是切回前台,网络连接成果的时候调用
     * startSchedule
     */
    public void startSchedule() {
        // if debug  time is 5 min
//        if (BaseFrameConfig.DEBUG &&
//                GtStatInterface.uploadPolicy == GtStatInterface.UploadPolicy.UPLOAD_POLICY_DEVELOPMENT) {
//            Log.d(LOG_TAG, "Schedule is start");
//        } else {
//            if (isWifiConnected(mContext)) {
//            } else {
//            }
//        }
        // 默认开启上报埋点
        if (EventConfig.IS_START) {
            GtStatInterface.onEvent(EventConfig.IN_RECEPTION_EVENTID, EventConfig.IN_RECEPTION_NAME,"");

        }

        if (GtStatInterface.getUploadPolicy() == GtStatInterface.UploadPolicy.UPLOAD_POLICY_INTERVA) {
            statiPollMgr.start(GtStatInterface.getIntervalRealtime() * 60 * 1000);
        }
    }

    /**
     * checkValidId
     *
     * @param name activitiyname
     * @return pageId
     */
    private String checkValidId(String name) {
        if (TextUtils.isEmpty(name)) {
            return null;
        }
        if (name.length() <= 0) {
            return null;
        }

        return getPageId(name);
    }


    /**
     * getPageId
     *
     * @param clazz
     * @return
     */
    private String getPageId(String clazz) {
        if (mContext == null) {
            return null;
        }
        return pageIdMaps.get(clazz);
    }

    /**
     * 用于前后台切换,网络切换的时候调用,这是切回后台,网络连接断开的时候调用
     * stop Schedule
     */
    public void stopSchedule() {
        if (EventConfig.IS_START) {
            GtStatInterface.onEvent(EventConfig.IN_BACKSTACK_EVENTID, EventConfig.IN_BACKSTACK_NAME,"");
        }
        //     Log.d(LOG_TAG, "stopSchedule()");
        if (GtStatInterface.getUploadPolicy() == GtStatInterface.UploadPolicy.UPLOAD_POLICY_INTERVA) {
            statiPollMgr.stop();
        }
    }

    @Override
    public void onStart() {
        Log.d(LOG_TAG, "startSchedule");

        startSchedule();

    }

    @Override
    public void onStop() {
        stopSchedule();
    }

    @Override
    public void onReStart() {
        // stopSchedule
        stopSchedule();
        // startSchedule
        startSchedule();
    }

    public static void checkDbEventFiles() {
        StaticsAgent.getEventMsgList(System.currentTimeMillis())
                .subscribeOn(Schedulers.io())
                .doOnSubscribe(new Consumer<Disposable>() {
                    @Override
                    public void accept(Disposable disposable) throws Exception {

                    }
                })
                .map(new Function<List<EventInfo>, EventInfos>() {
                    @Override
                    public EventInfos apply(List<EventInfo> eventInfos) throws Exception {
                        EventInfos messages = new EventInfos();
                        if (eventInfos == null || eventInfos.size() == 0) {
                            return messages;
                        }
                        for (EventInfo msg : eventInfos) {
                            DataConstruct.combineEventInfo(msg);
                        }
                        messages.setMessages(eventInfos);
                        return messages;
                    }
                })
                .subscribe(new MaybeObserver<EventInfos>() {

                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onSuccess(EventInfos eventInfos) {
                        if (eventInfos != null) {
                            uploadEvents(eventInfos.getMessages());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        LogUtils.d(e.getMessage());
                    }

                    @Override
                    public void onComplete() {

                    }
                });

    }

    public static void uploadEvents(List<EventInfo> list) {
        if (list == null || list.size() <= 0) {
            return;
        }
        UploadManager.uploadEvents(list, new NetCallback<BaseData>() {
            @Override
            public void onStart(Disposable d) {

            }

            @Override
            public void onSuccess(NetResultData<BaseData> netResult) {
                deleteEventMsgList(list)
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Consumer<Integer>() {
                            @Override
                            public void accept(Integer o) throws Exception {
//                                Toast.makeText(GtStatInterface.getContext(), "delete events :" + o.intValue(), Toast.LENGTH_SHORT).show();
                            }
                        }, new Consumer<Throwable>() {
                            @Override
                            public void accept(Throwable throwable) throws Exception {

                            }
                        });

            }

            @Override
            public void onError(ErrorMessage error) {

            }

        });
    }

    public static Observable deleteEventMsgList(List<EventInfo> lists) {

        return Observable.create(new ObservableOnSubscribe<Integer>() {
            @Override
            public void subscribe(ObservableEmitter<Integer> e) throws Exception {
                int num = StaticsAgent.deleteEventMsgList(lists);
                if (num > 0) {
                    e.onNext(num);
                } else {
                    e.onError(new Throwable("delete error"));
                }
                e.onComplete();
            }
        })
                .subscribeOn(Schedulers.io());
    }


}
