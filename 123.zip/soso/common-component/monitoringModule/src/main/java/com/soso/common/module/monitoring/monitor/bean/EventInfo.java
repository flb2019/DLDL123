package com.soso.common.module.monitoring.monitor.bean;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import java.util.HashMap;

/**
 * Created by haipeng.L on 2018/9/10.
 */
@Entity(tableName = "eventmsg")
public class EventInfo {
    @PrimaryKey
    @NonNull
    private long id;
    private String source;// 是		数据来源：前端，H5,后台
    private String eventId;//  是		事件Id
    private String eventName;//是		事件名称
    private int eventType;//是	  事件类型：1 - 计数， 2 - 计算
    private String uid;//  是		用户id
    private Long createTime;//	是		创建时间，时间戳
    private String cmd;//  是		页码
    private HashMap<String,Object> attributes;//Map	自定义参数
    @Ignore
    private ProductLine productLine;
    @Ignore
    private SysData sysData;
    private String eventTopic;   // 后台事件统计

    public String getEventTopic() {
        return eventTopic;
    }

    public void setEventTopic(String eventTopic) {
        this.eventTopic = eventTopic;
    }

    public ProductLine getProductLine() {
        return productLine;
    }

    public void setProductLine(ProductLine productLine) {
        this.productLine = productLine;
    }

    public SysData getSysData() {
        return sysData;
    }

    public void setSysData(SysData sysData) {
        this.sysData = sysData;
    }

    @NonNull
    public long getId() {
        return id;
    }

    public void setId(@NonNull long id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public int getEventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        this.eventType = eventType;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public HashMap<String, Object> getAttributes() {
        return attributes;
    }

    public void setAttributes(HashMap<String, Object> attributes) {
        this.attributes = attributes;
    }

}
