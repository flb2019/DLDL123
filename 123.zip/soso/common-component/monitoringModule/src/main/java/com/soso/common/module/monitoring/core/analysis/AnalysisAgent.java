package com.soso.common.module.monitoring.core.analysis;

import android.app.Application;
import android.content.Context;
import android.support.v4.app.Fragment;

import com.soso.common.module.monitoring.core.base.GtCrashListener;


/**
 * Created by haipeng.L on 2018/9/26.
 */

public class AnalysisAgent {

//    static {
////        UmsStatsWrapper.getInstance();
//        AnalysisFactory.getStatsHandler(AnalysisFactory.AnalysisType.gtMonitor).initialize(null);
//    }

    public static void initialize(Application application, String channel, boolean isListener, GtCrashListener crashListener, boolean isDebug){
//        AnalysisFactory.getStatsHandler(AnalysisFactory.AnalysisType.gtMonitor).initialize(context,channel);
        AnalysisInit.init(application , channel,isListener,crashListener,isDebug);
    }

    /** 设置session超时时间 */
    public static void setSessionContinueMillis(long interval) {
//        if (interval > 0) {
//            AnalysisConfig.CONTINUE_SESSION_MILLIS = interval;
//        }
    }

    /** 设置上报模式: 1表示实时发送，0表示启动时发送 */
    public static void setDefaultReportPolicy(Context context, int reportModel) {
//        AnalysisConfig.setDefaultReportPolicy(context, reportModel);
    }

//    /** 绑定用户标识 */
//    public static String bindUserIdentifier(Context context, String identifier) {
//        return AnalysisConfig.bindUserIdentifier(context, identifier);
//    }

    /** 进入界面 */
    public static void onResume(Context context) {
//        if (AnalysisInit.isInited()) {
//            UmsStatsWrapper.getInstance().onResume(context);
//        }
        AnalysisInit.onResume(context);
    }

    /** 退出界面 */
    public static void onPause(Context context) {
//        if (AnalysisInit.isInited()) {
//            UmsStatsWrapper.getInstance().onPause(context);
//        }
        AnalysisInit.onPause(context);
    }
    /** 进入界面 */
    public static void onResume(Fragment fragment) {
//        if (AnalysisInit.isInited()) {
//            UmsStatsWrapper.getInstance().onResume(fragment);
//        }
        AnalysisInit.onResume(fragment);
    }

    /** 退出界面 */
    public static void onPause(Fragment fragment) {
//        if (AnalysisInit.isInited()) {
//            UmsStatsWrapper.getInstance().onPause(fragment);
//        }
        AnalysisInit.onPause(fragment);
    }

    /** 上报访问日志 */
    public static void postClientData(Context context) {
//        if (AnalysisInit.isInited()) {
////            UmsStatsWrapper.getInstance().postClientData(context);
//        }
        AnalysisInit.postClientData(context);
    }

    /** 事件统计 */
    public static void onEvent(Context context, String event_id) {
        onEvent(context, event_id, "1");
    }

    /** 事件统计 */
    public static void onEvent(Context context, String event_id, String value) {
//        if (AnalysisInit.isInited() && !TextUtils.isEmpty(event_id)) {
//            if(TextUtils.isEmpty(value)) {
//                value = "1";
//            }
////            UmsStatsWrapper.getInstance().onEvent(context, event_id, value);
//        }
        AnalysisInit.onEvent(context, event_id, value);
    }

    /** 启动错误收集 */
    public static void onError(Context context) {
//        if (AnalysisInit.isInited()) {
////            UmsStatsWrapper.getInstance().onError(context);
//        }
        AnalysisInit.onError(context);
    }

    public static void onProfileSignOff(){
        AnalysisInit.onProfileSignOff();
    }

    public static void onProfileSignIn(int id){
        AnalysisInit.onProfileSignIn(id);
    }
}
