package com.soso.common.module.monitoring.monitor.core;

import android.content.Context;

import java.util.HashMap;

/**
 * Created by haipeng.L on 2018/9/13.
 */

public interface GtStaticsManager {


    void onInit(String appId, String channel);

    void onSend();

    void onStore();

    void onRelease();

    void onRecordAppStart();

    void onRrecordPageEnd();

    void onRecordPageStart(Context context);

    void onRrecordAppEnd();

    void onInitPage(String... strings);

    void onPageParameter(String... strings);

    void onInitEvent(String eventName);

    void onEventParameter(String... strings);

    void onEvent(String eventId, String eventName, String eventTopic, HashMap<String, Object> var2);

    void onEvent(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params);

    void onEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params);


    void onCrashEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params);
}
