package com.soso.common.module.monitoring.todo;

import android.app.Application;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;

import com.soso.common.module.monitoring.core.wrapper.GtMonitorStatsWrapper;
import com.soso.sosolib.art.base.delegate.AppLifecycles;
import com.soso.sosolib.art.di.module.GlobalConfigModule;
import com.soso.sosolib.art.integration.ConfigModule;
import com.soso.sosolib.utils.LogUtils;
import com.umeng.analytics.MobclickAgent;

import java.util.List;

/**
 * Created by sumerlin on 2019/2/19 2019/2/19.
 * Describe:
 */
public class GlobalConfiguration implements ConfigModule {
    @Override
    public void applyOptions(Context context, GlobalConfigModule.Builder builder) {

    }

    @Override
    public void injectAppLifecycle(Context context, List<AppLifecycles> lifecycles) {
        lifecycles.add(new AppLifecycles() {
            @Override
            public void attachBaseContext(@NonNull Context base) {

            }

            @Override
            public void onCreate(@NonNull Application application) {
                LogUtils.i("monitoringModule.....GlobalConfiguration.....injectAppLifecycle...........onCreate");
                //捕获全局异常 注册
//                initCrashHandlerManager();
                //友盟统计,禁止默认的页面统计方式，这样将不会再自动统计Activity
                //http://dev.umeng.com/analytics/android-doc/integration
                MobclickAgent.openActivityDurationTrack(false);
            }

            @Override
            public void onTerminate(@NonNull Application application) {
                GtMonitorStatsWrapper.getInstance().onDestroy();

            }
        });

    }

    @Override
    public void injectActivityLifecycle(Context context, List<Application.ActivityLifecycleCallbacks> lifecycles) {
        lifecycles.add(new ActivityLifecycleImpl());
    }

    @Override
    public void injectFragmentLifecycle(Context context, List<FragmentManager.FragmentLifecycleCallbacks> lifecycles) {
        lifecycles.add(new FragmentLifecycleImpl());

    }


}
