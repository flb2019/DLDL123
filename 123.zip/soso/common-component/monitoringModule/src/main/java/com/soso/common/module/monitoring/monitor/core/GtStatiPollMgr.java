package com.soso.common.module.monitoring.monitor.core;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.format.DateUtils;
import android.text.format.Time;

import com.soso.common.module.monitoring.todo.Config;

/**
 * 这里可以用RxJava的retry来实现,这里是提供另外一种思路.
 * StatiPollMgr
 * Created by haipeng.L on 2018/9/20.
 */

public class GtStatiPollMgr {

    /** DEBUG mode */
    private static final boolean DEBUG = Config.MONITORING_DEBUG;
    /** Log TAG */
    private static final String LOG_TAG = GtStatiPollMgr.class.getSimpleName();
    /** MSG_TIMEOUT */
    private static final int MSG_TIMEOUT = 1;
    private GtStaticsManagerImpl staticsManagerImpl;
    /** 心跳周期 */
    private long mCardiacCycle;
    /** DefaultCycle */
    private long mDefaultCycle;

    /**
     * Constructor
     */
    public GtStatiPollMgr(GtStaticsManagerImpl staticsManager) {
        staticsManagerImpl = staticsManager;
    }

    /**
     * start
     *
     * @param aCardiacCycle
     *            心跳周期
     */
    public void start(long aCardiacCycle) {
        mDefaultCycle = aCardiacCycle;
        mCardiacCycle = aCardiacCycle;
        checkDateChanging();
        stop();
        loop();
    }

    /**
     * stop
     */
    public void stop() {
        sPrivateHandler.get().removeMessages(MSG_TIMEOUT);
    }

    /**
     * loop
     */
    private void loop() {
        Message msg = sPrivateHandler.get().obtainMessage(MSG_TIMEOUT, this);
        sPrivateHandler.get().sendMessageDelayed(msg, mCardiacCycle);
    }

    /**
     * onTimeOut msg
     */
    public void onTimeOut() {
        staticsManagerImpl.onScheduleTimeOut();
    }

    /**
     * checkDateChanging
     */
    private void checkDateChanging() {
        Time time = new Time();
        time.setToNow();
        int hour = time.hour; //24小时制
        int minute = time.minute;
        if (hour == 23) { //SUPPRESS CHECKSTYLE
            int cycle = 61 - minute; // SUPPRESS CHECKSTYLE 12:01访问
            long timeSchedule = cycle * DateUtils.MINUTE_IN_MILLIS;
            if (timeSchedule < mCardiacCycle) {
                mCardiacCycle = timeSchedule;
            }
        } else {
            if (mCardiacCycle != mDefaultCycle) {
                mCardiacCycle = mDefaultCycle;
            }
        }
    }

    /**
     * Handler
     */
    private static final ThreadLocal<Handler> sPrivateHandler = new ThreadLocal<Handler>() {
        @Override
        protected Handler initialValue() {
            return new Handler(Looper.getMainLooper()) {

                @Override
                public void handleMessage(Message msg) {
                    switch (msg.what) {
                        case MSG_TIMEOUT:
                            GtStatiPollMgr schedule = (GtStatiPollMgr) msg.obj;
                            if (schedule != null) {
                                schedule.onTimeOut();
                                schedule.checkDateChanging();
                                schedule.loop();
                            }
                            break;
                        default:
                            break;
                    }
                }
            };
        }
    };
}
