package com.soso.common.module.monitoring.core.analysis;

/**
 * Created by haipeng.L on 2018/9/26.
 */

public class AnalysisConfig {
    /**
     * 上报字段
     */
    public static final boolean gtMonitor = true;//使用ums上报
    public static final boolean umeng = false;//使用友盟上报
    public static final long sessionInterval =  30 * 60 * 1000;
}
