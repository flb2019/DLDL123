package com.soso.common.module.monitoring.monitor.config;

/**
 * Created by zhouwei2 on 2018/9/29.
 */

public class EventConfig {
    // 默认是开启上报前后台埋点
    public static boolean IS_START=true;

    //页面将要消失eventId;
    public static String ONPAUSE_EVENTID= "page_onpause";
    public static String ONPAUSE_NAME="页面将要消失";

    //页面将要显示eventId；
    public static String ONRESUEM_EVENTID="page_onresume";
    public static String ONRESUME_NAME="页面进来";

    //页面将要加载；
    public static String ONSTART_EVENTID="page_onstart";
    public static String ONSTART_NAME="页面将要加载";

    //页面已经消失
    public static String ONSTOP_EVENTID="page_onstop";
    public static String ONSTOP_NMAE="页面已经消失";

    public static String ONDESTROY_EVENTID="UIApplicationWillTerminateNotification";
    public static String ONDESTROY_NAME="应用程序将要杀死";

    //    //app启动开始
    public static String START_APP_EVENTID="UIApplicationDidFinishLaunchingNotification";
    public static String START_APP_NAME="应用程序启动完成";

    // 程序进入前台
    public static String IN_RECEPTION_EVENTID="UIApplicationWillEnterForegroundNotification";
    public static String IN_RECEPTION_NAME="应用程序进入前台";

    // 程序进入后台
    public static String IN_BACKSTACK_EVENTID="UIApplicationDidEnterBackgroundNotification";
    public static String IN_BACKSTACK_NAME="应用程序进入后台";

    // 页面变为活跃状态
    public static String ACTIVE_EVENTID="UIApplicationDidBecomeActiveNotification";
    public static String ACTIVE_NAME="应用程序变活跃状态";

    //页面变为非活跃状态
    public static String NO_ACTIVE_EVENTID="UIApplicationWillResignActiveNotification";
    public static String NO_ACTIVE_NAME="应用程序变非活跃状态";

    //页面异常统计字段
    public static String EXCEPTION_STATISTICS="exception_statistics";

    //页面统计生命周期字段
    public static String LIFE_CYCLE="life_cycle";

    //异常信息
    public static String EXCEPTION_LOG_EVENTID="exception_log";
    public static String EXCEPTION_NAME="异常日志记录";


}
