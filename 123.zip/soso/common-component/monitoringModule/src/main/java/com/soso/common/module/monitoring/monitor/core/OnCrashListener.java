package com.soso.common.module.monitoring.monitor.core;

/**
 * Created by zhouwei2 on 2018/9/27.
 */

public interface OnCrashListener {
    void onDealCrash(Throwable ex);
}
