package com.soso.common.module.monitoring.core.base;

import android.app.Application;
import android.content.Context;
import android.support.v4.app.Fragment;

import java.util.HashMap;

/**
 * Created by haipeng.L on 2018/9/26.
 * 埋点接口
 */

public interface IStatsInterface {

    void initialize(Application application, String channel, Boolean isListener);

    /**进入界面*/
    public void onResume(final Context context);
    /**退出界面*/
    public void onPause(final Context context);
    /**进入界面*/
    public void onResume(final Fragment context);
    /**退出界面*/
    public void onPause(final Fragment context);
    /**上报访问日志*/
    public void postClientData(final Context context); // 限制只发送一次ClientData
    /**事件统计 */
    public void onEvent(final Context context, final String event_id, final String event_name, final HashMap<String, String> params);
    /**事件统计 */
    public void onEvent(final Context context, final String event_id, final String event_name);
    /**启动错误收集*/
    public void onError(final Context context);
    /**统计账户*/
    public void onProfileSignIn(int ID);
    public void onProfileSignIn(String Provider, String ID);
    /***登出账户*/
    public void onProfileSignOff();
    /**mainActivity销毁*/
    public void onDestroy();
}
