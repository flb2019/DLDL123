package com.soso.common.module.monitoring.todo;

/**
 * Created by sumerlin on 2019/2/26 2019/2/26.
 * Describe:
 */
public class Config {
    // 埋点需要传的appid
    public final static boolean MONITORING_DEBUG = true;

    public final static String APPID = "utopa";
}
