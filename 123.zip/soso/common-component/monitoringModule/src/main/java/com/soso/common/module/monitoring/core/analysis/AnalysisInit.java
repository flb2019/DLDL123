package com.soso.common.module.monitoring.core.analysis;

import android.app.Application;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.SparseArray;

import com.soso.common.module.monitoring.core.base.GtCrashListener;
import com.soso.common.module.monitoring.core.base.ICrashReportInterface;
import com.soso.common.module.monitoring.core.base.IStatsInterface;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by haipeng.L on 2018/9/26.
 */

public class AnalysisInit {

    private static AtomicBoolean mInitialized = new AtomicBoolean(false);

    private static List<IStatsInterface> mStatsHandlers;
    private static List<ICrashReportInterface> mCrashHandlers;

    public static void init(Application application, String channel, boolean isListener, GtCrashListener crashListener, boolean isDebug) {
        if(mInitialized.getAndSet(true)) {
            return;
        }
        initialize(application,channel,isListener,crashListener,isDebug);

    }

    public static boolean isInited() {
        return mInitialized.get();
    }

    public static void initialize(Application application, String channel, Boolean isListener, GtCrashListener crashListener, boolean isDebug) {
        initStatsHandler(application,channel,isListener);
        initLogHandler(application,crashListener,isDebug);
    }

    private static void initStatsHandler(Application application, String channel, Boolean isListener) {
//        if (mInitialized.getAndSet(true)){
//            return;
//        }
        mStatsHandlers = new ArrayList<>(2);

        if (AnalysisConfig.gtMonitor) {
            if (!mStatsHandlers.contains(AnalysisFactory.getStatsHandler(AnalysisFactory.AnalysisType.gtMonitor)))
                mStatsHandlers.add(AnalysisFactory.getStatsHandler(AnalysisFactory.AnalysisType.gtMonitor));
            AnalysisFactory.getStatsHandler(AnalysisFactory.AnalysisType.gtMonitor).initialize(application,channel,isListener);
        }
        if (AnalysisConfig.umeng) {
            if (!mStatsHandlers.contains(AnalysisFactory.getStatsHandler(AnalysisFactory.AnalysisType.umeng)))
                mStatsHandlers.add(AnalysisFactory.getStatsHandler(AnalysisFactory.AnalysisType.umeng));
            AnalysisFactory.getStatsHandler(AnalysisFactory.AnalysisType.umeng).initialize(application,channel,isListener);
        }
    }

    private static void initLogHandler(Application application, GtCrashListener crashListener, boolean isDebug) {

        mCrashHandlers = new ArrayList<>(2);

        if (AnalysisConfig.gtMonitor) {
            ICrashReportInterface handler = AnalysisFactory.getCrashHandler(AnalysisFactory.AnalysisType.gtMonitor);
            if (null != handler) {
                handler.initCrashReport(application,crashListener,isDebug);
                mCrashHandlers.add(handler);
            }
        }
        if (AnalysisConfig.umeng) {
            mCrashHandlers.add(AnalysisFactory.getCrashHandler(AnalysisFactory.AnalysisType.umeng));
        }
    }

    public static void onEvent(Context context, String event_id, String value){
        if (isInited() && !empty(mStatsHandlers) && !TextUtils.isEmpty(event_id)) {
            if(TextUtils.isEmpty(value)) {
                value = "1";
            }
            for (IStatsInterface handler : mStatsHandlers) {
                handler.onEvent(context,event_id,value);
            }
        }
    }

    public static void onError(Context context){
        if (isInited() && !empty(mStatsHandlers)) {
            for (IStatsInterface handler : mStatsHandlers) {
                handler.onError(context);
            }
        }
    }

    public static void postClientData(Context context){
        if (isInited() && !empty(mStatsHandlers)) {
            for (IStatsInterface handler : mStatsHandlers) {
                handler.postClientData(context);
            }
        }
    }

    public static void onPause(Fragment fragment){
        if (isInited() && !empty(mStatsHandlers)) {
            for (IStatsInterface handler : mStatsHandlers) {
                handler.onPause(fragment);
            }
        }
    }

    /** 进入界面 */
    public static void onResume(Fragment fragment){
        if (isInited() && !empty(mStatsHandlers)) {
            for (IStatsInterface handler : mStatsHandlers) {
                handler.onResume(fragment);
            }
        }
    }

    public static void onPause(Context context){
        if (isInited() && !empty(mStatsHandlers)) {
            for (IStatsInterface handler : mStatsHandlers) {
                handler.onPause(context);
            }
        }
    }

    /** 进入界面 */
    public static void onResume(Context context){
        if (isInited() && !empty(mStatsHandlers)) {
            for (IStatsInterface handler : mStatsHandlers) {
                handler.onResume(context);
            }
        }
    }

    public static void onProfileSignIn(int ID){
        if (isInited() && !empty(mStatsHandlers)) {
            for (IStatsInterface handler : mStatsHandlers) {
                handler.onProfileSignIn(ID);
            }
        }
    }

    public static void onProfileSignIn(String Provider, String ID){
        if (isInited() && !empty(mStatsHandlers)) {
            for (IStatsInterface handler : mStatsHandlers) {
                handler.onProfileSignIn(Provider,ID);
            }
        }
    }

    public static void onProfileSignOff(){
        if (isInited() && !empty(mStatsHandlers)) {
            for (IStatsInterface handler : mStatsHandlers) {
                handler.onProfileSignOff();
            }
        }
    }

    /**
     * Test if a collection is either NIL or empty
     */
    public static boolean empty(Collection<?> xs){
        return xs == null || xs.isEmpty();
    }

    /**
     * Test if an array is either NIL or empty
     */
    public static <T> boolean empty(T[] xs) {
        return xs == null || xs.length == 0;
    }

    public static boolean empty(SparseArray<?> xs) {
        return xs == null || xs.size() == 0;
    }

    public static boolean empty(Map<?,?> xs){
        return xs == null || xs.size() == 0;
    }
}
