package com.soso.common.module.monitoring.monitor.core;

import android.content.Context;

import java.util.HashMap;

/**
 * Created by haipeng.L on 2018/9/13.
 */

public class GtStatSdk {

    /** context */
    private Context mContext;
    /** Instance */
    private static GtStatSdk sInstance;

    private static final String TAG = "TcStaInterface::StatSdk";

    private GtStaticsManager staticsManager;

    /**
     * getInstance
     *
     * @param aContext
     *            context
     * @return 返回 TcStaticsManager
     */
    protected static synchronized GtStatSdk getInstance(Context aContext) {
        if (sInstance == null) {
            sInstance = new GtStatSdk(aContext, new GtStaticsManagerImpl(aContext));
        }
        return sInstance;
    }

    /**
            * constructor
     *
             * @param aContext
     *            context
     */
    private GtStatSdk(Context aContext, GtStaticsManager aStaticsManager) {
        mContext = aContext;
        staticsManager = aStaticsManager;

    }

    protected void init(String appId, String channel) {

        staticsManager.onInit(appId, channel);

    }

    protected void onEvent(String eventId, String eventName, String eventTopic, HashMap<String, Object> var2){
        onEvent(eventId,eventName,eventTopic,"","",1,var2);
    }

    protected void onEvent(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params){
        staticsManager.onEvent(eventId,eventName,eventTopic,uid,cmd,eventType,params);
    }

    protected void onEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params){
        staticsManager.onEventUpload(eventId,eventName,eventTopic,uid,cmd,eventType,params);
    }

    protected void onCrashEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params){
        staticsManager.onCrashEventUpload(eventId,eventName,eventTopic,uid,cmd,eventType,params);
    }

    protected void send() {

        staticsManager.onSend();
    }

    protected void store() {

        staticsManager.onStore();

    }

    protected void upLoad() {

       // staticsManager.onSend();
    }

    /**
     * release
     */
    protected void release() {

        staticsManager.onRelease();

    }

    protected void recordPageEnd() {

        staticsManager.onRrecordPageEnd();

    }

    protected void recordAppStart() {

        staticsManager.onRecordAppStart();

    }

    protected void recordAppEnd() {

        staticsManager.onRrecordAppEnd();

    }

    protected void recordPageStart(Context context) {

        staticsManager.onRecordPageStart(context);

    }
}
