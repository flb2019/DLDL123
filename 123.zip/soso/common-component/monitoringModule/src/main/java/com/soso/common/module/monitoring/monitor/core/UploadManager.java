package com.soso.common.module.monitoring.monitor.core;

import com.google.gson.GsonBuilder;
import com.soso.common.module.monitoring.monitor.bean.EventInfo;
import com.soso.network.ApiFactory;
import com.soso.network.callback.NetCallback;

import java.util.HashMap;
import java.util.List;


/**
 * Created by haipeng.L on 2018/9/15.
 */

public class UploadManager {
    public static <D> void uploadEvents(List<EventInfo> list, NetCallback<D> callback){
        if (list == null || list.size() <= 0) {
            return;
        }
        String jsonMsg = new GsonBuilder().create().toJson(list);
        HashMap<String, Object> params = new HashMap<>();
        params.put("messages", jsonMsg);
        ApiFactory.getInstance().postBody( "bizlog.datapoint.collect.appPushBatch", params,callback);
    }

    public static <D> void uploadExceptionEvents(List<EventInfo> list, NetCallback<D> callback){
        if (list == null || list.size() <= 0) {
            return;
        }
        String jsonMsg = new GsonBuilder().create().toJson(list);
        HashMap<String, Object> params = new HashMap<>();
        params.put("messages", jsonMsg);

//        ParamsModel paramsModel = new ParamsModel(Urls.Api_Default_Url, "1.0", "bizlog.datapoint.collect.appPushBatch", params);

//        if (NetworkUtils.isConnected()) {

//            HashMap<String, String> signMap = getDataWithSign(paramsModel);


            ApiFactory.getInstance().postBody("bizlog.datapoint.collect.appPushBatch",params ,callback);

/*            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Response response = RxUtils.executerequestMap(HttpMethod.POST, paramsModel.url, null, callback.getClazz(), signMap, null, CacheMode.NO_CACHE);

                        if (response.isSuccessful()){
                            if (response.body() != null){
                                String msg = "";

                                org.json.JSONObject jsonObject = new org.json.JSONObject(response.body().string());
                                int code = jsonObject.getInt("code");
                                if (code == 0){
//                                    D d = (D) new JsonConvert(callback.getClazz());
                                    BaseData baseData = new BaseData();
                                    callback.onSuccess((D) baseData);
                                }else {
                                    callback.onError(jsonObject.getString("msg"),code+"");
                                }
                            }
                        }else {

                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        callback.onError(e.toString(), "NETFAILERRCODE");
                    }catch (JSONException e) {
                        e.printStackTrace();
                        callback.onError(e.toString(), "NETFAILERRCODE");
                    }finally {
                        callback.onFinish();
                    }
                }
            }).start();*/

//        } else if (callback != null) {
//            try {
//                callback.onError("您的网络不给力，请检查网络环境", "NETFAILERRCODE");
//            } finally {
//                callback.onFinish();
//            }
//        }


    }

/*    public static HashMap<String, String> getDataWithSign(final ParamsModel paramsModel) {

        HashMap<String, String> signMap = new HashMap<>();

        SessionDto session = CacheContainerManager.getInstance().getSession();
        if (session != null) {
            String nowTimeSecs = String.valueOf(session.getCheckCurrentTime());
            if (!TextUtils.isEmpty(nowTimeSecs))
                signMap.put(NetConfig.TIMESTAMP, nowTimeSecs);
            signMap.put(NetConfig.SESSIONKEY, session.sessionKey);
        }

        if (!TextUtils.isEmpty(paramsModel.method))
            signMap.put(NetConfig.METHOD, paramsModel.method);
        HashMap<String, Object> preParams = new HashMap<>();
//                        if (UserModule.isLogin(null)) {
//                            preParams.put(NetConfig.UID, UserModule.getUserInfo(null).uid);
//                            preParams.put(NetConfig.ACCESSTOKEN, UserModule.getUserInfo(null).accessToken);
//                        }

        if (paramsModel.paramaters != null) {
            preParams.putAll(MapUtils.filterNull(paramsModel.paramaters));
        }
        signMap.put(NetConfig.PARAMS, (new JSONObject(preParams)).toString());

        AppSignatureMd5 appSignatureMd5 = new AppSignatureMd5(session != null ? session.sessionSecret : "", signMap);
        signMap.put(NetConfig.SIGN, appSignatureMd5.sign());


        return signMap;
    }*/
}
