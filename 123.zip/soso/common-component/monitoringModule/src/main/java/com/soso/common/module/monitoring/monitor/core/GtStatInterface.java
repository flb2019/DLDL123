package com.soso.common.module.monitoring.monitor.core;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import com.soso.common.module.monitoring.monitor.config.EventConfig;
import com.soso.common.module.monitoring.monitor.db.GtMonitorDatabase;

import java.lang.ref.WeakReference;
import java.util.HashMap;

/**
 * Created by haipeng.L on 2018/9/13.
 */

public class GtStatInterface {

    /**实时发送*/
    protected static final int UPLOAD_POLICY_REALTIME  = 0;
    /**只在wifi下*/
    protected static final int UPLOAD_POLICY_WIFI_ONLY = 2;
    /**批量上报 达到一定次数*/
    protected static final int UPLOAD_POLICY_BATCH = 3;
    /**时间间隔*/
    protected static final int UPLOAD_POLICY_INTERVAL = 4;
    /**开发者debug模式 调用就可以发送*/
    protected static final int UPLOAD_POLICY_DEVELOPMENT = 5;
    /**每次启动 发送上次产生的数据*/
    protected static final int UPLOAD_POLICY_WHILE_INITIALIZE = 6;

    /**
     * 上报策略模式.
     */
    public enum UploadPolicy {
        /**实时发送*/
        UPLOAD_POLICY_REALTIME,
        /**只在wifi下*/
//        UPLOAD_POLICY_WIFI_ONLY,
        /**批量上报 达到一定次数*/
        UPLOAD_POLICY_BATCH,
        /**时间间隔*/
        UPLOAD_POLICY_INTERVA,
        /**开发者debug模式 调用就可以发送*/
        UPLOAD_POLICY_DEVELOPMENT,
        /**每次启动 发送上次产生的数据*/
        UPLOAD_POLICY_WHILE_INITIALIZE
    }

    /**实时发送.*/
    public static final int UPLOAD_INTERVAL_REALTIME  = 0;
    /**1分钟.*/
    public static final int UPLOAD_TIME_ONE = 1;
    /**5分钟.*/
    public static final int UPLOAD_TIME_THREAD = 3;
    /**10分钟.*/
    public static final int UPLOAD_TIME_TEN = 10;
    /**20分钟.*/
    public static final int UPLOAD_TIME_TWENTY = 20;
    /**30分钟发送.*/
    public static final int UPLOAD_TIME_THIRTY = 30;
    /**批量5次*/
    public static final int UPLOAD_BATCH_FIVE = 5;
    /**批量20次*/
    public static final int UPLOAD_BATCH_TWENTY = 20;
    /**批量50次*/
    public static final int UPLOAD_BATCH_FIFTY = 50;

    /**
     * 上报策略
     */
    protected static UploadPolicy uploadPolicy;

    private static int intervalRealtime = UPLOAD_TIME_THREAD;

    /**
     * 缓存的事件数量
     */
    private static int intervalRealBatchNum = UPLOAD_BATCH_FIFTY;

    private static int eventType = 1;

    private static String appKey;
    private static String channel;
    private static String uid;
    private static Context context;
    private static Application mApplication;
    /**
     * private constructor
     */
    private GtStatInterface(){

    }

    public static Context getContext() {
        return mApplication;
    }
    public static String getUid(){
        return uid;
    }

    /**
     * initialize
     * @param
     * @param appId
     * @param channel
     */
    public static void initialize(Application application, String appId, String channel, String uid, boolean LifeListenr) {
      //  context = aContext;
        mApplication=application;
        GtStatInterface.appKey = appId;
        GtStatInterface.uid=uid;
        setChannel(channel);
        GtStatSdk.getInstance(application).init(appId, channel);
//        CacheContainerManager.getInstance().init(application);
//        SessionModule.checkSession(null);
        GtMonitorDatabase.getInstance(application);
        lifeStyleListener(LifeListenr);


    }

    /**
     * 设置策略模式
     * @param policy
     *     策略模式（实时模式下间隔时间无效）
     *     目前默认为UPLOAD_POLICY_INTERVA模式
     * @param time
     *     时间间隔（1 5 10 20 30分钟）
     */
    public static void setUploadPolicy(UploadPolicy policy, int time) {

        if (policy == null) {
            uploadPolicy = UploadPolicy.UPLOAD_POLICY_INTERVA;
            return;
        }
        switch (policy){
            case UPLOAD_POLICY_BATCH:
                if (time > 0){

                    setIntervalRealBatchNum(time);
                }
                break;
            case UPLOAD_POLICY_INTERVA:
                if (time > 0 || time <= 60) {
                    intervalRealtime = time;
                }
                break;
        }
        uploadPolicy = policy;

    }

    public static void setUploadPolicy(UploadPolicy policy) {
        if (policy == null) {
            uploadPolicy = UploadPolicy.UPLOAD_POLICY_INTERVA;
            return;
        }
        uploadPolicy = policy;
    }

    public static UploadPolicy getUploadPolicy() {
        if (uploadPolicy == null) {
            uploadPolicy = UploadPolicy.UPLOAD_POLICY_BATCH;
        }
        return uploadPolicy;
    }

    /**
     * getIntervalRealtime
     * @return  intervalRealtime
     */
    public static int getIntervalRealtime() {
        return intervalRealtime;
    }

    public static void setIntervalRealtime(int intervalRealtime) {
        GtStatInterface.intervalRealtime = intervalRealtime;
    }

    public static int getIntervalRealBatchNum() {
        //立马上报,缓存数量设置为1
        if (GtStatInterface.getUploadPolicy() == UploadPolicy.UPLOAD_POLICY_REALTIME
                || GtStatInterface.getUploadPolicy() == UploadPolicy.UPLOAD_POLICY_DEVELOPMENT){
            return 1;
        }
        return intervalRealBatchNum;
    }

    public static void setIntervalRealBatchNum(int intervalRealBatchNum) {
        GtStatInterface.intervalRealBatchNum = intervalRealBatchNum;
    }


    public static int getEventType() {
        return eventType;
    }

    public static void setEventType(int eventType) {
        GtStatInterface.eventType = eventType;
    }

    public static String getAppKey() {
        return GtStatInterface.appKey;
    }

    public static void setAppKey(String appKey) {
        GtStatInterface.appKey = appKey;
    }

    public static String getChannel() {
        return channel;
    }

    public static void setChannel(String channel) {
        GtStatInterface.channel = channel;
    }

    public static void onEvent(String eventId, String eventName, String eventTopic, HashMap<String, Object> params){
        onEvent(eventId,eventName,eventTopic,uid,"",1,params);
    }

    public static void onEvent(String eventId, String eventName, String eventTopic){
        onEvent(eventId,eventName,eventTopic,uid,"",1,null);
    }

    public static void onEvent(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params){
        GtStatSdk.getInstance(mApplication).onEvent(eventId,eventName,eventTopic,uid,cmd,eventType,params);
    }

    public static void onEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params){
        GtStatSdk.getInstance(mApplication).onEventUpload(eventId,eventName,eventTopic,uid,cmd,eventType,params);
    }

    //上报
    public static void onEventUpload(String eventId, String eventName, String eventTopic, HashMap<String, Object> params){
        GtStatSdk.getInstance(mApplication).onEventUpload(eventId,eventName,eventTopic,uid,"",eventType,params);
    }

    public static void onCrashEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params){
        GtStatSdk.getInstance(mApplication).onCrashEventUpload(eventId,eventName,eventTopic,uid,cmd,eventType,params);
    }

    //异常上报
    public static void onCrashEventUpload(String eventId, String eventName, String eventTopic, HashMap<String, Object> params){
        GtStatSdk.getInstance(mApplication).onCrashEventUpload(eventId,eventName,eventTopic,uid,"",eventType,params);
    }

    public static void send(){
        GtStatSdk.getInstance(mApplication).send();
    }

    /**
     * record Page Start
     * */
    public static void recordPageStart(String eventId, String name) {
        GtStatInterface.onEvent(eventId,name, EventConfig.LIFE_CYCLE);
        GtStatSdk.getInstance(mApplication).recordPageStart(mApplication);

    }
    /**
     * record Page End
     */
    public static void recordPageEnd(String eventId, String name) {
        GtStatInterface.onEvent(eventId,name,EventConfig.LIFE_CYCLE);
        GtStatSdk.getInstance(mApplication).recordPageEnd();

    }

    /**
     * record App Start
     */
    public static void recordAppStart(String eventId, String name) {
        GtStatInterface.onEvent(eventId,name,EventConfig.LIFE_CYCLE);
        GtStatSdk.getInstance(mApplication).recordAppStart();

    }

    /**
     * 关闭APP
     */
    public static void recordAppEnd(String eventId, String name) {
        GtStatInterface.onEvent(eventId,name,EventConfig.LIFE_CYCLE);
        GtStatSdk.getInstance(mApplication).recordAppEnd();
        GtStatSdk.getInstance(mApplication).release();

    }

    //为避免内存泄漏使用弱引用
    private static WeakReference<Activity> mCurrentActivity;


    public WeakReference<Activity> getCurrentActivity() {
        return mCurrentActivity;

    }
    public static  void lifeStyleListener(boolean isLifeListener){
        // isLifeListener 是否对生命周期进行监听，默认false
        if (isLifeListener){
            initActivityLifeRecycleCallback();
        }

    }


    /**
     * 注册activity生命周期监听，主要是拿当前的activity引用
     */
    private static void initActivityLifeRecycleCallback() {
        //当在代码里面引入多进程时，会出现Application类多次调用
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH /*&& isMainProcess(this)*/) {
            mApplication.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override
                public void onActivityCreated(Activity activity, Bundle bundle) {
                    //do nothing
                    mCurrentActivity = new WeakReference<>(activity);

                }

                @Override
                public void onActivityStarted(Activity activity) {
                    //do nothing
                    GtStatInterface.onEvent(EventConfig.ONSTART_EVENTID,EventConfig.ONSTART_NAME,EventConfig.LIFE_CYCLE);
                }

                @Override
                public void onActivityResumed(Activity activity) {
                    mCurrentActivity = new WeakReference<>(activity);
                    GtStatInterface.onEvent(EventConfig.ONRESUEM_EVENTID,EventConfig.ONRESUME_NAME,EventConfig.LIFE_CYCLE);
                }

                @Override
                public void onActivityPaused(Activity activity) {
                    //do nothing
                    GtStatInterface.onEvent(EventConfig.ONPAUSE_EVENTID,EventConfig.ONPAUSE_NAME,EventConfig.LIFE_CYCLE);
                }

                @Override
                public void onActivityStopped(Activity activity) {
                    //do nothing
                    GtStatInterface.onEvent(EventConfig.ONSTOP_EVENTID,EventConfig.ONSTOP_NMAE,EventConfig.LIFE_CYCLE);
                }

                @Override
                public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
                    //do nothing

                }

                @Override
                public void onActivityDestroyed(Activity activity) {
                    //do nothing
                }
            });
        }

    }

}
