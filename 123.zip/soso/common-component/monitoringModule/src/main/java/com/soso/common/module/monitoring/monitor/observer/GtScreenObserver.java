package com.soso.common.module.monitoring.monitor.observer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.PowerManager;
import android.util.Log;

import com.soso.common.module.monitoring.monitor.core.GtIntentManager;


/**
 * Created by haipeng.L on 2018/9/13.
 */

public class GtScreenObserver extends BroadcastReceiver {

    /** Debug mode */
    private static final boolean DEBUG = true;
    /** Log TAG */
    private static final String LOG_TAG = GtScreenObserver.class.getSimpleName();

    /** Context */
    private Context mContext;
    /** ScreenObserver  */
    private IScreenListener mListener;

    /**
     * Constructor
     *
     * @param aContext
     *            Context
     * @param aListener
     *            IScreenListener
     */
    public GtScreenObserver(Context aContext, IScreenListener aListener) {
        mContext = aContext;
        mListener = aListener;
    }


    public void start() {
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_SCREEN_ON);
            filter.addAction(Intent.ACTION_SCREEN_OFF);
            mContext.registerReceiver(this, filter);

            if (isScreenOn(mContext)) {
                if (mListener != null) {
                    mListener.onScreenOn(mContext);
                }
            } else {
                if (mListener != null) {
                    mListener.onScreenOff(mContext);
                }
            }
        } catch (Exception e) {
            if (DEBUG) {
                Log.w(LOG_TAG, "start Exception", e);
            }
        }
    }


    public void stop() {
        try {
            mContext.unregisterReceiver(this);
        } catch (Exception e) {
            if (DEBUG) {
                Log.w(LOG_TAG, "stop Exception", e);
            }
        }
    }

    /**
     * isScreenOn
     *
     * @param aContext
     *            Context
     */
    public boolean isScreenOn(Context aContext) {
        PowerManager pm = (PowerManager) aContext.getSystemService(Context.POWER_SERVICE);
        return pm.isScreenOn();
    }

    @Override
    public void onReceive(Context aContext, Intent aIntent) {
        if (GtIntentManager.getInstance().isScreenOnIntent(aIntent)) {
            if (mListener != null) {
                mListener.onScreenOn(aContext);
            }
        } else if (GtIntentManager.getInstance().isScreenOffIntent(aIntent)) {
            if (mListener != null) {
                mListener.onScreenOff(aContext);
            }
        }
    }

    /**
     * IScreenListener
     */
    public interface IScreenListener {


        void onScreenOn(Context aContext);


        void onScreenOff(Context aContext);
    }

}
