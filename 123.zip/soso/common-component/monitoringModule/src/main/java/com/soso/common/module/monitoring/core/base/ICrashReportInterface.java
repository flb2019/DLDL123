package com.soso.common.module.monitoring.core.base;

import android.app.Application;

/**
 * Created by haipeng.L on 2018/9/26.
 * 异常上报接口
 */

public interface ICrashReportInterface {
    void initCrashReport(Application application, GtCrashListener crashListener, boolean isDebug);
}
