package com.soso.common.module.monitoring.monitor.db;


import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import com.soso.common.module.monitoring.monitor.bean.EventInfo;

import java.util.List;

import io.reactivex.Maybe;

/**
 * Created by haipeng.L on 2018/9/11.
 */

@Dao
public interface EventMsgDao {

    @Query("SELECT * FROM eventmsg WHERE eventmsg.createTime <= :time ORDER BY eventmsg.id")
    Maybe<List<EventInfo>> getEventMsgList(long time);

    @Query("DELETE FROM eventmsg WHERE eventmsg.createTime <= :time")
    int deleteEventMsgList(long time);

    @Delete
    int deleteEventMsgList(List<EventInfo> lists);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    List<Long> insertEventMsgs(List<EventInfo> eventInfos);
}
