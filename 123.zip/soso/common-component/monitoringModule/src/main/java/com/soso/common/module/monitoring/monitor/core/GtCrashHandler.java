package com.soso.common.module.monitoring.monitor.core;

import android.content.Context;
import android.os.SystemClock;
import android.util.Log;

import com.soso.common.module.monitoring.CrashShowlActivity;
import com.soso.common.module.monitoring.monitor.config.EventConfig;

import java.util.HashMap;


/**
 * Created by haipeng.L on 2018/9/12.
 */

public class GtCrashHandler implements Thread.UncaughtExceptionHandler{
    private OnCrashListener onCrashListener;
    private Context context;
    public static GtCrashHandler INSTANCE;
    private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;

    /**
     * 是否处于Debug状态
     */
    private boolean isDebug = false;

    private GtCrashHandler() {
    }

    public void init(Context context) {
        this.context = context;
        uncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);
    }


    public static GtCrashHandler getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GtCrashHandler();
        }
        return INSTANCE;
    }

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {

        if (ex != null) {
            StackTraceElement[] stackTraceElements = ex.getStackTrace();
            Log.i("jiangTest", stackTraceElements.length + "---");
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(ex.getMessage()).append("\n");
            for (int i = stackTraceElements.length - 1; i >= 0; i--) {
                stringBuffer.append(stackTraceElements[i].getFileName()).append(":").append(stackTraceElements[i].getClassName()).append(stackTraceElements[i].getMethodName()).append("(").append(stackTraceElements[i].getLineNumber()).append(")").append("\n");
            }
            Log.i("jiangTest", stringBuffer.toString());
//            StaticsAgent.storeObject(new ExceptionInfo(DeviceUtil.getPhoneModel(), DeviceUtil.getSystemModel(), String.valueOf(DeviceUtil.getSystemVersion()), stringBuffer.toString()));
        }
//        android.os.Process.killProcess(android.os.Process.myPid());
//        System.exit(0);
           DealCrashEvent(thread,ex);
    }

    private void DealCrashEvent(Thread thread, Throwable ex) {
        //上传crash 信息给后台
        upLoadCrashEvent(ex);
        //延时杀死进程
        SystemClock.sleep(500);

        //Debug相关处理
        debugHandler(ex);
        // 供外部调用
        if (onCrashListener!=null){
            onCrashListener.onDealCrash(ex);
        }

        //这里可以弹出自己自定义的程序崩溃页面：然后自己干掉自己；
        //如果系统提供了默认的异常处理器，则交给系统去结束我们的程序，否则就由我们自己结束自己

        if (uncaughtExceptionHandler != null) {
            uncaughtExceptionHandler.uncaughtException(thread, ex);
        } else {
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(10);
        }

    }

    private void debugHandler(Throwable ex) {
        if (!isDebug) {
            return;
        }
        //开启日志崩溃页面
        if (ex.getStackTrace() != null && ex.getStackTrace().length > 0) {
            StackTraceElement element = ex.getStackTrace()[0];
            String strCrash="错误信息: \n"+ex.toString()+"\n"+"文件名:"+element.getFileName()+"\n"+"类名:"+element.getClassName()+"\n"
                           +"方法名:"+element.getMethodName()+"\n"
                            +"错误位置line :"+element.getLineNumber() + "\n";
            for (int i = 0; i < ex.getStackTrace().length; i++){
                strCrash += ex.getStackTrace()[i]+"\n";
            }
            CrashShowlActivity.startCrashShowlActivity(context,strCrash);
        }
    }

    private void upLoadCrashEvent(Throwable ex) {

        if (ex.getStackTrace() != null && ex.getStackTrace().length > 0) {
            StackTraceElement element = ex.getStackTrace()[0];
            String crashInfo="错误信息: \n";
            HashMap<String,Object> params = new HashMap<>();
            params.put("method",element.getMethodName());
            params.put("lineNumber",element.getLineNumber()+"");
            params.put("fileName",element.getFileName());
            params.put("className",element.getClassName());
            params.put("exception",ex.toString());
            for (int i = 0; i < ex.getStackTrace().length; i++){
                crashInfo += ex.getStackTrace()[i]+"\n";
            }
            params.put("exceptionString",crashInfo);
            GtStatInterface.onCrashEventUpload(EventConfig.EXCEPTION_LOG_EVENTID,EventConfig.EXCEPTION_NAME, EventConfig.EXCEPTION_STATISTICS,params);

        }
    }
   // 供外部调用
    public void setOnCrashListener(OnCrashListener listener,boolean isDebug){
        this.onCrashListener=listener;
        this.isDebug = isDebug;
    }
}
