package com.soso.common.module.monitoring.monitor.bean;

/**
 * Created by haipeng.L on 2018/9/10.
 */

public class SysData {

    private String os;//是		系统
    private String machine;//是		机器型号
    private String deviceId;//是		设备id

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getMachine() {
        return machine;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }
}
