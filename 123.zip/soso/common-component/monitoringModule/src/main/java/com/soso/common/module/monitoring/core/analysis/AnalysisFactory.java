package com.soso.common.module.monitoring.core.analysis;

import com.soso.common.module.monitoring.core.base.ICrashReportInterface;
import com.soso.common.module.monitoring.core.base.IStatsInterface;
import com.soso.common.module.monitoring.core.wrapper.GtMonitorStatsWrapper;
import com.soso.common.module.monitoring.core.wrapper.UmengStatsWrapper;
import com.soso.sosolib.utils.LogUtils;

/**
 * 写个埋点统计工厂,方便在不同的埋点工具之间切换
 * Created by haipeng.L on 2018/9/26.
 */

public class AnalysisFactory {

    public enum AnalysisType {
        gtMonitor,
        umeng,
    }

    public static IStatsInterface getStatsHandler(AnalysisType type) {
        switch (type) {
            case gtMonitor:
                return GtMonitorStatsWrapper.getInstance();
            case umeng:
                return UmengStatsWrapper.getInstance();
            default:
                LogUtils.e("AnalysisFactory", "getStatsHandler error type:" + type);
                return null;
        }
    }

    public static ICrashReportInterface getCrashHandler(AnalysisType type) {
        switch (type) {
            case gtMonitor:
                return GtMonitorStatsWrapper.getInstance();
            case umeng:
                return UmengStatsWrapper.getInstance();
            default:
                LogUtils.e("AnalysisFactory", "getCrashHandler error type:" + type);
                return null;
        }
    }
}
