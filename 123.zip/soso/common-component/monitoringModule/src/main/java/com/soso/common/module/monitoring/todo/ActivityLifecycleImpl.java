package com.soso.common.module.monitoring.todo;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

import com.soso.common.module.monitoring.core.wrapper.GtMonitorStatsWrapper;
import com.soso.sosolib.utils.LogUtils;
import com.umeng.analytics.MobclickAgent;

/**
 * Created by sumerlin on 2019/2/26 2019/2/26.
 * Describe:
 */
public class ActivityLifecycleImpl implements   Application.ActivityLifecycleCallbacks{

    @Override
    public void onActivityCreated(Activity activity, Bundle bundle) {

    }

    @Override
    public void onActivityStarted(Activity activity) {
        LogUtils.i("monitoringModule.....ActivityLifecycleImpl................onActivityStarted");

    }

    @Override
    public void onActivityResumed(Activity activity) {
        LogUtils.i("monitoringModule.....ActivityLifecycleImpl................onActivityResumed");
        // gmonitor  监听时长
        GtMonitorStatsWrapper.getInstance().onResume(activity);

    }

    @Override
    public void onActivityPaused(Activity activity) {
        LogUtils.i("monitoringModule.....ActivityLifecycleImpl................onActivityPaused");
        //友盟统计时长
        MobclickAgent.onPause(activity);
        // gmonitor 统计时长
        GtMonitorStatsWrapper.getInstance().onPause(activity);

    }

    @Override
    public void onActivityStopped(Activity activity) {

    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {

    }

    @Override
    public void onActivityDestroyed(Activity activity) {

    }
}
