package com.soso.common.module.monitoring;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.soso.monitoringmodule.R;


/**
 * Created by haipeng.L on 2018/10/10.
 */

public class CrashShowlActivity extends AppCompatActivity {

    private TextView tx_info;
    private Toolbar toolbar;
    private String crashInfo;

    /**
     * 打开崩溃展示页面
     *
     * @param context
     */
    public static void startCrashShowlActivity(Context context, String crashInfo) {
        Intent intent = new Intent(context.getApplicationContext(), CrashShowlActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Bundle bundle=new Bundle();
        intent.putExtra("crashInfo",crashInfo);
        intent.putExtras(bundle);
        context.getApplicationContext().startActivity(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crash_info);
        tx_info = findViewById(R.id.tx_info);
        tx_info.setMovementMethod(ScrollingMovementMethod.getInstance());
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("崩溃信息");
        setSupportActionBar(toolbar);
        crashInfo = (String) getIntent().getStringExtra("crashInfo");
        if (!TextUtils.isEmpty(crashInfo)){
            tx_info.setText(crashInfo);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_crash,menu);
        MenuItem btn_copy=  menu.findItem(R.id.btn_copy);
        btn_copy.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId()==R.id.btn_copy){
                    clipboard(crashInfo);
                }
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);

    }

    public void clipboard(String crashInfo) {
        if (TextUtils.isEmpty(crashInfo)) {
            return;
        }
        ClipboardManager cmb = (ClipboardManager) CrashShowlActivity.this.getSystemService(Context.CLIPBOARD_SERVICE);
        cmb.setText(crashInfo);
        Toast.makeText(CrashShowlActivity.this, "已复制崩溃信息", Toast.LENGTH_SHORT).show();
    }
}
