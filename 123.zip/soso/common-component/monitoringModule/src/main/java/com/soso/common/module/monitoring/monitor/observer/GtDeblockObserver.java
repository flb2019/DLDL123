package com.soso.common.module.monitoring.monitor.observer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

import com.soso.common.module.monitoring.monitor.core.GtIntentManager;
import com.soso.common.module.monitoring.todo.Config;

/**
 * Created by haipeng.L on 2018/9/13.
 */

public class GtDeblockObserver extends BroadcastReceiver {

    /** Debug mode */
    private static final boolean DEBUG = Config.MONITORING_DEBUG;
    /** StatLog TAG */
    private static final String StatLog_TAG = GtDeblockObserver.class.getSimpleName();
    /** Context */
    private Context mContext;
    /** IKeyguardListener */
    private IKeyguardListener mListener;

    /**
     * Constructor
     *
     * @param aContext
     *            Context
     * @param aListener
     *            IScreenListener
     */
    public GtDeblockObserver(Context aContext, IKeyguardListener aListener) {
        mContext = aContext;
        mListener = aListener;
    }

    /**
     * start Listener
     */
    public void start() {
        try {
            IntentFilter filter = new IntentFilter();
            filter.addAction(Intent.ACTION_USER_PRESENT);
            mContext.registerReceiver(this, filter);

            if (!isScreenLocked(mContext)) {
                if (mListener != null) {
                    mListener.onKeyguardGone(mContext);
                }
            }
        } catch (Exception e) {
            if (DEBUG) {
                Log.w(StatLog_TAG, "start Exception", e);
            }
        }
    }

    /**
     * stop Listener
     */
    public void stop() {
        try {
            mContext.unregisterReceiver(this);
        } catch (Exception e) {
            if (DEBUG) {
                Log.w(StatLog_TAG, "stop Exception", e);
            }
        }
    }

    /**
     * is Screen Locked
     *
     * @param aContext Context
     * @return true if screen locked, false otherwise
     */
    public boolean isScreenLocked(Context aContext) {
        android.app.KeyguardManager km = (android.app.KeyguardManager) aContext
                .getSystemService(Context.KEYGUARD_SERVICE);
        return km.inKeyguardRestrictedInputMode();
    }

    @Override
    public void onReceive(Context aContext, Intent aIntent) {
        if (GtIntentManager.getInstance().isUserPresentIntent(aIntent)) {
            if (mListener != null) {
                mListener.onKeyguardGone(aContext);
            }
        }
    }

    /**
     * IKeyguardListener
     */
    public interface IKeyguardListener {

        /**
         * unlock
         *
         * @param aContext
         *            Context
         */
        void onKeyguardGone(Context aContext);
    }

}
