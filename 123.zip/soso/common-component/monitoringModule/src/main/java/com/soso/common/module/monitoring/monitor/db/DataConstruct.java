package com.soso.common.module.monitoring.monitor.db;

import android.text.TextUtils;

import com.soso.common.module.monitoring.monitor.bean.EventInfo;
import com.soso.common.module.monitoring.monitor.bean.ProductLine;
import com.soso.common.module.monitoring.monitor.bean.SysData;
import com.soso.common.module.monitoring.monitor.core.GtStatInterface;
import com.soso.common.module.monitoring.monitor.core.UploadManager;
import com.soso.network.bean.BaseData;
import com.soso.network.bean.NetResultData;
import com.soso.network.callback.NetCallback;
import com.soso.network.exception.ErrorMessage;
import com.soso.sosolib.utils.AppUtils;
import com.soso.sosolib.utils.LogUtils;
import com.soso.sosolib.utils.SystemUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


/**
 * 数据构建
 * Created by haipeng.L on 2018/9/14.
 */

public class DataConstruct {

    private static ArrayBlockingQueue<EventInfo> eventQueue = new ArrayBlockingQueue(GtStatInterface.getIntervalRealBatchNum());

    private DataConstruct() {
    }


    /**
     * 缓存事件,如果队列满了,就按照策略执行对应任务
     * @param info
     */
    private static void storeEventQueue(EventInfo info){
        if (info == null){
            return;
        }
        try {
            eventQueue.put(info);
            if (eventQueue.size() == getIntervalRealBatchNum()){
                eventQueuePolicy();
            }
        } catch (InterruptedException e) {
            if (BaseFrameConfig.DEBUG){
                LogUtils.d("eventQueue is InterruptedException: eventQueue size:"+eventQueue.size());
            }
            eventQueuePolicy();
        }

    }

    private static void eventQueuePolicy(){
        switch (GtStatInterface.getUploadPolicy()){
            case UPLOAD_POLICY_BATCH:
                uploadBatchPolicy();
                break;
            case UPLOAD_POLICY_REALTIME:
                uploadBatchPolicy();
                break;
            case UPLOAD_POLICY_DEVELOPMENT:
                if (BaseFrameConfig.DEBUG){
                    uploadBatchPolicy();
                }
                break;
            case UPLOAD_POLICY_WHILE_INITIALIZE:
                uploadWhileInitialize();
                break;
            case UPLOAD_POLICY_INTERVA:
                uploadIntervaPolicy();
                break;
        }
    }

    /**
     * 时间间隔的时候,都放在队列中,在间隔触发的时候一次性取出来
     */
    private static void uploadIntervaPolicy(){

    }

    private static void uploadWhileInitialize(){
        List<EventInfo> list = new ArrayList<>();
        eventQueue.drainTo(list);
        StaticsAgent.insertEventMsgs(list);
    }

    public static void uploadBatchPolicy(){
        List<EventInfo> list = new ArrayList<>();
        eventQueue.drainTo(list);
        uploadBatchPolicy(list);
    }

    private static void uploadBatchPolicy(List<EventInfo> list){
        if (list == null){
            return;
        }
            UploadManager.uploadEvents(list, new NetCallback<BaseData>(BaseData.class) {
                @Override
                public void onStart(Disposable d) {

                }

                @Override
                public void onSuccess(BaseData d) {
                    LogUtils.d("Upload Success"+d.msg);
                }

                @Override
                public void onError(String errorMsg, String errorCode) {
                    super.onError(errorMsg, errorCode);
                    //失败了则存入数据库
                    StaticsAgent.insertEventMsgs(list);
                }
            });

    }

    private static void uploadCrashEvent(List<EventInfo> list){
        if (list == null){
            return;
        }
        UploadManager.uploadExceptionEvents(list, new NetCallback<BaseData>() {
            @Override
            public void onStart(Disposable d) {

            }

            @Override
            public void onSuccess(NetResultData<BaseData> netResult) {
                LogUtils.d("Upload Success"+netResult.getStatusMgs());
            }

            @Override
            public void onError(ErrorMessage error) {
                //失败了则存入数据库
                StaticsAgent.insertEventMsgs(list);
            }

        });
    }

    private static EventInfo createEventInfo(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params){
        EventInfo info = new EventInfo();
        if (TextUtils.isEmpty(eventId)){
            throw new RuntimeException("you must set eventId!");
        }
        info.setEventId(eventId);
        if (TextUtils.isEmpty(eventName)){
            throw new RuntimeException("you must set eventName!");
        }
        info.setEventName(eventName);
        info.setUid(uid);
        info.setCmd(cmd);
        info.setEventType(eventType);
        info.setSource("app");
        info.setCreateTime(System.currentTimeMillis());
        info.setId(getId());
        info.setEventTopic(eventTopic);
        if (params != null){
            info.setAttributes(params);
        }
        return info;
    }

    public static ProductLine createProductLine(){
        ProductLine productLine = new ProductLine();
        productLine.setProductVersion(AppUtils.getAppVersionName(getContext()));
        productLine.setAppKey(getAppKey());
        productLine.setChannel(getChannel());
        return productLine;
    }

    public static SysData createSysData(){
        SysData sysData = new SysData();
        AppInfoModel appInfo = CacheContainerManager.getInstance().getAppInfo();
        if (appInfo != null){
            sysData.setOs(appInfo.getOsInfo());
        }
        sysData.setDeviceId(SystemUtil.getImei());
        sysData.setMachine(SystemUtil.getSystemModel());
        return sysData;
    }

    public static EventInfo combineEventInfo(EventInfo eventInfo){
        if (eventInfo == null){
            return null;
        }
        eventInfo.setProductLine(createProductLine());
        eventInfo.setSysData(createSysData());
        return eventInfo;
    }

    public static void storeAppAction(String s) {
    }

    public static void onEvent(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params) {
        EventInfo eventInfo = createEventInfo(eventId,eventName,eventTopic,uid,cmd,eventType,params);
        storeData(eventInfo);
    }

    /**
     * 立刻上传信息到后台
     * @param eventId
     * @param eventName
     * @param uid
     * @param cmd
     * @param eventType
     * @param params
     */
    public static void onEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params){
        EventInfo eventInfo = createEventInfo(eventId,eventName,eventTopic,uid,cmd,eventType,params);
        combineEventInfo(eventInfo);
        ArrayList<EventInfo> list = new ArrayList<>();
        list.add(eventInfo);
        uploadBatchPolicy(list);
    }

    /**
     * 上传异常信息到后台
     * @param eventId
     * @param eventName
     * @param uid
     * @param cmd
     * @param eventType
     * @param params
     */
    public static void onCrashEventUpload(String eventId, String eventName, String eventTopic, String uid, String cmd, int eventType, HashMap<String, Object> params){
        EventInfo eventInfo = createEventInfo(eventId,eventName,eventTopic,uid,cmd,eventType,params);
        combineEventInfo(eventInfo);
        ArrayList<EventInfo> list = new ArrayList<>();
        list.add(eventInfo);
        uploadCrashEvent(list);
    }

    public static void storeData(EventInfo eventInfo){
        Observable.just(eventInfo)
                .doOnSubscribe(new Consumer<Disposable>() {
                    @Override
                    public void accept(Disposable disposable) throws Exception {
                        DataConstruct.combineEventInfo(eventInfo);
                    }
                })
                .observeOn(Schedulers.newThread())
                .subscribeOn(Schedulers.newThread())
                .subscribe(new Consumer<EventInfo>() {
                    @Override
                    public void accept(EventInfo eventInfo) throws Exception {
//                        if (GtStatInterface.getUploadPolicy() == GtStatInterface.UploadPolicy.UPLOAD_POLICY_DEVELOPMENT && BaseFrameConfig.DEBUG){
//                            ArrayList<EventInfo> list = new ArrayList<>();
//                            list.add(eventInfo);
//                            uploadBatchPolicy(list);
//                        }
                        storeEventQueue(eventInfo);
                    }
                });


    }

    /**
     * APP退出的时候检测缓存
     */
    public static void finishCheckEvent(){
        switch (GtStatInterface.getUploadPolicy()){
            case UPLOAD_POLICY_INTERVA:
            case UPLOAD_POLICY_BATCH:
            case UPLOAD_POLICY_REALTIME:
            case UPLOAD_POLICY_DEVELOPMENT:
                uploadBatchPolicy();
                break;
            case UPLOAD_POLICY_WHILE_INITIALIZE:
                uploadWhileInitialize();
                break;

            default:
                break;
        }
    }
}
