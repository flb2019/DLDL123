package com.soso.common.module.monitoring.monitor.db;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;
import android.content.Context;
import android.util.Log;

import com.soso.common.module.monitoring.monitor.bean.EventInfo;

/**
 * Created by haipeng.L on 2018/9/10.
 */

@Database(entities = {EventInfo.class},version = 1, exportSchema = false)
@TypeConverters({HashMapConverter.class})
public abstract class GtMonitorDatabase extends RoomDatabase {

    private static final String LOG_TAG = GtMonitorDatabase.class.getSimpleName();
    private static final String DATABASE_NAME = "gtmonitor";

    // For Singleton instantiation
    private static final Object LOCK = new Object();
    private static GtMonitorDatabase sInstance;

    public static GtMonitorDatabase getInstance(Context context) {
        Log.d(LOG_TAG, "Getting the database");
        if (sInstance == null) {
            synchronized (LOCK) {
                sInstance = Room.databaseBuilder(context.getApplicationContext(), GtMonitorDatabase.class, GtMonitorDatabase.DATABASE_NAME)
                        .allowMainThreadQueries()
//                        .fallbackToDestructiveMigration()//数据库迁移时，清空数据库的内容（不推荐使用，体验不好）。
//                        .addMigrations(MIGRATION_1_2,MIGRATION_2_3)//2.6版本之后如果更改了数据库，需要用此方法升级数据库
                        .build();
                Log.d(LOG_TAG, "Made new database");
            }
        }
        return sInstance;
    }

    public abstract EventMsgDao eventMsgDao();

}
