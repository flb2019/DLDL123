package com.soso.common.module.monitoring.core.wrapper;

import android.app.Application;
import android.content.Context;
import android.os.Looper;
import android.support.v4.app.Fragment;

import com.soso.common.module.monitoring.core.base.GtCrashListener;
import com.soso.common.module.monitoring.core.base.ICrashReportInterface;
import com.soso.common.module.monitoring.core.base.IStatsInterface;
import com.soso.common.module.monitoring.monitor.core.GtStatInterface;
import com.soso.common.module.monitoring.monitor.config.EventConfig;
import com.soso.common.module.monitoring.monitor.core.GtCrashHandler;
import com.soso.common.module.monitoring.monitor.core.OnCrashListener;
import com.soso.common.module.monitoring.todo.Config;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Created by haipeng.L on 2018/9/26.
 * 给 activity 和 fragment 生命周期 设置提供者
 */

public class GtMonitorStatsWrapper implements IStatsInterface, ICrashReportInterface {

    private AtomicBoolean mInitialized = new AtomicBoolean(false);
    private static final class Holder {
        private static final GtMonitorStatsWrapper mInstance = new GtMonitorStatsWrapper();
    }

    public static GtMonitorStatsWrapper getInstance() {
        return Holder.mInstance;
    }

    @Override
    public void initialize(Application application, String channel, Boolean isListener) {
        if (!mInitialized.getAndSet(false)){
            // 注册url 到基础框架中，
//            initUrls();
            // 初始化异常捕获
//            String uid=UserModule.getUserInfo(application).uid;   //获取uid
            String uid = "";
            GtStatInterface.initialize(application, Config.APPID, channel,uid,isListener);
            // set upload url
            // Set loadPolicy
            GtStatInterface.setUploadPolicy(GtStatInterface.UploadPolicy.UPLOAD_POLICY_BATCH, GtStatInterface.UPLOAD_BATCH_TWENTY);
            // app启动埋点,先判断是否在当前主线程
            if (isOnMainThread()){
                GtStatInterface.recordAppStart(EventConfig.START_APP_EVENTID,EventConfig.START_APP_NAME);
            }
        }

    }

    /**进入界面*/
    @Override
    public void onResume(final Context context){
        if (!mInitialized.get()){
            GtStatInterface.recordPageStart(EventConfig.ACTIVE_EVENTID,EventConfig.ACTIVE_NAME);
            return;
        }
    }
    /**退出界面*/
    @Override
    public void onPause(final Context context){
        if (!mInitialized.get()){
            GtStatInterface.recordPageEnd(EventConfig.NO_ACTIVE_EVENTID,EventConfig.NO_ACTIVE_NAME);
            return;
        }
    }
    /**进入界面*/
    @Override
    public void onResume(final Fragment context){
        if (!mInitialized.get()){
           GtStatInterface.recordPageStart(EventConfig.ACTIVE_EVENTID,EventConfig.ACTIVE_NAME);
            return;
        }
    }
    /**退出界面*/
    @Override
    public void onPause(final Fragment context){
        if (!mInitialized.get()){
            GtStatInterface.recordPageEnd(EventConfig.NO_ACTIVE_EVENTID,EventConfig.NO_ACTIVE_NAME);
            return;
        }
    }

    /**上报访问日志*/
    @Override
    public void postClientData(final Context context) {
        if (!mInitialized.get()){
            return;
        }
        GtStatInterface.send();
    }

    /**事件统计 */
    public void onEvent(final Context context, final String event_id, final String event_name, final HashMap<String,String> params){

    }

    /**事件统计 充值时带上参数多少钱*/
    @Override
    public void onEvent(final Context context, final String event_id, final String value) {
        if (!mInitialized.get()){
            return;
        }
    }

    /**启动错误收集*/
    @Override
    public void onError(final Context context) {
        if (!mInitialized.get()){
            return;
        }
    }

    @Override
    public void onProfileSignIn(int ID) {

    }

    @Override
    public void onProfileSignIn(String Provider, String ID) {

    }

    @Override
    public void onProfileSignOff() {

    }

    @Override
    public void onDestroy() {
        // app 退出埋点
        GtStatInterface.recordAppEnd(EventConfig.ONDESTROY_EVENTID, EventConfig.ONDESTROY_NAME);
    }

    @Override
    public void initCrashReport(Application application, GtCrashListener crashListener, boolean isDebug) {
//        initialize(context);
        if (crashListener != null){
        }
        GtCrashHandler.getInstance().setOnCrashListener(new OnCrashListener() {
            @Override
            public void onDealCrash(Throwable ex) {
                if (crashListener != null){
                    crashListener.gtCrashInfo(ex);
                }
            }
        },isDebug);
    }


//    /**
//     * 注册url 到基础框架中， 因为有些基础业务模块需要url
//     */
//    private void initUrls() {
//        Urls.Builder builder = new Urls.Builder()
//                .setHost(com.cn.utopa.baseframe.net.Urls.HOST)
//                .setApiDefaultUrl(com.cn.utopa.baseframe.net.Urls.HOST + "/app.do")
////                .setApiDefaultUrl(BuildConfig.ServerAddr + "/ting-common-entry/app.do")
//                .setWebhost(com.cn.utopa.baseframe.net.Urls.WebHost)
//                .setMethodSession(com.cn.utopa.baseframe.net.Urls.METHOD_SESSION)
//                .setAccountSessionRenew(com.cn.utopa.baseframe.net.Urls.METHOD_ACCOUNT_SESSION_RENEW)
//                .setAccountTokenRenew(com.cn.utopa.baseframe.net.Urls.METHOD_ACCOUNT_TOKEN_RENEW)
//                .build();
////        Urls.init(builder);
//    }

    /**
     * 判断是否在当前主线程
     * @return
     */
    public static boolean isOnMainThread(){
        return Thread.currentThread() == Looper.getMainLooper().getThread();
    }


}
