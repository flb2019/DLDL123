package com.soso.common.module.monitoring.core.wrapper;

import android.app.Application;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.text.TextUtils;

import com.soso.common.module.monitoring.core.analysis.AnalysisConfig;
import com.soso.common.module.monitoring.core.base.GtCrashListener;
import com.soso.common.module.monitoring.core.base.ICrashReportInterface;
import com.soso.common.module.monitoring.core.base.IStatsInterface;
import com.umeng.analytics.MobclickAgent;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;


/**
 * Created by haipeng.L on 2018/9/26.
 */

public class UmengStatsWrapper implements IStatsInterface, ICrashReportInterface {

    private AtomicBoolean mInitialized = new AtomicBoolean(false);
    private JSONObject eventJsonObject = null;

    private static final class Holder {
        private static final UmengStatsWrapper mInstance = new UmengStatsWrapper();
    }

    public static UmengStatsWrapper getInstance() {
        return Holder.mInstance;
    }

    /// from IStatsInterface
    @Override
    public void initialize(Application application, String channel, Boolean isListener) {
        if (!mInitialized.getAndSet(true)) {
//            getEventJsonObject(context);
            String appKey = "appkey";
            // 设置输出运行时日志
            MobclickAgent.setDebugMode(false);
            // SDK在统计Fragment时，需要关闭Activity自带的页面统计，
            // 然后在每个页面中重新集成页面统计的代码(包括调用了 onResume 和 onPause 的Activity)。
            MobclickAgent.openActivityDurationTrack(false);
            MobclickAgent.setSessionContinueMillis(AnalysisConfig.sessionInterval);
            MobclickAgent.startWithConfigure(
                    new MobclickAgent.UMAnalyticsConfig(application, appKey,
                            "channel",
                            MobclickAgent.EScenarioType.E_UM_NORMAL, false));

            MobclickAgent.setScenarioType(application, MobclickAgent.EScenarioType.E_UM_NORMAL);
        }
    }

    @Override
    public void onResume(Context context) {
        if (mInitialized.get()) {
            MobclickAgent.onResume(context);
        }

    }

    @Override
    public void onPause(Context context) {
        if (mInitialized.get()) {
            MobclickAgent.onPause(context);
        }
    }

    @Override
    public void onResume(Fragment context) {
        MobclickAgent.onPageStart(context.getClass().getName());
    }

    @Override
    public void onPause(Fragment context) {
        if (mInitialized.get()) {
            MobclickAgent.onPageEnd(context.getClass().getName());
        }
    }

    @Override
    public void postClientData(Context context) {
        //do nothing
    }

    @Override
    public void onEvent(Context context, String event_id, String event_name, HashMap<String, String> params) {
//        map.put(StatsConst.UID, String.valueOf(uid));
//        Map<String, String> map_ekv = parseKeyJson(event_id, value);
//        Map<String, String> map_ekv = new HashMap<>();
//        map_ekv.put(event_id,value);
//        if (UmsInit.empty(map_ekv)) {
//            return;//不在表里的不上报
//        }
        MobclickAgent.onEvent(context, event_id,params);
    }

    @Override
    public void onEvent(Context context, String event_id, String value) {
//        map.put(StatsConst.UID, String.valueOf(uid));
//        Map<String, String> map_ekv = parseKeyJson(event_id, value);
////        Map<String, String> map_ekv = new HashMap<>();
////        map_ekv.put(event_id,value);
//        if (UmsInit.empty(map_ekv)) {
//            return;//不在表里的不上报
//        }
        MobclickAgent.onEvent(context, event_id);
    }

    @Override
    public void onError(Context context) {
        if (mInitialized.get()) {
//            MobclickAgent.reportError(context, t);
        }
    }

    @Override
    public void initCrashReport(Application application, GtCrashListener crashListener, boolean isDebug) {
//        initialize(context);
    }

    private static String[] getUMValues(String str) {
        if (TextUtils.isEmpty(str)) {
            str = "1";
        }
        String[] keys = str.split("#");
        return keys;
    }

    @Override
    public void onProfileSignIn(int ID){
        MobclickAgent.onProfileSignIn(ID+"");
    }

    @Override
    public void onProfileSignIn(String Provider, String ID){
        MobclickAgent.onProfileSignIn(Provider,ID);
    }

    @Override
    public void onProfileSignOff(){
        MobclickAgent.onProfileSignOff();
    }

    @Override
    public void onDestroy() {

    }

//    private void getEventJsonObject(Context context) {
//        Observable.just(context)
//                .subscribeOn(Schedulers.io())
//                .map(new Function<Context, Object>() {
//                    @Override
//                    public JSONObject apply(Context context) {
//                        JSONObject jsonObject = null;
//                        String jsonstr = SystemUtils.getUMKeys(context);
//                        try {
//                            jsonObject = new JSONObject(jsonstr);
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                        return jsonObject;
//                    }
//                })
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(new Action1<JSONObject>() {
//                    @Override
//                    public void call(JSONObject jsonObject) {
//                        eventJsonObject = jsonObject;
//                    }
//                });
//    }

    private Map<String, String> parseKeyJson(String eventId, String value) {
        if (TextUtils.isEmpty(eventId)) {
            return null;
        }
        String[] values = getUMValues(value);
        Map<String, String> map_ekv = new HashMap<String, String>();
        if (eventJsonObject == null) {
            return null;
        }
        try {
            JSONObject jsonObject = eventJsonObject;
            if (jsonObject.isNull(eventId)) {
                return null;
            }
            if (!TextUtils.isEmpty(jsonObject.optString(eventId))) {
                JSONObject eventObject = jsonObject.optJSONObject(eventId);
                if (eventObject == null) {
                    return null;
                }
                if (eventObject.isNull("event_parameter_list")) {
                    map_ekv.put("status", "1");
                    return map_ekv;
                }
                JSONObject jsonArray = eventObject.optJSONObject("event_parameter_list");
                if (jsonArray == null || jsonArray.length() == 0) {
                    map_ekv.put("status", "1");
                    return map_ekv;
                }
                for (int i = 1; i < jsonArray.length() + 1; i++) {
                    //拿到key了
                    String key = jsonArray.optString(i + "");
                    String valueTemp = "1";
                    if (i - 1 < values.length) {
                        //预防数组越界
                        valueTemp = values[i - 1];
                    }
                    if (eventObject.isNull(key)) {//不需要把value转成对应中文
                        map_ekv.put(key, valueTemp);
                        continue;
                    }

                    JSONObject keyObject = eventObject.optJSONObject(key);
                    if (keyObject.isNull(valueTemp)) {//传入的value不在表里则跳过
                        continue;
                    }
                    valueTemp = keyObject.optString(valueTemp);
                    map_ekv.put(key, valueTemp);
                }
            } else {
                map_ekv.put("status", "1");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return map_ekv;
    }

}
