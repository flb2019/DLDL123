package com.soso.common.module.monitoring.monitor.db;

import android.content.Context;

import com.cn.gtmonitoring.Model.EventInfo;
import com.soso.common.module.monitoring.monitor.bean.EventInfo;

import java.util.List;

import io.reactivex.Maybe;

/**
 * Created by haipeng.L on 2018/9/14.
 */

public class StaticsAgent {
    private static Context mContext;

    public static void init(Context context){
        mContext = context;
    }

    public static Maybe<List<EventInfo>> getEventMsgList(long time) {
        Maybe<List<EventInfo>> list = GtMonitorDatabase.getInstance(mContext).eventMsgDao().getEventMsgList(time);
        return list;
    }

    public static List<Long> insertEventMsgs(List<EventInfo> lists){
      return GtMonitorDatabase.getInstance(mContext).eventMsgDao().insertEventMsgs(lists);
    }

    public static int deleteEventMsgList(List<EventInfo> lists){
        return GtMonitorDatabase.getInstance(mContext).eventMsgDao().deleteEventMsgList(lists);
    }

    public static int deleteEventMsgList(){
        return GtMonitorDatabase.getInstance(mContext).eventMsgDao().deleteEventMsgList(System.currentTimeMillis());
    }


}
