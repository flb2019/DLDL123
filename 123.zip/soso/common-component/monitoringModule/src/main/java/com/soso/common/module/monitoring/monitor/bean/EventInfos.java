package com.soso.common.module.monitoring.monitor.bean;

import java.util.List;

/**
 * Created by haipeng.L on 2018/9/10.
 */

public class EventInfos {
    private List<EventInfo> messages;

    public List<EventInfo> getMessages() {
        return messages;
    }

    public void setMessages(List<EventInfo> messages) {
        this.messages = messages;
    }
}
