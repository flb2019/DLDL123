package com.soso.common.module.monitoring.todo;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.View;

import com.soso.common.module.monitoring.core.wrapper.GtMonitorStatsWrapper;
import com.soso.sosolib.utils.LogUtils;
import com.umeng.analytics.MobclickAgent;

/**
 * Created by sumerlin on 2019/2/26 2019/2/26.
 * Describe:
 */
public class FragmentLifecycleImpl extends FragmentManager.FragmentLifecycleCallbacks{


    @Override
    public void onFragmentViewCreated(FragmentManager fm, Fragment f, View v, Bundle savedInstanceState) {
        super.onFragmentViewCreated(fm, f, v, savedInstanceState);
        LogUtils.i("monitoringModule.....FragmentLifecycleImpl................onFragmentViewCreated");
    }

    /*************************  友盟 - start ****************************/
    @Override
    public void onFragmentResumed(FragmentManager fm, Fragment f) {
        super.onFragmentResumed(fm, f);
        LogUtils.i("monitoringModule.....FragmentLifecycleImpl................onFragmentResumed");
        MobclickAgent.onPageStart(this.getClass().getSimpleName()); //统计页面，"MainScreen"为页面名称，可自定义
        GtMonitorStatsWrapper.getInstance().onResume(f.getActivity()); // gmotitor 监听时长
    }

    @Override
    public void onFragmentPaused(FragmentManager fm, Fragment f) {
        LogUtils.i("monitoringModule.....FragmentLifecycleImpl................onFragmentPaused");
        super.onFragmentPaused(fm, f);
        MobclickAgent.onPageEnd(this.getClass().getSimpleName());
        GtMonitorStatsWrapper.getInstance().onPause(f.getActivity()); // gmotitor 监听时长
    }

    /*************************  友盟 - end ****************************/
}
