package com.soso.common.module.monitoring.core.base;

/**
 * Created by zhouwei2 on 2018/9/27.
 */

public interface GtCrashListener {
    void gtCrashInfo(Throwable ex);
}
