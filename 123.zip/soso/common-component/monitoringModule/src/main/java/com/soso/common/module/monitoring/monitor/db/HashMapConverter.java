package com.soso.common.module.monitoring.monitor.db;

import android.arch.persistence.room.TypeConverter;
import android.text.TextUtils;

import com.google.gson.GsonBuilder;

import java.util.HashMap;

/**
 * Created by haipeng.L on 2018/9/11.
 */

public class HashMapConverter {
    @TypeConverter
    public static HashMap<String,Object> toHashMap(String str){
        HashMap<String, Object> params;
        if (TextUtils.isEmpty(str)){
            params = new HashMap<>();
            return params;
        }
        params = new GsonBuilder().create().fromJson(str, HashMap.class);
        return params;
    }

    @TypeConverter
    public static String toStr(HashMap<String,Object> hashMap){
        if (hashMap == null){
            return "";
        }
        return new GsonBuilder().create().toJson(hashMap);
    }
}
